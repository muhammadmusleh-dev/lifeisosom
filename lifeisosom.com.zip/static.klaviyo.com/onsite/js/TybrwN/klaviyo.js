var KLAVIYO_JS_REGEX = /(\/onsite\/js\/([a-zA-Z]{6})\/klaviyo\.js\?company_id=([a-zA-Z0-9]{6}).*|\/onsite\/js\/klaviyo\.js\?company_id=([a-zA-Z0-9]{6}).*)/;

function logFailedKlaviyoJsLoad(e, t, o) {
    var n = {
        metric_group: "onsite",
        events: [{
            metric: "klaviyoJsCompanyIdMisMatch",
            log_to_statsd: !0,
            log_to_s3: !0,
            log_to_metrics_service: !1,
            event_details: {
                script: e,
                templated_company_id: t,
                fastly_forwarded: o,
                hostname: window.location.hostname
            }
        }]
    };
    fetch("https://a.klaviyo.com/onsite/track-analytics?company_id=".concat(t), {
        headers: {
            accept: "application/json",
            "content-type": "application/json"
        },
        referrerPolicy: "strict-origin-when-cross-origin",
        body: JSON.stringify(n),
        method: "POST",
        mode: "cors",
        credentials: "omit"
    })
}! function(e) {
    var t = "TybrwN",
        o = JSON.parse("[]"),
        n = "true" === "True".toLowerCase(),
        a = JSON.parse("[\u0022is_kservice_billing_enabled\u0022]"),
        r = new Set(null != a ? a : []),
        s = JSON.parse("[\u0022onsite_datadome_enabled\u0022]"),
        c = new Set(null != s ? s : []),
        i = "true" === "False".toLowerCase();
    if (!(document.currentScript && document.currentScript instanceof HTMLScriptElement && document.currentScript.src && document.currentScript.src.match(KLAVIYO_JS_REGEX)) || null !== (e = document.currentScript.src) && void 0 !== e && e.includes(t) || i) {
        var d = window.klaviyoModulesObject;
        if (window._learnq = window._learnq || [], window.__klKey = window.__klKey || t, d || (window._learnq.push(["account", t]), d = {
                companyId: t,
                loadTime: new Date,
                loadedModules: {},
                loadedCss: {},
                serverSideRendered: !0,
                assetSource: "",
                v2Route: n,
                extendedIdIdentifiers: o,
                env: "web",
                featureFlags: r,
                hotsettings: c
            }, Object.defineProperty(window, "klaviyoModulesObject", {
                value: d,
                enumerable: !1
            })), t === d.companyId && d.serverSideRendered) {
            var l, p, u, m = {},
                y = document,
                _ = y.head,
                f = JSON.parse("noModule" in y.createElement("script") || function() {
                    try {
                        return new Function('import("")'), !0
                    } catch (e) {
                        return !1
                    }
                }() ? "{\u0022static\u0022: {\u0022js\u0022: [\u0022https://static\u002Dtracking.klaviyo.com/onsite/js/fender_analytics.e5aba8b3a52dc623782c.js?cb\u003D2\u0022, \u0022https://static\u002Dtracking.klaviyo.com/onsite/js/static.5f280103f51ea7c7fff7.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/runtime.47df4c563c983aef99bc.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/sharedUtils.bc619e620ff8b33f5f9c.js?cb\u003D2\u0022]}}" : "{\u0022static\u0022: {\u0022js\u0022: [\u0022https://static\u002Dtracking.klaviyo.com/onsite/js/fender_analytics.c6670ae4aca3f547c70b.js?cb\u003D2\u0022, \u0022https://static\u002Dtracking.klaviyo.com/onsite/js/static.7140ef9888c75ce53d81.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/runtime.61f703e6cea589d1f92a.js?cb\u003D2\u0022, \u0022https://static.klaviyo.com/onsite/js/sharedUtils.4f2fe65f88b32c99149a.js?cb\u003D2\u0022]}}"),
                w = d,
                v = w.loadedCss,
                S = w.loadedModules;
            for (l in f)
                if (f.hasOwnProperty(l)) {
                    var h = f[l];
                    h.js.forEach((function(e) {
                        var t = e.split("?")[0];
                        t && !S[t] && (j(e), S[t] = (new Date).toISOString())
                    }));
                    var g = h.css;
                    g && !v[g] && (p = g, u = void 0, (u = y.createElement("link")).rel = "stylesheet", u.href = p, _.appendChild(u), v[g] = (new Date).toISOString())
                }
        } else console.warn("Already loaded for account ".concat(d.companyId, ". Skipping account ").concat(t, "."))
    } else {
        console.warn("Not loading ".concat(document.currentScript.src, " for ").concat(t));
        try {
            logFailedKlaviyoJsLoad(document.currentScript.src, t, n)
        } catch (e) {
            console.warn("Error logging klaviyo.js company mismatch")
        }
    }

    function j(e) {
        if (!m[e]) {
            var t = y.createElement("script");
            t.type = "text/javascript", t.async = !0, t.src = e, t.crossOrigin = "anonymous", _.appendChild(t), m[e] = !0
        }
    }
}();