{
    "token": "hWN79edBoCcoyhndxe69G0Pb?key=d71267e6ba32a5e0d24aec3b2e3cd505",
    "note": "",
    "attributes": {},
    "original_total_price": 0,
    "total_price": 0,
    "total_discount": 0,
    "total_weight": 0.0,
    "item_count": 0,
    "items": [],
    "requires_shipping": false,
    "currency": "USD",
    "items_subtotal_price": 0,
    "cart_level_discount_applications": [],
    "discount_codes": []
}