(() => {
    var s = "WebPixel::Render";
    var o = t => shopify.extend(s, t);
    o(({
        settings: t,
        analytics: r
    }) => {
        let i = new Set(["page_viewed", "cart_viewed", "product_viewed", "product_added_to_cart", "product_removed_from_cart", "search_submitted", "checkout_started", "checkout_completed"]),
            d = new Set(["ocu_upsell_shown", "ocu_upsell_accepted"]),
            c = e => {
                e.billingAddress = null, e.email = null, e.phone = null, e.shippingAddress = null
            };

        function n(e) {
            fetch(t.trackingUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Shop-Token": t.shopToken
                },
                keepalive: !0,
                body: JSON.stringify(e)
            })
        }
        r.subscribe("all_standard_events", function(e) {
            i.has(e.name) && (e.data.checkout && c(e.data.checkout), n(e))
        }), r.subscribe("all_custom_events", e => {
            d.has(e.name) && n(e)
        })
    });
})();