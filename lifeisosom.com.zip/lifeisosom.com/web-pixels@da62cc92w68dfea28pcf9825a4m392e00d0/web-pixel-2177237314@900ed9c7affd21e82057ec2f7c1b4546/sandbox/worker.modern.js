importScripts('https://lifeisosom.com/cdn/wpm/sda62cc92w68dfea28pcf9825a4m392e00d0m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('2177237314', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-2177237314@900ed9c7affd21e82057ec2f7c1b4546.js');