(function(shopify) {
    (() => {
        var be = Object.defineProperty,
            Ae = Object.defineProperties;
        var Te = Object.getOwnPropertyDescriptors;
        var _e = Object.getOwnPropertySymbols;
        var Ce = Object.prototype.hasOwnProperty,
            Pe = Object.prototype.propertyIsEnumerable;
        var ue = (t, _, g) => _ in t ? be(t, _, {
                enumerable: !0,
                configurable: !0,
                writable: !0,
                value: g
            }) : t[_] = g,
            O = (t, _) => {
                for (var g in _ || (_ = {})) Ce.call(_, g) && ue(t, g, _[g]);
                if (_e)
                    for (var g of _e(_)) Pe.call(_, g) && ue(t, g, _[g]);
                return t
            },
            q = (t, _) => Ae(t, Te(_));
        var Ee = "WebPixel::Render";
        var V = t => shopify.extend(Ee, t);
        var ce = !1;

        function we() {
            for (let t of Object.values(me)) t.enabled = t.percent > Math.random() * 100
        }

        function P(t) {
            return ce || (ce = !0, we()), me[t].enabled
        }
        var me = {
            0: {
                percent: 0,
                enabled: !1
            },
            1: {
                percent: 0,
                enabled: !1
            },
            2: {
                percent: 100,
                enabled: !1
            },
            3: {
                percent: 100,
                enabled: !0
            },
            4: {
                percent: 100,
                enabled: !1
            },
            5: {
                percent: 100,
                enabled: !1
            },
            6: {
                percent: 0,
                enabled: !1
            }
        };
        var Fe = "developer_id.dYmNjMT",
            U = "dNzYwYj";

        function ye(t) {
            let _ = t.init.customerPrivacy;
            if (_ === void 0 || _.marketingAllowed || _.analyticsProcessingAllowed) fe(t, _);
            else {
                let g = !1;
                t.customerPrivacy.subscribe("visitorConsentCollected", b => {
                    let A = b.customerPrivacy;
                    !g && (A.marketingAllowed || A.analyticsProcessingAllowed) && (fe(t, A), g = !0)
                })
            }
        }

        function fe(t, _) {
            var W, H, J, $, X, Z, K, Q, h, k, ee, te;
            let g = window.dataLayer = window.dataLayer || [],
                b = JSON.parse(t.settings.config),
                A = [];
            if (b.google_tag_ids && b.google_tag_ids.length > 0) {
                let e = b.google_tag_ids;
                A.push(...e)
            } else A.push(b.pixel_id);
            let u = window.gtag = window.gtag || function() {
                g.push(arguments)
            };
            _ && (u("consent", "default", ge(_)), u("set", pe(_))), D(t) && (u("set", {
                ignore_referrer: "true"
            }), u("policy", "detect_click_events", () => !1), u("policy", "detect_element_visibility_events", () => !1), u("policy", "detect_history_change_events", () => !1), u("policy", "detect_link_click_events", () => !1), u("policy", "detect_timer_events", () => !1), u("policy", "detect_youtube_activity_events", () => !1), u("policy", "detect_scroll_events", () => !1), u("policy", "detect_form_submit_events", () => !1), u("policy", "detect_form_interaction_events", () => !1)), u("policy", "internal_sw_allowed", () => !1), P(4) && u("policy", "inject_cmp_banner", () => !1), P(6) && u("policy", "all", (e, n, i) => {
                let a = i == null ? void 0 : i.options;
                switch (n) {
                    case "detect_link_click_events":
                    case "detect_form_submit_events":
                        return (a == null ? void 0 : a.waitForTags) !== !0;
                    case "detect_youtube_activity_events":
                        return (a == null ? void 0 : a.fixMissingApi) !== !0;
                    default:
                        return !0
                }
            }), u("set", Fe, !0), u("js", new Date);
            let j = {
                send_page_view: !1
            };
            D(t) && (j.ignore_referrer = "true");
            for (let e of A) {
                let n = document.createElement("script");
                n.src = `https://www.googletagmanager.com/gtag/js?id=${e}`, document.body.appendChild(n), u("config", e, j)
            }
            let F = b.gtag_events,
                N = e => {
                    var n;
                    return "shopify_" + (b.target_country || "US") + "_" + String((n = e == null ? void 0 : e.product) == null ? void 0 : n.id) + "_" + String(e == null ? void 0 : e.id)
                },
                S = e => {
                    let n = e == null ? void 0 : e.title;
                    return ["default", "title", "default title", ""].includes(String(n).toLowerCase()) ? null : n
                },
                x = e => {
                    var m, p, r, s, y, f, R, d, c, o, w, v;
                    let i = {
                            value: (m = e == null ? void 0 : e.subtotalPrice) == null ? void 0 : m.amount
                        },
                        a = (r = (p = e == null ? void 0 : e.totalPrice) == null ? void 0 : p.amount) != null ? r : 0;
                    a -= (y = (s = e == null ? void 0 : e.totalTax) == null ? void 0 : s.amount) != null ? y : 0, a -= (d = (R = (f = e == null ? void 0 : e.shippingLine) == null ? void 0 : f.price) == null ? void 0 : R.amount) != null ? d : 0;
                    let E = 0,
                        l = (c = e == null ? void 0 : e.lineItems) != null ? c : [];
                    for (let T of l) {
                        let C = (w = (o = T.variant) == null ? void 0 : o.price.amount) != null ? w : 0;
                        C *= T.quantity;
                        for (let I of T.discountAllocations) C -= (v = I.amount.amount) != null ? v : 0;
                        E += C
                    }
                    return P(3) && (i.google_analysis_params = {
                        lineItemValue: E,
                        totalPriceValue: a
                    }), i
                },
                L = (e, n) => n ? `${e} - ${n}` : e,
                ve = (e, n) => {
                    var i;
                    if (e === "/search") {
                        let a = (i = document.querySelector("link[rel='canonical']")) == null ? void 0 : i.getAttribute("href");
                        if (a) return a
                    }
                    return n
                },
                Re = (e, n, i) => e && e.endsWith("thank_you") ? L(n, i) : n,
                B = e => {
                    var n, i, a, E, l, m, p;
                    return {
                        email: e == null ? void 0 : e.email,
                        phone_number: e == null ? void 0 : e.phone,
                        address: {
                            first_name: (n = e == null ? void 0 : e.billingAddress) == null ? void 0 : n.firstName,
                            last_name: (i = e == null ? void 0 : e.billingAddress) == null ? void 0 : i.lastName,
                            street: (a = e == null ? void 0 : e.billingAddress) == null ? void 0 : a.address1,
                            city: (E = e == null ? void 0 : e.billingAddress) == null ? void 0 : E.city,
                            region: (l = e == null ? void 0 : e.billingAddress) == null ? void 0 : l.province,
                            postal_code: (m = e == null ? void 0 : e.billingAddress) == null ? void 0 : m.zip,
                            country: (p = e == null ? void 0 : e.billingAddress) == null ? void 0 : p.country
                        }
                    }
                },
                Y = {
                    email: (J = (H = (W = t.init) == null ? void 0 : W.data) == null ? void 0 : H.customer) == null ? void 0 : J.email,
                    phone_number: (Z = (X = ($ = t.init) == null ? void 0 : $.data) == null ? void 0 : X.customer) == null ? void 0 : Z.phone,
                    address: {
                        first_name: (h = (Q = (K = t.init) == null ? void 0 : K.data) == null ? void 0 : Q.customer) == null ? void 0 : h.firstName,
                        last_name: (te = (ee = (k = t.init) == null ? void 0 : k.data) == null ? void 0 : ee.customer) == null ? void 0 : te.lastName
                    }
                };
            t.analytics.subscribe("page_viewed", e => {
                var i, a, E, l, m, p, r, s;
                let n = F.find(y => y.type === "page_view");
                if (n && n.action_label) {
                    let y = (E = (a = (i = e.context) == null ? void 0 : i.window) == null ? void 0 : a.location) == null ? void 0 : E.pathname,
                        f = O({
                            send_to: n.action_label,
                            developer_id: {
                                [U]: !0
                            },
                            page_path: y,
                            page_title: Ie((m = (l = e.context) == null ? void 0 : l.document) == null ? void 0 : m.title, y),
                            page_location: ve(y, (s = (r = (p = e.context) == null ? void 0 : p.window) == null ? void 0 : r.location) == null ? void 0 : s.href),
                            user_data: Y
                        }, !P(2) && D(t) && {
                            ignore_referrer: "true"
                        });
                    u("event", "page_view", f)
                }
            }), t.analytics.subscribe("product_viewed", e => {
                var i, a, E, l, m, p;
                let n = F.find(r => r.type === "view_item");
                if (n && n.action_label) {
                    let r = (i = e.data) == null ? void 0 : i.productVariant;
                    u("event", "view_item", {
                        send_to: n.action_label,
                        developer_id: {
                            [U]: !0
                        },
                        ecomm_prodid: [N(r)],
                        ecomm_totalvalue: (a = r == null ? void 0 : r.price) == null ? void 0 : a.amount,
                        ecomm_pagetype: "product",
                        items: [{
                            id: N(r),
                            name: L((E = r == null ? void 0 : r.product) == null ? void 0 : E.title, S(r)),
                            brand: (l = r == null ? void 0 : r.product) == null ? void 0 : l.vendor,
                            category: (m = r == null ? void 0 : r.product) == null ? void 0 : m.type,
                            price: (p = r == null ? void 0 : r.price) == null ? void 0 : p.amount,
                            variant: S(r)
                        }],
                        user_data: Y
                    })
                }
            }), t.analytics.subscribe("product_added_to_cart", e => {
                var i, a, E, l, m, p, r, s, y, f, R;
                let n = F.find(d => d.type === "add_to_cart");
                if (n && n.action_label) {
                    let d = (i = e.data) == null ? void 0 : i.cartLine,
                        c = d == null ? void 0 : d.merchandise;
                    u("event", "add_to_cart", {
                        send_to: n.action_label,
                        developer_id: {
                            [U]: !0
                        },
                        ecomm_prodid: [N(d == null ? void 0 : d.merchandise)],
                        ecomm_totalvalue: (E = (a = d == null ? void 0 : d.cost) == null ? void 0 : a.totalAmount) == null ? void 0 : E.amount,
                        ecomm_pagetype: "cart",
                        value: (m = (l = d == null ? void 0 : d.cost) == null ? void 0 : l.totalAmount) == null ? void 0 : m.amount,
                        currency: ((r = (p = d == null ? void 0 : d.cost) == null ? void 0 : p.totalAmount) == null ? void 0 : r.currencyCode) || "USD",
                        items: [{
                            id: N(c),
                            name: L((s = c == null ? void 0 : c.product) == null ? void 0 : s.title, S(c)),
                            brand: (y = c == null ? void 0 : c.product) == null ? void 0 : y.vendor,
                            category: (f = c == null ? void 0 : c.product) == null ? void 0 : f.type,
                            price: (R = c == null ? void 0 : c.price) == null ? void 0 : R.amount,
                            quantity: d == null ? void 0 : d.quantity,
                            variant: S(c)
                        }],
                        user_data: Y
                    })
                }
            }), t.analytics.subscribe("checkout_completed", e => {
                var i, a, E, l, m, p, r, s, y, f, R, d, c;
                let n = F.find(o => o.type === "purchase");
                if (n && n.action_label) {
                    let o = (i = e.data) == null ? void 0 : i.checkout,
                        w = O(q(O({
                            send_to: n.action_label,
                            developer_id: {
                                [U]: !0
                            },
                            transaction_id: (a = o == null ? void 0 : o.order) == null ? void 0 : a.id,
                            new_customer: ((l = (E = o == null ? void 0 : o.order) == null ? void 0 : E.customer) == null ? void 0 : l.isFirstOrder) == null || (p = (m = o == null ? void 0 : o.order) == null ? void 0 : m.customer) == null ? void 0 : p.isFirstOrder
                        }, x(o)), {
                            currency: ((r = o == null ? void 0 : o.subtotalPrice) == null ? void 0 : r.currencyCode) || "USD",
                            tax: (s = o == null ? void 0 : o.totalTax) == null ? void 0 : s.amount,
                            shipping: (f = (y = o == null ? void 0 : o.shippingLine) == null ? void 0 : y.price) == null ? void 0 : f.amount,
                            items: (R = o == null ? void 0 : o.lineItems) == null ? void 0 : R.map(v => {
                                var T, C, I, M, G, z, ne, ae, re, ie, oe, se, le, de;
                                return {
                                    id: N(v.variant),
                                    name: Re((I = (C = (T = e.context) == null ? void 0 : T.window) == null ? void 0 : C.location) == null ? void 0 : I.pathname, (G = (M = v.variant) == null ? void 0 : M.product) == null ? void 0 : G.title, S(v.variant)),
                                    brand: (ne = (z = v.variant) == null ? void 0 : z.product) == null ? void 0 : ne.vendor,
                                    category: (re = (ae = v.variant) == null ? void 0 : ae.product) == null ? void 0 : re.type,
                                    coupon: (se = (oe = (ie = v.discountAllocations) == null ? void 0 : ie[0]) == null ? void 0 : oe.discountApplication) == null ? void 0 : se.title,
                                    price: (de = (le = v.variant) == null ? void 0 : le.price) == null ? void 0 : de.amount,
                                    quantity: v.quantity,
                                    variant: S(v.variant)
                                }
                            }),
                            user_data: B(o)
                        }), !P(2) && D(t) && {
                            ignore_referrer: "true"
                        });
                    P(5) && (w.customer_type = Ne((c = (d = o == null ? void 0 : o.order) == null ? void 0 : d.customer) == null ? void 0 : c.isFirstOrder)), u("event", "purchase", w)
                }
            }), t.analytics.subscribe("checkout_started", e => {
                var i, a, E, l, m, p, r;
                let n = F.find(s => s.type === "begin_checkout");
                if (n && n.action_label) {
                    let s = (i = e.data) == null ? void 0 : i.checkout,
                        y = O(q(O({
                            send_to: n.action_label,
                            developer_id: {
                                [U]: !0
                            },
                            ecomm_prodid: (a = s == null ? void 0 : s.lineItems) == null ? void 0 : a.map(f => N(f.variant)),
                            ecomm_totalvalue: (E = s == null ? void 0 : s.subtotalPrice) == null ? void 0 : E.amount,
                            ecomm_pagetype: "cart"
                        }, x(s)), {
                            currency: ((l = s == null ? void 0 : s.subtotalPrice) == null ? void 0 : l.currencyCode) || "USD",
                            coupon: (p = (m = s == null ? void 0 : s.discountApplications) == null ? void 0 : m[0]) == null ? void 0 : p.title,
                            items: (r = s == null ? void 0 : s.lineItems) == null ? void 0 : r.map(f => {
                                var R, d, c, o, w, v, T, C, I, M, G, z;
                                return {
                                    id: N(f.variant),
                                    name: (d = (R = f.variant) == null ? void 0 : R.product) == null ? void 0 : d.title,
                                    brand: (o = (c = f.variant) == null ? void 0 : c.product) == null ? void 0 : o.vendor,
                                    category: (v = (w = f.variant) == null ? void 0 : w.product) == null ? void 0 : v.type,
                                    coupon: (I = (C = (T = f.discountAllocations) == null ? void 0 : T[0]) == null ? void 0 : C.discountApplication) == null ? void 0 : I.title,
                                    price: (G = (M = f.variant) == null ? void 0 : M.price) == null ? void 0 : G.amount,
                                    quantity: f.quantity,
                                    variant: (z = f.variant) == null ? void 0 : z.title
                                }
                            }),
                            user_data: B(s)
                        }), !P(2) && D(t) && {
                            ignore_referrer: "true"
                        });
                    u("event", "begin_checkout", y)
                }
            }), t.analytics.subscribe("search_submitted", e => {
                var i, a;
                let n = F.find(E => E.type === "search");
                n && n.action_label && u("event", "search", {
                    send_to: n.action_label,
                    developer_id: {
                        [U]: !0
                    },
                    search_term: (a = (i = e.data) == null ? void 0 : i.searchResult) == null ? void 0 : a.query,
                    user_data: Y
                })
            }), t.analytics.subscribe("payment_info_submitted", e => {
                var i, a, E;
                let n = F.find(l => l.type === "add_payment_info");
                if (n && n.action_label) {
                    let l = (i = e.data) == null ? void 0 : i.checkout,
                        m = O({
                            send_to: n.action_label,
                            developer_id: {
                                [U]: !0
                            },
                            currency: ((a = l == null ? void 0 : l.totalPrice) == null ? void 0 : a.currencyCode) || "USD",
                            total: (E = l == null ? void 0 : l.totalPrice) == null ? void 0 : E.amount,
                            user_data: B(l)
                        }, !P(2) && D(t) && {
                            ignore_referrer: "true"
                        });
                    u("event", "add_payment_info", m)
                }
            }), t.customerPrivacy.subscribe("visitorConsentCollected", e => {
                let n = e.customerPrivacy;
                u("consent", "update", ge(n)), u("set", pe(n))
            })
        }

        function pe(t) {
            return {
                restricted_data_processing: !t.saleOfDataAllowed
            }
        }

        function ge(t) {
            return {
                ad_storage: t.marketingAllowed ? "granted" : "denied",
                ad_user_data: t.marketingAllowed ? "granted" : "denied",
                ad_personalization: t.marketingAllowed ? "granted" : "denied",
                analytics_storage: t.analyticsProcessingAllowed ? "granted" : "denied"
            }
        }

        function Ne(t) {
            if (t != null) return t ? "new" : "returning"
        }

        function D(t) {
            var _;
            return ((_ = t == null ? void 0 : t._pixelInfo) == null ? void 0 : _.surfaceNext) === "checkout"
        }

        function Ie(t, _) {
            if (!_) return t;
            let g = [
                ["/information", "Checkout - Contact Information"],
                ["/shipping", "Checkout - Shipping"],
                ["/payment", "Checkout - Payment"],
                ["/review", "Checkout - Review"],
                ["/processing", "Checkout - Processing"],
                ["/thank-you", "Checkout - Receipt"],
                ["/stock-problems", "Checkout - Stock problems"],
                ["/error", "Checkout - Error"]
            ];
            for (let [b, A] of g)
                if (_.endsWith(b)) return A;
            return /^\/checkouts\/[A-Za-z0-9]+\/[A-Za-z0-9]+$/.test(_) ? "Checkout - Contact Information" : t
        }
        V(ye);
    })();

})(self.webPixelsManager.createShopifyExtend('1015972162', 'app'));