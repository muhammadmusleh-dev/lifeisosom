importScripts('https://lifeisosom.com/cdn/wpm/sda62cc92w68dfea28pcf9825a4m392e00d0m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('shopify-app-pixel', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-shopify-app-pixel@0450.js');