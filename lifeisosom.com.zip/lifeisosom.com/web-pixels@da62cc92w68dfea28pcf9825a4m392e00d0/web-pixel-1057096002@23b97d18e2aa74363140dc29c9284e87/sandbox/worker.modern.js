importScripts('https://lifeisosom.com/cdn/wpm/sda62cc92w68dfea28pcf9825a4m392e00d0m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('1057096002', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-1057096002@23b97d18e2aa74363140dc29c9284e87.js');