! function(f, R) {
    var B = ["token"];

    function o(t, e) {
        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
        t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                writable: !0,
                configurable: !0
            }
        }), Object.defineProperty(t, "prototype", {
            writable: !1
        }), e && r(t, e)
    }

    function r(t, e) {
        return (r = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
            return t.__proto__ = e, t
        })(t, e)
    }

    function a(r) {
        var n = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
            } catch (t) {
                return !1
            }
        }();
        return function() {
            var t, e = c(r),
                e = (t = n ? (t = c(this).constructor, Reflect.construct(e, arguments, t)) : e.apply(this, arguments), this);
            if (t && ("object" === U(t) || "function" == typeof t)) return t;
            if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
            if (void 0 !== e) return e;
            throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
        }
    }

    function c(t) {
        return (c = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
            return t.__proto__ || Object.getPrototypeOf(t)
        })(t)
    }

    function s(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }

    function n(t, e) {
        for (var r = 0; r < e.length; r++) {
            var n = e[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, y(n.key), n)
        }
    }

    function u(t, e, r) {
        e && n(t.prototype, e), r && n(t, r), Object.defineProperty(t, "prototype", {
            writable: !1
        })
    }

    function l(t, e) {
        return function(t) {
            if (Array.isArray(t)) return t
        }(t) || function(t, e) {
            var r = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
            if (null != r) {
                var n, i, o, a, c = [],
                    s = !0,
                    u = !1;
                try {
                    if (o = (r = r.call(t)).next, 0 === e) {
                        if (Object(r) !== r) return;
                        s = !1
                    } else
                        for (; !(s = (n = o.call(r)).done) && (c.push(n.value), c.length !== e); s = !0);
                } catch (t) {
                    u = !0, i = t
                } finally {
                    try {
                        if (!s && null != r.return && (a = r.return(), Object(a) !== a)) return
                    } finally {
                        if (u) throw i
                    }
                }
                return c
            }
        }(t, e) || p(t, e) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function d(t) {
        return function(t) {
            if (Array.isArray(t)) return m(t)
        }(t) || function(t) {
            if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t)
        }(t) || p(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function N(t, e) {
        if (null == t) return {};
        var r, n = function(t, e) {
            if (null == t) return {};
            var r, n, i = {},
                o = Object.keys(t);
            for (n = 0; n < o.length; n++) r = o[n], 0 <= e.indexOf(r) || (i[r] = t[r]);
            return i
        }(t, e);
        if (Object.getOwnPropertySymbols)
            for (var i = Object.getOwnPropertySymbols(t), o = 0; o < i.length; o++) r = i[o], 0 <= e.indexOf(r) || Object.prototype.propertyIsEnumerable.call(t, r) && (n[r] = t[r]);
        return n
    }

    function h(t, e) {
        var r, n, i, o, a = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
        if (a) return n = !(r = !0), {
            s: function() {
                a = a.call(t)
            },
            n: function() {
                var t = a.next();
                return r = t.done, t
            },
            e: function(t) {
                n = !0, i = t
            },
            f: function() {
                try {
                    r || null == a.return || a.return()
                } finally {
                    if (n) throw i
                }
            }
        };
        if (Array.isArray(t) || (a = p(t)) || e && t && "number" == typeof t.length) return a && (t = a), o = 0, {
            s: e = function() {},
            n: function() {
                return o >= t.length ? {
                    done: !0
                } : {
                    done: !1,
                    value: t[o++]
                }
            },
            e: function(t) {
                throw t
            },
            f: e
        };
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
    }

    function p(t, e) {
        var r;
        if (t) return "string" == typeof t ? m(t, e) : "Map" === (r = "Object" === (r = Object.prototype.toString.call(t).slice(8, -1)) && t.constructor ? t.constructor.name : r) || "Set" === r ? Array.from(t) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? m(t, e) : void 0
    }

    function m(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var r = 0, n = new Array(e); r < e; r++) n[r] = t[r];
        return n
    }

    function e(e, t) {
        var r, n = Object.keys(e);
        return Object.getOwnPropertySymbols && (r = Object.getOwnPropertySymbols(e), t && (r = r.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable
        })), n.push.apply(n, r)), n
    }

    function g(n) {
        for (var t = 1; t < arguments.length; t++) {
            var i = null != arguments[t] ? arguments[t] : {};
            t % 2 ? e(Object(i), !0).forEach(function(t) {
                var e, r;
                e = n, r = i[t = t], (t = y(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(i)) : e(Object(i)).forEach(function(t) {
                Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(i, t))
            })
        }
        return n
    }

    function y(t) {
        t = function(t, e) {
            if ("object" !== U(t) || null === t) return t;
            var r = t[Symbol.toPrimitive];
            if (void 0 === r) return ("string" === e ? String : Number)(t);
            r = r.call(t, e || "default");
            if ("object" !== U(r)) return r;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }(t, "string");
        return "symbol" === U(t) ? t : String(t)
    }

    function S() {
        "use strict";
        S = function() {
            return a
        };
        var s, a = {},
            t = Object.prototype,
            u = t.hasOwnProperty,
            l = Object.defineProperty || function(t, e, r) {
                t[e] = r.value
            },
            e = "function" == typeof Symbol ? Symbol : {},
            n = e.iterator || "@@iterator",
            r = e.asyncIterator || "@@asyncIterator",
            i = e.toStringTag || "@@toStringTag";

        function o(t, e, r) {
            return Object.defineProperty(t, e, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }), t[e]
        }
        try {
            o({}, "")
        } catch (s) {
            o = function(t, e, r) {
                return t[e] = r
            }
        }

        function c(t, e, r, n) {
            var i, o, a, c, e = e && e.prototype instanceof y ? e : y,
                e = Object.create(e.prototype),
                n = new x(n || []);
            return l(e, "_invoke", {
                value: (i = t, o = r, a = n, c = d, function(t, e) {
                    if (c === f) throw new Error("Generator is already running");
                    if (c === m) {
                        if ("throw" === t) throw e;
                        return {
                            value: s,
                            done: !0
                        }
                    }
                    for (a.method = t, a.arg = e;;) {
                        var r = a.delegate;
                        if (r) {
                            r = function t(e, r) {
                                var n = r.method,
                                    i = e.iterator[n];
                                if (i === s) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = s, t(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), g;
                                n = p(i, e.iterator, r.arg);
                                if ("throw" === n.type) return r.method = "throw", r.arg = n.arg, r.delegate = null, g;
                                i = n.arg;
                                return i ? i.done ? (r[e.resultName] = i.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = s), r.delegate = null, g) : i : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, g)
                            }(r, a);
                            if (r) {
                                if (r === g) continue;
                                return r
                            }
                        }
                        if ("next" === a.method) a.sent = a._sent = a.arg;
                        else if ("throw" === a.method) {
                            if (c === d) throw c = m, a.arg;
                            a.dispatchException(a.arg)
                        } else "return" === a.method && a.abrupt("return", a.arg);
                        c = f;
                        r = p(i, o, a);
                        if ("normal" === r.type) {
                            if (c = a.done ? m : h, r.arg === g) continue;
                            return {
                                value: r.arg,
                                done: a.done
                            }
                        }
                        "throw" === r.type && (c = m, a.method = "throw", a.arg = r.arg)
                    }
                })
            }), e
        }

        function p(t, e, r) {
            try {
                return {
                    type: "normal",
                    arg: t.call(e, r)
                }
            } catch (t) {
                return {
                    type: "throw",
                    arg: t
                }
            }
        }
        a.wrap = c;
        var d = "suspendedStart",
            h = "suspendedYield",
            f = "executing",
            m = "completed",
            g = {};

        function y() {}

        function v() {}

        function b() {}
        var e = {},
            k = (o(e, n, function() {
                return this
            }), Object.getPrototypeOf),
            k = k && k(k(A([]))),
            _ = (k && k !== t && u.call(k, n) && (e = k), b.prototype = y.prototype = Object.create(e));

        function C(t) {
            ["next", "throw", "return"].forEach(function(e) {
                o(t, e, function(t) {
                    return this._invoke(e, t)
                })
            })
        }

        function w(a, c) {
            var e;
            l(this, "_invoke", {
                value: function(r, n) {
                    function t() {
                        return new c(function(t, e) {
                            ! function e(t, r, n, i) {
                                var o, t = p(a[t], a, r);
                                if ("throw" !== t.type) return (r = (o = t.arg).value) && "object" == U(r) && u.call(r, "__await") ? c.resolve(r.__await).then(function(t) {
                                    e("next", t, n, i)
                                }, function(t) {
                                    e("throw", t, n, i)
                                }) : c.resolve(r).then(function(t) {
                                    o.value = t, n(o)
                                }, function(t) {
                                    return e("throw", t, n, i)
                                });
                                i(t.arg)
                            }(r, n, t, e)
                        })
                    }
                    return e = e ? e.then(t, t) : t()
                }
            })
        }

        function O(t) {
            var e = {
                tryLoc: t[0]
            };
            1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e)
        }

        function P(t) {
            var e = t.completion || {};
            e.type = "normal", delete e.arg, t.completion = e
        }

        function x(t) {
            this.tryEntries = [{
                tryLoc: "root"
            }], t.forEach(O, this), this.reset(!0)
        }

        function A(e) {
            if (e || "" === e) {
                var r, t = e[n];
                if (t) return t.call(e);
                if ("function" == typeof e.next) return e;
                if (!isNaN(e.length)) return r = -1, (t = function t() {
                    for (; ++r < e.length;)
                        if (u.call(e, r)) return t.value = e[r], t.done = !1, t;
                    return t.value = s, t.done = !0, t
                }).next = t
            }
            throw new TypeError(U(e) + " is not iterable")
        }
        return l(_, "constructor", {
            value: v.prototype = b,
            configurable: !0
        }), l(b, "constructor", {
            value: v,
            configurable: !0
        }), v.displayName = o(b, i, "GeneratorFunction"), a.isGeneratorFunction = function(t) {
            t = "function" == typeof t && t.constructor;
            return !!t && (t === v || "GeneratorFunction" === (t.displayName || t.name))
        }, a.mark = function(t) {
            return Object.setPrototypeOf ? Object.setPrototypeOf(t, b) : (t.__proto__ = b, o(t, i, "GeneratorFunction")), t.prototype = Object.create(_), t
        }, a.awrap = function(t) {
            return {
                __await: t
            }
        }, C(w.prototype), o(w.prototype, r, function() {
            return this
        }), a.AsyncIterator = w, a.async = function(t, e, r, n, i) {
            void 0 === i && (i = Promise);
            var o = new w(c(t, e, r, n), i);
            return a.isGeneratorFunction(e) ? o : o.next().then(function(t) {
                return t.done ? t.value : o.next()
            })
        }, C(_), o(_, i, "Generator"), o(_, n, function() {
            return this
        }), o(_, "toString", function() {
            return "[object Generator]"
        }), a.keys = function(t) {
            var e, r = Object(t),
                n = [];
            for (e in r) n.push(e);
            return n.reverse(),
                function t() {
                    for (; n.length;) {
                        var e = n.pop();
                        if (e in r) return t.value = e, t.done = !1, t
                    }
                    return t.done = !0, t
                }
        }, a.values = A, x.prototype = {
            constructor: x,
            reset: function(t) {
                if (this.prev = 0, this.next = 0, this.sent = this._sent = s, this.done = !1, this.delegate = null, this.method = "next", this.arg = s, this.tryEntries.forEach(P), !t)
                    for (var e in this) "t" === e.charAt(0) && u.call(this, e) && !isNaN(+e.slice(1)) && (this[e] = s)
            },
            stop: function() {
                this.done = !0;
                var t = this.tryEntries[0].completion;
                if ("throw" === t.type) throw t.arg;
                return this.rval
            },
            dispatchException: function(r) {
                if (this.done) throw r;
                var n = this;

                function t(t, e) {
                    return o.type = "throw", o.arg = r, n.next = t, e && (n.method = "next", n.arg = s), !!e
                }
                for (var e = this.tryEntries.length - 1; 0 <= e; --e) {
                    var i = this.tryEntries[e],
                        o = i.completion;
                    if ("root" === i.tryLoc) return t("end");
                    if (i.tryLoc <= this.prev) {
                        var a = u.call(i, "catchLoc"),
                            c = u.call(i, "finallyLoc");
                        if (a && c) {
                            if (this.prev < i.catchLoc) return t(i.catchLoc, !0);
                            if (this.prev < i.finallyLoc) return t(i.finallyLoc)
                        } else if (a) {
                            if (this.prev < i.catchLoc) return t(i.catchLoc, !0)
                        } else {
                            if (!c) throw new Error("try statement without catch or finally");
                            if (this.prev < i.finallyLoc) return t(i.finallyLoc)
                        }
                    }
                }
            },
            abrupt: function(t, e) {
                for (var r = this.tryEntries.length - 1; 0 <= r; --r) {
                    var n = this.tryEntries[r];
                    if (n.tryLoc <= this.prev && u.call(n, "finallyLoc") && this.prev < n.finallyLoc) {
                        var i = n;
                        break
                    }
                }
                var o = (i = i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc ? null : i) ? i.completion : {};
                return o.type = t, o.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, g) : this.complete(o)
            },
            complete: function(t, e) {
                if ("throw" === t.type) throw t.arg;
                return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), g
            },
            finish: function(t) {
                for (var e = this.tryEntries.length - 1; 0 <= e; --e) {
                    var r = this.tryEntries[e];
                    if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), P(r), g
                }
            },
            catch: function(t) {
                for (var e = this.tryEntries.length - 1; 0 <= e; --e) {
                    var r, n, i = this.tryEntries[e];
                    if (i.tryLoc === t) return "throw" === (r = i.completion).type && (n = r.arg, P(i)), n
                }
                throw new Error("illegal catch attempt")
            },
            delegateYield: function(t, e, r) {
                return this.delegate = {
                    iterator: A(t),
                    resultName: e,
                    nextLoc: r
                }, "next" === this.method && (this.arg = s), g
            }
        }, a
    }

    function M(t, e, r, n, i, o, a) {
        try {
            var c = t[o](a),
                s = c.value
        } catch (t) {
            return void r(t)
        }
        c.done ? e(s) : Promise.resolve(s).then(n, i)
    }

    function v(c) {
        return function() {
            var t = this,
                a = arguments;
            return new Promise(function(e, r) {
                var n = c.apply(t, a);

                function i(t) {
                    M(n, e, r, i, o, "next", t)
                }

                function o(t) {
                    M(n, e, r, i, o, "throw", t)
                }
                i(void 0)
            })
        }
    }

    function U(t) {
        return (U = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        })(t)
    }
    var t, b = [];
    window.Promise || b.push("Promise"), window.URLSearchParams || b.push("URL"), Element.prototype.closest || b.push("Element.prototype.closest"), Array.from || b.push("Array.from"), Object.assign || b.push("Object.assign"), Object.entries || b.push("Object.entries"), Object.values || b.push("Object.values"), Array.prototype.includes || b.push("Array.prototype.includes");
    try {
        new Event("event")
    } catch (t) {
        b.push("Event")
    }
    try {
        Symbol
    } catch (t) {
        b.push("Symbol")
    }
    b.length && ((t = document.createElement("script")).src = "https://cdnjs.cloudflare.com/polyfill/v3/polyfill.min.js?features=" + b.join(",") + "&flags=gated", t.async = !0, document.head.appendChild(t)), Object.setPrototypeOf = Object.setPrototypeOf || function(t, e) {
        return t.__proto__ = e, t
    };
    var k, z, Z, H, V, W, G = URLSearchParams,
        _ = {
            store: Object.freeze(new function() {
                var r = {
                    store: {
                        skipCartSelector: "[data-ocu-skip-cart]",
                        ocuSelectors: '[name="checkout"], [href^="/checkout"], form[action^="/checkout"] [type="submit"], form[action$="/cart"] [type="submit"], #checkout, [name="goto_pp"], .checkout_button, .checkout-button, [value="Checkout"], .cart-button-checkout, #btn-checkout, .btn__checkout.js-prefill-url, form[action^="/checkout"] .chk_out, form[action^="/cart"] .chk_out, form[action^="/cart"] .cart__checkout, form[action^="/cart"] .ajaxcart__checkout.ajax-cart__button, form[action^="/cart"] .btn-checkout, #rebuy-cart .rebuy-cart__flyout-footer .rebuy-cart__checkout-button, #slidedown-cart .actions .btn.btn-checkout,  #qikify-stickycart-v2-app .qsc2-checkout-button, #nvd-with-checkout-btn, #nvd-without-checkout-btn',
                        onWindowClickSelectors: "#qikify-stickycart-v2-app .qsc2-checkout-button",
                        navidiumSelectors: ["nvd-with-checkout-btn", "nvd-without-checkout-btn"],
                        addToCartButton: '[name="add"]',
                        excludeAddToCartButton: "quick-buy-modal buy-buttons button, .quick-add__button--choose",
                        proxy: "/apps/secure-checkout",
                        lqdCart: "/upsellapp_cart",
                        checkUpsells: "/check_upsells",
                        excludedRequiredFormIds: ["cbb-shipping-rates-calculator-form"],
                        neededCartFileds: ["token", "note", "attributes", "items", "currency", "cart_level_discount_applications"],
                        neededCartItemsFields: ["product_id", "variant_id", "quantity", "grams", "price", "line_price", "title", "properties", "vendor", "sku", "key"],
                        subscriptionProperties: {
                            recharge: ["subscription_id", "shipping_interval_frequency", "shipping_interval_unit_type"],
                            bold: ["frequency_num", "frequency_type"]
                        },
                        customCartIconBubbleSelectors: "[data-cart-item-count], [data-cart-count]:not(form), .cart_count, .cart-count, .header-cart__count--badge, .js-toggle-cart, cart-icon .cart-bubble__text-count",
                        isAddToCartClicked: !1,
                        cartChanged: !1,
                        cartUpdated: !1,
                        requirePayPal: !1,
                        checkoutButtonState: !1,
                        submitted: !1,
                        amazonPayInitiated: !1,
                        salesRocketIntegrationApplied: !1,
                        redirect_url: null,
                        offer: null,
                        offerDeclined: !1,
                        incarts: {},
                        tags: [],
                        isTargetBuyNow: !1,
                        cart_token: null,
                        classList: {
                            buyNow: "shopify-payment-button__button",
                            buyNowBranded: "shopify-payment-button__button--branded",
                            customBuyNowButton: OCUApi.customBuyNowButton
                        },
                        params: {
                            str: "",
                            arr: []
                        },
                        fallback: {
                            timeout: 15e3,
                            id: 0
                        },
                        XHR: {
                            send: XMLHttpRequest.prototype.send
                        },
                        checkoutButton: {
                            selector: "[data-ocu-checkout]",
                            excludes: {
                                tagName: /^P$/,
                                id: /^ProceedToCheckout(Top|Bottom)$/
                            }
                        },
                        cartDrawerControl: {
                            selector: '[data-action="close-drawer"][data-drawer-id="sidebar-cart"], #CartDrawer .drawer__close-button, #CartDrawer .js-drawer-close'
                        },
                        cartDrawerSalesRocketControl: {
                            selector: "#cartSlider-shopper .ws-cs-close"
                        },
                        cartDrawerTimberControl: {
                            selector: "#CartDrawer .js-drawer-close button"
                        },
                        chatButton: {
                            selector: "#shopify-chat"
                        },
                        termsOfServiceCheckbox: {
                            selector: ".cart__terms-checkbox"
                        },
                        productLocation: {
                            variant_id: null,
                            product_id: null
                        },
                        extraClassListToRemove: ["hulkapps_submit_cart"],
                        shopPayInstallments: {
                            id: "shop-pay-button-link",
                            parent: "#shopify-payment-terms-modal shop-pay-button",
                            query: "payment=shop_pay_installments&source=installments_modal&source_token",
                            checkoutUrl: "/checkout?payment=shop_pay_installments&source=installments_modal&source_token",
                            attr: {
                                variant: "variants",
                                token: "source-token"
                            }
                        },
                        pagesIntegrationData: {},
                        productPageWidget: {},
                        widgetHandled: !1,
                        widgetDiscounts: {},
                        incartDiscounts: {},
                        publicEvents: {
                            ocuDiscounts: "ocu:discounts",
                            cartUpdated: "ocu:cart:updated",
                            cartChanging: "ocu:cart:changing",
                            cartOpen: "ocu:cart:open"
                        },
                        sealSellingPlanPrice: null,
                        removed_free_shipping: !1,
                        offerCustomRedirectOptions: {
                            clickedItem: null,
                            location: null,
                            itemList: {
                                acceptButton: "acceptButton",
                                declineButton: "declineButton",
                                crossButton: "crossButton",
                                background: "background"
                            },
                            locationList: {
                                default: null,
                                cart: "cart",
                                checkout: "checkout",
                                samePage: "stay_on_the_same_page"
                            }
                        },
                        clientId: null
                    },
                    event: function(t) {
                        return new Event("store:" + t)
                    },
                    emit: function(t) {
                        document.dispatchEvent(this.event(t))
                    }
                };
                this.get = function(t) {
                    return r.store[t]
                }, this.set = function(t, e) {
                    if (!r.store.hasOwnProperty(t)) return console.error("Unavailable key! ", t);
                    r.emit(t), r.store[t] = e
                }, this.listen = function(e) {
                    return new Promise(function(t) {
                        document.addEventListener("store:" + e, t)
                    })
                }
            }),
            cookie: {
                options: {
                    expires: 86400,
                    path: "/",
                    encodeValue: !1
                },
                get: function(t) {
                    t = document.cookie.match(new RegExp("(?:^|; )" + t.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, "\\$1") + "=([^;]*)"));
                    return t ? decodeURIComponent(t[1]) : void 0
                },
                set: function(t, e, r) {
                    var n, i, o = (r = r || this.options).expires,
                        a = ("number" == typeof o && o && ((n = new Date).setTime(n.getTime() + 1e3 * o), o = r.expires = n), o && o.toUTCString && (r.expires = o.toUTCString()), t + "=" + (e = encodeURIComponent(e)));
                    for (i in r) {
                        a += "; " + i;
                        var c = r[i];
                        !0 !== c && (a += "=" + c)
                    }
                    document.cookie = a
                },
                remove: function(t) {
                    this.set(t, null, {
                        expires: -1
                    })
                }
            },
            queryParams: function(t) {
                var r = {};
                return t.replace("?", "").split("&").forEach(function(t) {
                    var e = t.split("=")[0],
                        t = t.split("=")[1];
                    r[e] = decodeURIComponent(t)
                }), r
            },
            shareableDiscount: function(t) {
                t = t || {};
                var e = _.queryParams(location.search)[t.key || "discount"];
                e && (_.cookie.set(t.name || "ocu-share-discount", e, _.cookie.options), t.clear) && history.pushState(null, null, location.href.replace(/\?.+/, ""))
            },
            serializeForm: function(t) {
                return new G(new FormData(t).fd || new FormData(t)).toString()
            },
            serializeFormEdge: function(t) {
                var e, r = [];
                if ("object" == U(t) && "FORM" == t.nodeName) {
                    var n = t.elements.length;
                    for (i = 0; i < n; i++)
                        if ((e = t.elements[i]).name && !e.disabled && "file" != e.type && "reset" != e.type && "submit" != e.type && "button" != e.type)
                            if ("select-multiple" == e.type)
                                for (j = t.elements[i].options.length - 1; 0 <= j; j--) e.options[j].selected && (r[r.length] = encodeURIComponent(e.name) + "=" + encodeURIComponent(e.options[j].value));
                            else("checkbox" != e.type && "radio" != e.type || e.checked) && (r[r.length] = encodeURIComponent(e.name) + "=" + encodeURIComponent(e.value))
                }
                return r.join("&").replace(/%20/g, "+")
            },
            serialize: function(n, i, o, a) {
                var t;
                return this.helpers.isFormData(i) && (a = o, o = i, i = null), (i = i || {}).indices = i.indices || !1, o = o || new G, this.helpers.isUndefined(n) || (this.helpers.isNull(n) ? o.append(a, "") : this.helpers.isArray(n) ? n.length ? n.forEach(function(t, e) {
                    var r = "object" == U(t),
                        r = a + "[" + (i.indices && r ? e : "") + "]";
                    this.serialize(t, i, o, r)
                }.bind(this)) : (t = a + "[]", o.append(t, "")) : this.helpers.isDate(n) ? o.append(a, n.toISOString()) : !this.helpers.isObject(n) || this.helpers.isFile(n) || this.helpers.isBlob(n) ? o.append(a, n) : Object.keys(n).forEach(function(t) {
                    var e = n[t];
                    if (this.helpers.isArray(e))
                        for (; 2 < t.length && t.lastIndexOf("[]") === t.length - 2;) t = t.substring(0, t.length - 2);
                    var r = a ? a + "[" + t + "]" : t;
                    this.serialize(e, i, o, r)
                }.bind(this))), o
            },
            inArray: function(t, e, r) {
                return t.some(function(t) {
                    return t[e] === r
                })
            },
            filterObject: function(r, t) {
                return t.reduce(function(t, e) {
                    return t[e] = r[e], t
                }, {})
            },
            helpers: {
                isUndefined: function(t) {
                    return void 0 === t
                },
                isNull: function(t) {
                    return null === t
                },
                isObject: function(t) {
                    return t === Object(t)
                },
                isArray: function(t) {
                    return Array.isArray(t)
                },
                isDate: function(t) {
                    return t instanceof Date
                },
                isBlob: function(t) {
                    return t && "number" == typeof t.size && "string" == typeof t.type && "function" == typeof t.slice
                },
                isFile: function(t) {
                    return this.isBlob(t) && ("object" == U(t.lastModifiedDate) || "number" == typeof t.lastModified) && "string" == typeof t.name
                },
                isFormData: function(t) {
                    return t instanceof FormData
                }
            }
        },
        C = (Zipify.OCU.PrecheckoutIntegrations = function(t) {
            this.cartItems = t
        }, window.OCUIncart = window.OCUIncart || {}, window.OCUIncart.integrations = function(t) {
            return new Zipify.OCU.PrecheckoutIntegrations(t)
        }, Zipify.OCU.PrecheckoutIntegrations.prototype = {
            get advancedProductOptions() {
                var t = this.cartItems;
                return {
                    get present() {
                        return !!window.mwProductOptions
                    },
                    get relations() {
                        return t.reduce(function(t, e) {
                            return e.properties && e.properties._mw_option_relation && t.push(+e.properties._mw_option_relation.split("_")[0]), t
                        }, [])
                    }
                }
            },
            get zapiet() {
                return {
                    get present() {
                        return !(!window.Zapiet || !document.querySelector("#storePickupApp"))
                    },
                    get params() {
                        var t = Zapiet.Cart && Zapiet.Cart.getUrlParams() || {};
                        return Object.entries(t).reduce(function(t, e) {
                            var r;
                            return /^\s*$/.test(e[1]) || ((r = {})[e[0]] = e[1], t.push(r)), t
                        }, [])
                    },
                    merge: function(t) {
                        return (t || []).concat(this.params)
                    }
                }
            },
            get simpleInStorePickup() {
                return {
                    get present() {
                        var t = document.querySelector("#in-store-pick-up");
                        return t && t.checked
                    },
                    get params() {
                        var t, e = document.querySelector('form[action^="/cart"]');
                        return e ? (t = (e = e.action.split(/\?|&/)).slice(7).slice(0, 3), e = e.slice(-6), t.concat(e).reduce(function(t, e) {
                            var e = e.split("="),
                                r = {};
                            return r[e[0]] = decodeURIComponent(e[1]), t.push(r), t
                        }, [])) : []
                    },
                    merge: function(t) {
                        return (t || []).concat(this.params)
                    }
                }
            },
            get weglot() {
                return {
                    get present() {
                        return !!window.Weglot ? .initialized
                    },
                    get params() {
                        return [{
                            locale: window.Weglot.getCurrentLang()
                        }]
                    },
                    merge: function(t) {
                        return (t || []).concat(this.params)
                    }
                }
            },
            get bt() {
                return {
                    get present() {
                        return !(!window.BT || !window.$)
                    },
                    get addToCartBtn() {
                        return document.querySelector('button[name="add"]')
                    },
                    startLoadingBtn: function() {
                        BT.startLoadingBtn($(this.addToCartBtn))
                    },
                    endLoadingBtn: function() {
                        BT.endLoadingBtn($(this.addToCartBtn))
                    }
                }
            },
            get exemptify() {
                return {
                    get present() {
                        var t = document.querySelector('[name="checkout-exemptify"]'),
                            e = document.querySelectorAll("[data-ocu-checkout]");
                        return !!t && 1 < e.length
                    }
                }
            },
            get tidio() {
                return {
                    stateStorageKey: null,
                    selector: {
                        main: 'script[src*="code.tidio.co"]',
                        fallback: 'script[src*="code.tidio"],script[src*="code"][src*="tidio"],script[src*="uploads/redirect"][src*="tidio"]'
                    },
                    get present() {
                        return !!window.tidioChatApi
                    },
                    get storageKey() {
                        return this.stateStorageKey || (this.stateStorageKey = "tidio_state_" + (this.publickey || "preview"))
                    },
                    get publickey() {
                        var t = (t = document.querySelector(this.selector.main)) || document.querySelector(this.selector.fallback),
                            t = /([a-z0-9]+)(\.js|$)/g.exec(t.src);
                        if (t && 32 === t[1].length) return t[1]
                    },
                    saveKeyToStorage: function(t, e) {
                        e = JSON.stringify(e);
                        localStorage.setItem(this.storageKey + "_" + t, e)
                    },
                    trackEvent: function(t, e) {
                        window.tidioChatApi.track("shopify." + t, {}, e || function() {})
                    },
                    track: function() {
                        try {
                            this.saveKeyToStorage("goToCheckout", !0), this.trackEvent("go_to_checkout")
                        } catch (t) {
                            console.log("tidio integration error", t.message)
                        }
                    }
                }
            },
            get salesRocket() {
                return {
                    get present() {
                        return !!window.SalesRocket
                    },
                    setup: function() {
                        if (this.present && !_.store.get("salesRocketIntegrationApplied")) try {
                            document.querySelector(".ws-cs-checkout-btn").setAttribute("name", "checkout"), _.store.set("salesRocketIntegrationApplied", !0)
                        } catch (t) {
                            console.error("salesRocketIntegrationError", t), _.store.set("salesRocketIntegrationApplied", !1)
                        }
                    }
                }
            },
            get bundlerBuilder() {
                return {
                    selector: "/apps/bundles",
                    get bundleBuilderInput() {
                        return document.querySelector("#bb_proxy_prefix")
                    },
                    get present() {
                        return this.bundleBuilderInput && this.bundleBuilderInput.value === this.selector && this.bundlerForm && !!this.bundlerForm.querySelector('[formaction="'.concat(this.selector, '/cart"]'))
                    },
                    get bundlerForm() {
                        return this.bundleBuilderInput.closest('form[action*="'.concat(this.selector, '"]'))
                    },
                    submit: function() {
                        this.bundlerForm.submit()
                    }
                }
            },
            get minMaxify() {
                return {
                    get present() {
                        return !!window.minMaxify
                    },
                    get isFunction() {
                        return minMaxify.checkLimits instanceof Function
                    },
                    get invalid() {
                        return this.present && this.isFunction && !minMaxify.checkLimits()
                    }
                }
            },
            get navidiumShippingProtection() {
                return {
                    get checked() {
                        return "on" === localStorage.getItem("nvdStatus")
                    },
                    get isAppExist() {
                        return null !== localStorage.getItem("nvd_variant") && null !== localStorage.getItem("nvdProductVariants")
                    },
                    addProduct: (t = v(S().mark(function t() {
                        var e, r, n;
                        return S().wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if (this.checked) {
                                        t.next = 2;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 2:
                                    if (e = localStorage.getItem("nvd_variant"), r = JSON.parse(localStorage.getItem("nvdProductVariants")), r = r ? .find(function(t) {
                                            return t.id === Number(e)
                                        }), OCUApi.navidiumAddProtection) return t.next = 8, OCUApi.navidiumAddProtection(r);
                                    t.next = 10;
                                    break;
                                case 8:
                                    t.next = 13;
                                    break;
                                case 10:
                                    return n = JSON.stringify({
                                        items: [{
                                            id: r.id,
                                            quantity: 1
                                        }]
                                    }), t.next = 13, OCUApi.axios.post("".concat(OCUApi.shopifyRoot, "cart/add.js"), n, {
                                        headers: {
                                            "Content-Type": "application/json"
                                        }
                                    });
                                case 13:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    })), function() {
                        return t.apply(this, arguments)
                    })
                };
                var t
            },
            stickyATC: function(t) {
                return {
                    selectors: {
                        atc: "[data-sticky-addtocart] [data-action-atc]",
                        quantity: "[data-sticky-addtocart] [data-quantity-wrapper] [data-quantity-value]"
                    },
                    get present() {
                        return !!this.id
                    },
                    get button() {
                        return t ? .closest(this.selectors.atc)
                    },
                    get id() {
                        return this.button ? .dataset.variantId
                    },
                    get quantity() {
                        return t ? .closest(this.selectors.quantity) ? .value ? ? 1
                    },
                    get payload() {
                        return {
                            id: this.id,
                            quantity: this.quantity
                        }
                    }
                }
            },
            cartWithShadowRoot: function(e) {
                try {
                    var r = [{
                        name: "Upcart",
                        container: "#upCart",
                        target: 'a[href*="/checkout"]'
                    }].find(function(t) {
                        return e.target ? .closest(t.container)
                    }).target;
                    return e.composedPath().find(function(t) {
                        return t.matches(r)
                    })
                } catch (t) {
                    return null
                }
            }
        }, window.OCUApi || (window.OCUApi = {
            customCheckoutButton: null,
            customBuyNowButton: null,
            customAddToCartButton: null,
            customSkipCart: !1,
            customAddToCartEventHandler: null,
            customAddToCartForm: null,
            customAddToCartEvent: null,
            customAddToCartFetch: null,
            customButtonLoader: null,
            customCheckoutForm: null,
            customCheckoutDuplicatedForm: null,
            getCustomAddToCartData: null,
            preventReloadOnNavigate: !1,
            preventReloadPersistedPage: !1,
            customLineItemAttributes: null,
            excludeActionButton: null,
            excludeUpdateElement: null,
            originFetch: null,
            customCartDrawerCloseButton: null,
            axios: null,
            customQuantityInput: null,
            refreshCart: null,
            isWindowLocationForClickListener: null,
            listenFormEvents: null,
            isFormInvalid: !1,
            customFormValidate: null,
            callbackBeforeRedirect: null,
            callbackAfterNativeClick: null,
            cartDiscountSelectors: null,
            forceRenderDiscounts: null,
            dualPricing: null,
            customRechargeUrl: null,
            productLocationOnly: !1,
            isButtonDisabledAfterClick: !1,
            fireAddToCartEvent: null,
            preventEventBeforeNativeClick: !1,
            enableCollectionLocation: !1,
            enableCustomPages: null,
            customPageName: null,
            beforeCreate: null,
            popupWasShown: null,
            product: null,
            cart: null,
            resetCartCache: !1,
            shopPayDraftOrder: !1,
            navidiumAddProtection: null,
            moneyFormat: null,
            customAllowUpsellsValidation: null,
            preventRestoreXMLHttp: !1,
            customUpdateCart: null,
            customShippingInsurance: {
                enabled: !1,
                price: 0
            },
            getCustomProductId: null,
            customSkipCartZPEventHandler: null,
            widget: {
                customProceedAccept: null
            },
            loadScriptsOnWindowLoad: !1,
            currencyCode: null,
            customCheckoutRedirect: null,
            customCartIconBubbleSelectorParams: {
                customBubbleSelectors: null,
                customBubbleHiddenClass: null
            },
            customOpenThemeCartDrawerHandler: null,
            customStaticCartToken: null
        }), OCUApi.store = _.store, OCUApi.documentationReference = "https://github.com/ZipifyApps/ocu/wiki/Public-API", OCUApi.customCheckoutButton && (OCUApi.customCheckoutButton = ", ".concat(OCUApi.customCheckoutButton)), OCUApi.customQuantityInput && (OCUApi.customQuantityInput = ", ".concat(OCUApi.customQuantityInput)), OCUApi.callbackBeforeRedirect || (OCUApi.callbackBeforeRedirect = function() {
            return Promise.resolve({})
        }), {
            redirect_url: null
        });

    function X() {}
    window.OCUApi = Object.assign(OCUApi, {
        get shopifyRoot() {
            return window.Shopify ? .routes ? .root ? ? "/"
        },
        updateLqdCart: (W = v(S().mark(function t() {
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.prev = 0, t.next = 3, fetch("".concat(this.shopifyRoot, "cart.js")).then(function(t) {
                            return t.json()
                        });
                    case 3:
                        Zipify.OCU.lqd.cart = t.sent, t.next = 9;
                        break;
                    case 6:
                        t.prev = 6, t.t0 = t.catch(0), console.log("Error while updating lqd cart");
                    case 9:
                    case "end":
                        return t.stop()
                }
            }, t, this, [
                [0, 6]
            ])
        })), function() {
            return W.apply(this, arguments)
        }),
        showUpsell: function(a) {
            var c = this,
                s = this.context.popupDispatcher,
                u = this.context.integrations.zipifyPages;
            return s.context = this.context, s.target = a.form, new Promise(function() {
                var e = v(S().mark(function t(e) {
                    var r, n, i, o;
                    return S().wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (s.popupAccepted || "once" === OCUIncart.settings.popup_frequency && _.cookie.get("ocu_popup_token")) return t.abrupt("return", e(C));
                                t.next = 3;
                                break;
                            case 3:
                                return t.next = 5, c.updateLqdCart();
                            case 5:
                                if (r = function(t) {
                                        s._upsellAppInstance() && s._upsellAppInstance().hide(), u.clear();
                                        if (a.customCallback) return a.customCallback(s, t, "customCallback");
                                        e((t = t.detail.response || C, g({
                                            skip_cart: f.skip_cart
                                        }, t)))
                                    }, n = a.blockId, o = a.products, u.setProducts(o), u.setBlockId(n), u.isLandingPage && (Zipify.OCU.lqd.product = u.getProductFromForm(a.form)), (i = c.context.integrations.widget).isWidgetPresent()) return i.disable(!0), t.next = 15, i.proceed().then(v(S().mark(function t() {
                                    return S().wrap(function(t) {
                                        for (;;) switch (t.prev = t.next) {
                                            case 0:
                                                return t.next = 2, i.accept();
                                            case 2:
                                                return t.abrupt("return", t.sent);
                                            case 3:
                                            case "end":
                                                return t.stop()
                                        }
                                    }, t)
                                }))).finally(function() {
                                    i.clearState(), i.disable(!1)
                                });
                                t.next = 15;
                                break;
                            case 15:
                                if (u.isBlockOutsideProductPage()) return t.abrupt("return", u.handleZPOutsidePage(c.context, r));
                                t.next = 17;
                                break;
                            case 17:
                                if (o = u.isZipifyEntity() && u.isAcceptableZPLocation(), s.isProductAction || u.isLandingPage || o) {
                                    t.next = 21;
                                    break
                                }
                                return u.clear(), t.abrupt("return", e(C));
                            case 21:
                                s.listenCustomEvent(r), s._show(null, !0);
                            case 23:
                            case "end":
                                return t.stop()
                        }
                    }, t)
                }));
                return function(t) {
                    return e.apply(this, arguments)
                }
            }())
        },
        getProductPageWidgetConfig: (V = v(S().mark(function t(e) {
            var r, n, i, o, a, c, s, u, l, p, d, h;
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return r = "/product_page/v1/offers/appropriate", n = window.OCUIncart && OCUIncart.appEndpoint, i = {
                            "Content-Type": "application/json",
                            "Shop-Domain": f.permanent_domain
                        }, o = _.cookie.get("ocu_widget_ids"), a = f.cart.token || _.cookie.get("cart") ? .replace(/\?.+/, ""), Zipify.OCU.api.context.popupDispatcher.context = Zipify.OCU.api.context, t.next = 8, Zipify.OCU.api.context.popupDispatcher.verifyToken();
                    case 8:
                        return t.next = 10, Zipify.OCU.api.context.cart.createToken();
                    case 10:
                        if ((c = t.sent) && c.data && (a = c.data.token ? .replace(/\?.+/, "")), c = f.product, s = c ? .variants.find(function(t) {
                                return t.available
                            }) ? .id, u = c ? .variants.find(function(t) {
                                return t.id === s && t.available
                            }), (l = u || c) && l.available) {
                            t.next = 18;
                            break
                        }
                        return t.abrupt("return", {
                            data: {
                                error: "Unavaliable product"
                            }
                        });
                    case 18:
                        if (l = c.options.map(function(t, e) {
                                return {
                                    name: t,
                                    value: u.options[e]
                                }
                            }), h = {
                                variant_id: s,
                                product_id: c.id,
                                price: c.price,
                                handle: c.handle,
                                title: c.title,
                                quantity: 1,
                                is_product_location: !0,
                                options_with_values: l
                            }, p = c.available || u, p && !Number.isNaN(s) || (h = null), p = e.getCartItems((this.actualCart || f.cart).items).line_items, h && p.push(h), h = _.store.get("clientId"), p = {
                                line_items: p,
                                cart_token: a,
                                customer_tags: f.customer_tags || [],
                                currency: e.currencyRate(),
                                location: "product",
                                customer_location: OCUIncart.customer_location ? .handle,
                                snippet_version: OCUIncart.version,
                                appropriate_type: "on_page_1",
                                client_id: h
                            }, e.validateAppropriate(p)) return t.abrupt("return");
                        t.next = 29;
                        break;
                    case 29:
                        return o && (r += "?split_test_weight=".concat(o)), t.prev = 30, t.next = 33, OCUApi.axios.post(n + r, p, {
                            headers: i
                        });
                    case 33:
                        if (d = t.sent, h = d ? .data ? .discount_data) return t.next = 38, OCUApi.handleAutomaticDiscounts(OCUIncart.cart_items, h);
                        t.next = 38;
                        break;
                    case 38:
                        return Zipify.OCU.api.context.integrations.widget.listenEvents(d.data), t.abrupt("return", d);
                    case 42:
                        return t.prev = 42, t.t0 = t.catch(30), console.log(t.t0), t.abrupt("return", t.t0);
                    case 46:
                    case "end":
                        return t.stop()
                }
            }, t, this, [
                [30, 42]
            ])
        })), function(t) {
            return V.apply(this, arguments)
        }),
        _updatePropertiesProcessing: {},
        updateProperties: (H = v(S().mark(function t(e) {
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        if (this._updatePropertiesProcessing[e.id]) return t.abrupt("return", !0);
                        t.next = 2;
                        break;
                    case 2:
                        return this._updatePropertiesProcessing[e.id] = !0, t.next = 5, OCUApi.axios.post("".concat(this.shopifyRoot, "cart/change.js?ocu"), e, {
                            headers: {
                                "Content-Type": "application/json"
                            }
                        });
                    case 5:
                        delete this._updatePropertiesProcessing[e.id];
                    case 6:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        })), function(t) {
            return H.apply(this, arguments)
        }),
        updateCartDetails: (Z = v(S().mark(function t(e) {
            var r, n = this;
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        r = this.context.integrations.helpers;
                        try {
                            r.withLock(v(S().mark(function t() {
                                return S().wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return t.next = 2, OCUApi.axios.post("".concat(n.shopifyRoot, "cart/update.js?ocu"), e, {
                                                headers: {
                                                    "Content-Type": "application/json"
                                                }
                                            });
                                        case 2:
                                        case "end":
                                            return t.stop()
                                    }
                                }, t)
                            })))
                        } catch (t) {
                            console.log(t)
                        }
                    case 2:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        })), function(t) {
            return Z.apply(this, arguments)
        }),
        handleAutomaticDiscounts: (z = v(S().mark(function t(e, r) {
            var n, i, o, a, c, s, u, l, p, d;
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return n = [], t.prev = 1, t.next = 4, fetch("".concat(this.shopifyRoot, "cart.js?ocu"));
                    case 4:
                        return t.next = 6, t.sent.json();
                    case 6:
                        n = t.sent.items, t.next = 12;
                        break;
                    case 9:
                        t.prev = 9, t.t0 = t.catch(1), n = e;
                    case 12:
                        i = h(n), t.prev = 13, i.s();
                    case 15:
                        if ((o = i.n()).done) {
                            t.next = 36;
                            break
                        }
                        if (o = o.value, a = o.properties ? ._ocu_offer_data, c = o.properties ? ._ocu_offer_reference_id, s = o.key ? ? o.variant_id ? .toString(), c) {
                            t.next = 22;
                            break
                        }
                        return t.abrupt("continue", 34);
                    case 22:
                        if (u = {
                                id: s,
                                properties: o.properties,
                                quantity: o.quantity
                            }, l = {
                                ocu: {
                                    _ocu_offer_data: r ? .ocu ? .[c] ? ? null
                                }
                            }, t.t1 = a && !l.ocu._ocu_offer_data || !a && l.ocu._ocu_offer_data, (p = {
                                get none() {
                                    return !this.ocu
                                },
                                ocu: t.t1
                            }).ocu && (u.properties = g(g({}, u.properties), l.ocu)), p.none) return t.abrupt("continue", 34);
                        t.next = 29;
                        break;
                    case 29:
                        return l = _.store.get("publicEvents"), p = l.cartChanging, d = l.ocuDiscounts, dispatchEvent(new CustomEvent(p)), t.next = 33, OCUApi.updateProperties(u);
                    case 33:
                        dispatchEvent(new CustomEvent(d));
                    case 34:
                        t.next = 15;
                        break;
                    case 36:
                        t.next = 41;
                        break;
                    case 38:
                        t.prev = 38, t.t2 = t.catch(13), i.e(t.t2);
                    case 41:
                        return t.prev = 41, i.f(), t.finish(41);
                    case 44:
                    case "end":
                        return t.stop()
                }
            }, t, this, [
                [1, 9],
                [13, 38, 41, 44]
            ])
        })), function(t, e) {
            return z.apply(this, arguments)
        }),
        getAnonymousUserToken: function() {
            function n() {
                try {
                    if (Shopify.customerPrivacy.userCanBeTracked()) return ShopifyAnalytics.lib.user().traits().uniqToken
                } catch (t) {
                    return null
                }
            }
            return new Promise(function(e) {
                try {
                    var t = n();
                    if (t) return e(t);
                    var r = setTimeout(function() {
                        e(null)
                    }, 1e4);
                    window.Shopify.loadFeatures([{
                        name: "consent-tracking-api",
                        version: "0.1"
                    }], function(t) {
                        clearTimeout(r), e(t ? null : n())
                    })
                } catch (t) {
                    e(null)
                }
            })
        },
        initialize: function(t) {
            this.context = t.context
        },
        onAccept: function() {},
        onDecline: function() {},
        onPopupIsNotShown: function() {}
    });

    function J(t, e) {
        return this.addEventListener("load", function(t) {
            P.shouldCartRequest(this._url) && "blob" !== this.responseType ? P.proceedDiscounts({
                data: JSON.parse(this.responseText)
            }, !0) : !["/cart/add.js?ocu", "/cart/change.js?prevent"].includes(this._url) && P.doesUrlMatch(this._url) && O.get("?ocu").then(function(t) {
                P.proceedDiscounts(t, !0)
            }), OCUApi.customLineItemAttributes && setTimeout(function() {
                return P.removePrivateAttributes(OCUApi.customLineItemAttributes)
            })
        }), window.simplyInsurance && (this._url = e), ct.apply(this, arguments)
    }
    var K, Q, Y, tt, et, rt, nt, it, ot, at, w = ["product", "collection", "index", "page"],
        b = (X.prototype = {
            proceed: function(t, e, r) {
                this.context = r, this.target = e, this.event = t, this.appropriateResponse = null, this.triggerProduct = null, this.actualCart = null, this.customEventsBinded || = !1, this.customEventsBinded || this.listenCustomEvent(), this.bt = OCUIncart.integrations().bt, this.isBuyNow = r.helpers.isBuyNow(t), this.shopPayInstallments = r.helpers.isShopPayInstallments(t), this.permalinkType = e.href ? r.helpers.getPermalinkType(e.href) : null, (OCUApi.customButtonLoader ? .(this.event)) ? .startLoading();
                r = this.isProductLocationOption(e) && "cart" === f.template_name;
                return OCUIncart._is_product_action = this.isProductAction, (!t.isTrusted && this.secondAttempt || r || this.context.helpers.isDisabledButton(this.event.target) || this.context.helpers.termsOfServiceConfirmation(this.event.target)) && !this.ignoreTrust ? this._clearFlow() : this.isProductLocationOption(e) ? this.productLocation(t, e) : (this.context.prevent(t, "immediate"), this.check(t, e))
            },
            check: function(r, n) {
                var i = this.context;
                return i.cart.get("?ocu").then(i.cart.update).then(function(t) {
                    OCUIncart.cart_items = t.data.items || t.data.cart.items, f.cart = t.data.items ? t.data : t.data.cart;
                    try {
                        var e = i.helpers.isSubscriptionProductInCart(f.cart);
                        if (e && this.isProductAction) return this.nativeClick();
                        if (e) return i.integrations[e].redirect(r, f.cart)
                    } catch (t) {
                        return this.checkout()
                    }
                    if (!_.cookie.get("ocu_shown_popup")) return this.show(r, n);
                    this.checkout()
                }.bind(this)).catch(this.checkout.bind(this))
            },
            show: function(t, e) {
                return this.context.prevent(t), _.store.get("amazonPayInitiated") ? null : !(e = e.closest('[action="/cart"], [action="/checkout"]')) || e.hasAttribute("novalidate") || this.context.validate(e) ? (window.disableBodyScroll && disableBodyScroll(), this._show(t, !1)) : (clearTimeout(_.store.get("fallback").id), _.store.set("submitted", !1), e.reportValidity())
            },
            _show: function(e, r) {
                var n, i, t, o, a = this,
                    c = (this.apiMode = r, f.product),
                    s = this.context.integrations.zipifyPages;
                return this.isAcceptableAction("collection") && "collection" === f.template_name && "zp_collection" !== s.zpLocation() && !s.isZipifyEntity() && (t = OCUApi.customAddToCartForm ? ? 'form[action*="/cart/add"]', n = +((OCUApi.getCustomAddToCartData ? .()) ? .id ? ? e.target.closest(t) ? .id ? .value), c = f.collectionProducts.find(function(t) {
                    return t.variants.find(function(t) {
                        return t.id === n
                    })
                })), s.isZipifyEntity() && !s.isAcceptableZPLocation() && "cart" !== this.targetAction ? this._finalizeEvent() : !this.isAcceptableAction(this.targetAction) && "cart" !== this.targetAction && f.isSkipCartCondition ? this.nativeClick() : (i = this.context, t = f.integrate_with_recharge && !f.disabled_by_subscription_app, o = {
                    utils: _,
                    Updater: D,
                    is_recharge_enabled: t,
                    is_skip_cart: f.skip_cart,
                    product: c,
                    integrations: {
                        zipifyPages: i.integrations.zipifyPages
                    }
                }, this[this.appropriateResponse ? "_emptyResolve" : "getIncartConfig"](this.appropriateResponse).then(function(t) {
                    if ("skip" === t) throw new Error("There are no appropriate funnels");
                    window.OCUIncart.preLoad && window.OCUIncart.preLoad.showLoader(), i.helpers.beforeCreate(), _.store.set("isTargetBuyNow", i.helpers.isBuyNow(e)), this.kind = t.data.kind, o.config = t.data, o.customer_tags = f.customer_tags || [], o.customer_location = OCUIncart.customer_location.handle, o.config._ocu_offer_reference_ids = o.config._ocu_offer_reference_ids ? .filter(Boolean) ? ? [];
                    t = f.skip_cart || this.apiMode;
                    return o.product && !t && (o.product = Object.assign({}, o.product, {
                        quantity: this._quantityOfProduct,
                        selectedPageProduct: this._selectedVariant(o.product.variants)
                    })), i.utils.beforePrecheckoutPopup(), OCUIncart._is_product_action = this.isProductAction, this._upsellAppInstance().setData(o)
                }.bind(this)).catch(function(t) {
                    if (t instanceof Error && console.error(t), OCUApi.onPopupIsNotShown(), "The product is sold out" === t) return a._finalizeEvent();
                    a[r ? "_finalizeEvent" : "checkout"].bind(a)(t)
                }))
            },
            handleErrorResponse: function() {
                return this.apiMode || this.nativeClick(), this._emptyResolve("skip")
            },
            getIncartConfig: (ot = v(S().mark(function t() {
                var e, r, n, i, o, a, c, s, u;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return e = "/pre_purchase/v2/checkout_offers/appropriate?", r = window.OCUIncart && OCUIncart.appEndpoint, n = {
                                "Content-Type": "application/json",
                                "Shop-Domain": f.permanent_domain
                            }, i = this.context, o = this.actualCart || f.cart, c = i.helpers.isSameCart(o), a = i.helpers.isSameCartToken(o), (c || a) && a || _.cookie.remove("ocu_popup_ids"), (c = _.cookie.get("ocu_popup_ids")) && (e += "split_test_weight=" + c), t.prev = 10, this.apiMode || (OCUApi.customButtonLoader ? .(this.event)) ? .endLoading(), t.next = 14, this.prefetchProduct();
                        case 14:
                            if (this.isHCAction && !this._isAcceptableProduct()) return t.next = 17, this._getHCProduct();
                            t.next = 18;
                            break;
                        case 17:
                            f.product = t.sent;
                        case 18:
                            return t.next = 20, this._incartPayload();
                        case 20:
                            if (s = t.sent) {
                                t.next = 24;
                                break
                            }
                            return console.log("Payload is empty"), t.abrupt("return", "skip");
                        case 24:
                            if (i.helpers.validateAppropriate(s)) return t.abrupt("return", this.handleErrorResponse());
                            t.next = 26;
                            break;
                        case 26:
                            return t.next = 28, OCUApi.axios.post(r + e, s, {
                                headers: n
                            });
                        case 28:
                            if ((u = t.sent).data.error) {
                                if (console.error("OCU Error:", u.data.error), this.context.helpers.hasWidgetItem(o.items) && this.isBuyNow) return this.context.prevent(this.event), new L(this.event, this.context.integrations.widget), t.abrupt("return", "skip");
                                t.next = 35
                            } else t.next = 36;
                            break;
                        case 35:
                            return t.abrupt("return", this.handleErrorResponse());
                        case 36:
                            return t.abrupt("return", {
                                data: u.data.context
                            });
                        case 39:
                            return t.prev = 39, t.t0 = t.catch(10), console.log(t.t0.message), t.abrupt("return", this.handleErrorResponse());
                        case 43:
                        case "end":
                            return t.stop()
                    }
                }, t, this, [
                    [10, 39]
                ])
            })), function() {
                return ot.apply(this, arguments)
            }),
            checkout: (it = v(S().mark(function t(e) {
                var r, n, i, o, a, c, s, u, l, p, d, h;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            if (this.context) {
                                t.next = 2;
                                break
                            }
                            return t.abrupt("return", console.log("Error: lost context"));
                        case 2:
                            if (OCUApi.customCheckoutRedirect) return t.abrupt("return", OCUApi.customCheckoutRedirect(e));
                            t.next = 4;
                            break;
                        case 4:
                            return t.next = 6, this.handleCustomRedirectOption();
                        case 6:
                            if (t.sent) return this.resetCustomRedirectOptions(), this._upsellAppInstance().hide(e), window.OCUIncart ? .preLoad ? .hideLoader(), _.store.set("submitted", !1), t.abrupt("return");
                            t.next = 13;
                            break;
                        case 13:
                            if (r = e && "ocuNativeClick" === e.type, n = e && "productUnavailable" === e.error, i = this.context.helpers.hasWidgetItem(this.actualCart ? .items || f.cart.items), o = e && !e.detail ? .response ? .accepted && !i && this.isBuyNow, u = e ? .detail ? ? {}, a = u.event_type, u = u.offer_type, i && this.isBuyNow && "decline" === a && "Upgrade" === u) return t.abrupt("return", new L(this.event, this.context.integrations.widget));
                            t.next = 20;
                            break;
                        case 20:
                            if (e && !r && (e.response ? console.error(e.response.data.message) : console.error(e)), a = e ? .detail ? .type || e ? .detail ? .event_type, c = r && "Upgrade" !== a, s = this.isProductAction && (!this.isBuyNow || o) && c && !f.skip_cart, (OCUApi.customButtonLoader ? .(this.event)) ? .endLoading(), window.OCUIncart.preLoad && window.OCUIncart.preLoad.hideLoader(), this.bt && this.bt.present && this.bt.endLoadingBtn(), _.store.get("navidiumSelectors").includes(this ? .target ? .id) && this.context.helpers.handleNavidium(this), this._shouldRefillDiscounts(e)) return t.next = 32, oneClickUpsellGetCheckoutUrl({
                                redirect: !1
                            });
                            t.next = 32;
                            break;
                        case 32:
                            return t.next = 34, OCUApi.callbackBeforeRedirect(this, e);
                        case 34:
                            if (u = t.sent, l = u.discount, !this.shopPayInstallments) {
                                t.next = 40;
                                break
                            }
                            if ((s = !this.handleShopPayInstallments(e ? ? {})) || OCUApi.shopPayDraftOrder) {
                                t.next = 40;
                                break
                            }
                            return t.abrupt("return");
                        case 40:
                            if (p = !this.isBuyNow && !f.skip_cart && c, h = "cart" !== this.targetAction, n || s || i && h && p) return this._upsellAppInstance().hide(e), this.nativeClick(), t.abrupt("return");
                            t.next = 46;
                            break;
                        case 46:
                            if (!e || e instanceof Error || this.context.prevent(e, !0), (d = OCUIncart.integrations().navidiumShippingProtection).isAppExist) {
                                if (e ? .preventDefault ? .(), e ? .stopImmediatePropagation ? .(), Zipify.Cart ? .integrations ? .ShippingProtection ? .app) return t.next = 54, Zipify.Cart.integrations.ShippingProtection.app.callToAction();
                                t.next = 56
                            } else t.next = 58;
                            break;
                        case 54:
                            t.next = 58;
                            break;
                        case 56:
                            return t.next = 58, d.addProduct();
                        case 58:
                            return h = e && e.detail && e.detail.response, t.abrupt("return", this.context.checkout({
                                discount: l,
                                redirect: !0,
                                redirect_url: h && h.redirect_url
                            }));
                        case 60:
                        case "end":
                            return t.stop()
                    }
                }, t, this)
            })), function(t) {
                return it.apply(this, arguments)
            }),
            handleShopPayInstallments: function(t, e) {
                var r, n, i, o, a = this,
                    c = t.detail;
                return void 0 !== c ? .response ? .accepted && (r = (t = this.context.helpers.getCustomAddToCartData(this)).token, n = N(t, B), i = (t = _.store.get("shopPayInstallments")).checkoutUrl, t = t.query, i = "".concat(i, "=").concat(r), t = "/cart/".concat(n.id, ":").concat(n.quantity, "?").concat(t, "=").concat(r), o = e ? t : i, !! function() {
                    var t = v(S().mark(function t() {
                        return S().wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if ("Upgrade" === c ? .type || e) {
                                        t.next = 3;
                                        break
                                    }
                                    return t.next = 3, a.context.cart.add(null, null, n);
                                case 3:
                                    location.assign(o);
                                case 4:
                                case "end":
                                    return t.stop()
                            }
                        }, t)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()())
            },
            isProductLocationOption: function(t) {
                return this.shopPayInstallments ? f.isPopupTriggerPage : OCUApi.customAddToCartButton ? f.isPopupTriggerPage && this._isAddAction(t) : !("product" !== f.template_name || !this.permalinkType) || (f.isPopupTriggerPage || this.context.integrations.zipifyPages.isLandingPage) && ("form" === t.tagName.toLowerCase() || this.context.integrations.pageFly.isPageFlyButton(t)) && this._isAddAction(t)
            },
            productLocation: function(t, e) {
                var r = this;
                this.popupAccepted ? (void 0 !== OCUApi.preventEventBeforeNativeClick && !OCUApi.preventEventBeforeNativeClick || this.context.prevent(t, !0), this.nativeClick(this.ignoreTrust), this.ignoreTrust = !1) : (this.context.prevent(t, !0), this.context.integrations.createGemPages(t.target), this.bt && this.bt.present && this.bt.startLoadingBtn(), e.disabled = !0, this.verifyToken().then(this[this.secondAttempt ? "getActualCart" : "_emptyResolve"].bind(this)).then(function(t) {
                    return r.actualCart = t && t.data
                }).then(function() {
                    var e = this;
                    this.getIncartConfig().then(function(t) {
                        if ("skip" !== t) {
                            if (function() {
                                    var t = (0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {}).offer_type,
                                        t = ["Upgrade", "SameAsBoughtUpgrade"].includes(t);
                                    return !r.shopPayInstallments && !t && (f.skip_cart || r.isBuyNow)
                                }(t.data)) return this.addAndCheck();
                            this.appropriateResponse = t, this.check(this.event, this.target, null)
                        }
                    }.bind(this)).catch(function(t) {
                        OCUApi.onPopupIsNotShown(), e.nativeClick.bind(e)()
                    })
                }.bind(this)))
            },
            getCartToken: function() {
                return this.context.cart.get("?ocu").then(function(t) {
                    f.cart.token = t.data.token, _.cookie.set("cart", f.cart.token)
                })
            },
            verifyToken: function() {
                return this.cartToken && this.cartToken.includes("?key") ? this._emptyResolve() : this.getCartToken()
            },
            addAndCheck: function() {
                var t, e = 0 < arguments.length && void 0 !== arguments[0] && arguments[0],
                    r = [null, null, OCUApi.getCustomAddToCartData ? .().payload],
                    r = OCUApi.customSkipCart ? r : [this.target],
                    n = this.context.integrations.pageFly.getPFProductData(this.target);
                return (t = this.context.cart)[n ? "_add" : "add"].apply(t, d(n ? [n] : r)).then(function(t) {
                    e || this.check(this.event, this.target, t.data)
                }.bind(this)).catch(this.checkout)
            },
            getActualCart: function() {
                return this.context.cart.get()
            },
            addTriggerVariant: (nt = v(S().mark(function t() {
                var e, r, n, i, o = this;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return e = "cart-drawer,cart-icon-bubble", n = function() {
                                var t = o.context.popupDispatcher.target,
                                    t = "FORM" === t.tagName ? t : t.closest('form[action="/cart/add"]');
                                return t ? ((t = new FormData(t)).append("sections", e), t) : null
                            }, r = function() {
                                return console.warn("Trigger product form is not found"), {
                                    id: o.triggerProduct.variant_id,
                                    quantity: o.triggerProduct.quantity ? ? 1,
                                    sections: e
                                }
                            }, t.prev = 3, n = n() ? ? r(), t.next = 7, this.context.cart.add(null, null, n);
                        case 7:
                            return i = t.sent, t.next = 10, this.context.cart.updateCartItems();
                        case 10:
                            return t.abrupt("return", i.data);
                        case 13:
                            t.prev = 13, t.t0 = t.catch(3), console.error("Error adding trigger variant: ", t.t0);
                        case 16:
                        case "end":
                            return t.stop()
                    }
                }, t, this, [
                    [3, 13]
                ])
            })), function() {
                return nt.apply(this, arguments)
            }),
            openCartDrawer: (rt = v(S().mark(function t(e) {
                var r, n, i, o;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            if (r = function() {
                                    var t = v(S().mark(function t() {
                                        return S().wrap(function(t) {
                                            for (;;) switch (t.prev = t.next) {
                                                case 0:
                                                    return t.abrupt("return", fetch(window.location.pathname + "?sections=cart-drawer,cart-icon-bubble").then(function(t) {
                                                        return t.json()
                                                    }).then(function(t) {
                                                        return {
                                                            sections: t
                                                        }
                                                    }));
                                                case 1:
                                                case "end":
                                                    return t.stop()
                                            }
                                        }, t)
                                    }));
                                    return function() {
                                        return t.apply(this, arguments)
                                    }
                                }(), !1 === Zipify.Cart ? .instance.unpublished) return o = _.store.get("publicEvents"), o = o.cartOpen, n = {
                                triggerElement: this.eventTarget
                            }, dispatchEvent(new CustomEvent(o, {
                                detail: n
                            })), t.abrupt("return", !0);
                            t.next = 6;
                            break;
                        case 6:
                            if (Zipify.OCU.api.customOpenThemeCartDrawerHandler) return t.abrupt("return", Zipify.OCU.api.customOpenThemeCartDrawerHandler(e));
                            t.next = 8;
                            break;
                        case 8:
                            if (i = document.querySelector("cart-drawer")) {
                                t.next = 11;
                                break
                            }
                            return t.abrupt("return", console.log("Theme drawer not found"));
                        case 11:
                            t.prev = 11, e ? .sections ? (t.t0 = e, t.next = 19) : t.next = 16;
                            break;
                        case 16:
                            return t.next = 18, r();
                        case 18:
                            t.t0 = t.sent;
                        case 19:
                            return o = t.t0, i.classList.remove("is-empty"), i.renderContents(o), t.abrupt("return", !0);
                        case 25:
                            t.prev = 25, t.t1 = t.catch(11), console.error(t.t1);
                        case 28:
                        case "end":
                            return t.stop()
                    }
                }, t, this, [
                    [11, 25]
                ])
            })), function(t) {
                return rt.apply(this, arguments)
            }),
            resetCustomRedirectOptions: function() {
                var t = _.store.get("offerCustomRedirectOptions");
                _.store.set("offerCustomRedirectOptions", g(g({}, t), {}, {
                    location: t.locationList.default,
                    clickedItem: null
                }))
            },
            handleCustomRedirectOption: (et = v(S().mark(function t() {
                var e, r, n, i, o, a, c = this;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            if (!(e = _.store.get("offerCustomRedirectOptions")).location || f.skip_cart || this.isBuyNow) return t.abrupt("return");
                            t.next = 3;
                            break;
                        case 3:
                            if (r = "cart" === f.template_name, i = this.isProductAction && !!this.triggerProduct, n = null, i) return t.next = 9, this.addTriggerVariant();
                            t.next = 10;
                            break;
                        case 9:
                            n = t.sent;
                        case 10:
                            if (i = function() {
                                    var t = v(S().mark(function t() {
                                        return S().wrap(function(t) {
                                            for (;;) switch (t.prev = t.next) {
                                                case 0:
                                                    r ? (e.clickedItem === e.itemList.acceptButton && location.reload(), t.next = 8) : t.next = 4;
                                                    break;
                                                case 4:
                                                    return t.next = 6, c.openCartDrawer(n);
                                                case 6:
                                                    t.sent || window.location.assign("/cart");
                                                case 8:
                                                    return t.abrupt("return", !0);
                                                case 9:
                                                case "end":
                                                    return t.stop()
                                            }
                                        }, t)
                                    }));
                                    return function() {
                                        return t.apply(this, arguments)
                                    }
                                }(), o = function() {
                                    return window.location.assign("/checkout"), !0
                                }, a = function() {
                                    var t = v(S().mark(function t() {
                                        return S().wrap(function(t) {
                                            for (;;) switch (t.prev = t.next) {
                                                case 0:
                                                    if (r && e.clickedItem === e.itemList.acceptButton) return t.abrupt("return", location.reload());
                                                    t.next = 2;
                                                    break;
                                                case 2:
                                                    if (r) {
                                                        t.next = 5;
                                                        break
                                                    }
                                                    return t.next = 5, c.openCartDrawer(n);
                                                case 5:
                                                case "end":
                                                    return t.stop()
                                            }
                                        }, t)
                                    }));
                                    return function() {
                                        return t.apply(this, arguments)
                                    }
                                }(), e.location === e.locationList.cart) return t.abrupt("return", i());
                            t.next = 17;
                            break;
                        case 17:
                            if (e.location === e.locationList.checkout) return t.abrupt("return", o());
                            t.next = 21;
                            break;
                        case 21:
                            if (e.location === e.locationList.samePage) return t.next = 24, a();
                            t.next = 25;
                            break;
                        case 24:
                            return t.abrupt("return", !0);
                        case 25:
                        case "end":
                            return t.stop()
                    }
                }, t, this)
            })), function() {
                return et.apply(this, arguments)
            }),
            prefetchProduct: (tt = v(S().mark(function t() {
                var e, r, n;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            if (e = this.context.integrations.gemPages, n = e ? .isValidEntity(this.target), r = "v7" === e ? .getVersion, n = n && r, this.isHCAction && !this._isAcceptableProduct() || n) return n && e.setGMProductAsTrigger(this.eventTarget), t.next = 8, this._getHCProduct();
                            t.next = 10;
                            break;
                        case 8:
                            f.product = t.sent, e.setProduct(f.product);
                        case 10:
                        case "end":
                            return t.stop()
                    }
                }, t, this)
            })), function() {
                return tt.apply(this, arguments)
            }),
            nativeClick: (Y = v(S().mark(function t(e) {
                var r, n, i;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            if (this._clearFlow(), this.secondAttempt = !0, this.ignoreTrust = e, r = OCUApi.customAddToCartButton ? this.target : this.eventTarget, this.isBuyNow && (n = Zipify.OCU.api.customBuyNowButton ? document.querySelector(Zipify.OCU.api.customBuyNowButton) : null, r = n ? ? r.querySelector("button.".concat(_.store.get("classList").buyNow)) ? ? r), (n = OCUIncart.integrations().stickyATC(this.target)).button && (r = n.button), f.skip_cart) return t.abrupt("return", this.handleSkipCart());
                            t.next = 9;
                            break;
                        case 9:
                            if (r && (r.disabled = !1), this.context.helpers.removeExtraClassList(r), this.permalinkType) return t.abrupt("return", this.context.integrations.handlePermalink(this.target.href, this.permalinkType));
                            t.next = 15;
                            break;
                        case 15:
                            OCUApi.customAddToCartEvent ? (r.dispatchEvent(new Event("click")), t.next = 34) : t.next = 19;
                            break;
                        case 19:
                            OCUApi.customAddToCartEventHandler ? (OCUApi.customAddToCartEventHandler(r), t.next = 34) : t.next = 23;
                            break;
                        case 23:
                            return t.next = 25, this.handleCustomRedirectOption();
                        case 25:
                            if (t.sent) return t.abrupt("return", this.resetCustomRedirectOptions());
                            t.next = 27;
                            break;
                        case 27:
                            if ((i = this.context.integrations.gemPages) ? .isAjaxButton(r)) return t.next = 31, i ? .handleGPAjaxCart(r, this.context);
                            t.next = 32;
                            break;
                        case 31:
                            return t.abrupt("return", t.sent);
                        case 32:
                            r ? .focus(), r ? .click();
                        case 34:
                            this.shopPayInstallments && this.isProductAction && !this.popupAccepted && this.handleShopPayInstallments({
                                detail: {
                                    response: {
                                        accepted: !1
                                    }
                                }
                            }, "nativeClick"), OCUApi.callbackAfterNativeClick && OCUApi.callbackAfterNativeClick(this.event), this.bt && this.bt.present && this.bt.endLoadingBtn();
                        case 37:
                        case "end":
                            return t.stop()
                    }
                }, t, this)
            })), function(t) {
                return Y.apply(this, arguments)
            }),
            handleSkipCart: function() {
                var t = this,
                    e = this.context.integrations.pageFly,
                    e = e.isPageFlyButton(this.target) ? e.getPFForm(this.target) : this.target;
                return this.context.cart.add(e).finally(function() {
                    return t.context.checkout({
                        redirect: !0
                    })
                })
            },
            getTriggerAction: function() {
                return {
                    cart: "cart",
                    product: "product",
                    collection: "collection",
                    index: "index",
                    page: "page"
                }[this.isAcceptableAction(this.targetAction) ? this.targetAction : "cart"]
            },
            isAcceptableAction: function(t) {
                return f.isPopupTriggerPage && OCUIncart.popupLocation[t]
            },
            breakHandling: function(t, e) {
                return f.skip_cart ? (this.context.prevent(t), this.context.cart.add(e).then(this.checkout.bind(this)).catch(this.checkout.bind(this))) : this._clearFlow()
            },
            listenCustomEvent: function(t) {
                t = t || this.checkout;
                document.addEventListener("ocuNativeClick", t.bind(this)), this.customEventsBinded = !0
            },
            removeCustomEvents: function() {
                document.removeEventListener("ocuNativeClick", this.checkout, !0)
            },
            _upsellAppInstance: function() {
                return OCUIncart[this.kind + "Upsells"]
            },
            _incartPayload: (Q = v(S().mark(function t() {
                var e, r, n, i;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            if (e = this.context.helpers.getCartItems((this.actualCart || f.cart).items), r = this._productPageVariant, n = _.cookie.get("ocu_shown_id"), i = this.targetAction !== this.getTriggerAction() ? this.targetAction : this.getTriggerAction(), e.cart_token = this.cartToken ? .replace(/\?.+/, ""), e.location = this.context.integrations.zipifyPages.isLandingPage && "product" === this.targetAction ? "product" : i, OCUIncart._location = e.location, e.currency = this.context.helpers.currencyRate(), e.customer_tags = f.customer_tags || [], e.customer_location = OCUIncart.customer_location.handle, e.snippet_version = OCUIncart.version, e.client_id = _.store.get("clientId"), n && (e.shown_popup_id = n), ![].concat(w, d(this.context.integrations.zipifyPages.ZP_LOCATIONS)).includes(e.location)) {
                                t.next = 19;
                                break
                            }
                            if (r) {
                                t.next = 16;
                                break
                            }
                            throw new Error("Variant not found");
                        case 16:
                            e.line_items.push(r), i = this.context.integrations.zipifyPages.getPreOfferAppropriateLineItems().filter(function(t) {
                                return t.variant_id !== r.variant_id
                            }), (n = e.line_items).push.apply(n, d(i));
                        case 19:
                            return _.store.set("productLocation", r), e.line_items = e.line_items.filter(function(t) {
                                return 0 < Object.keys(t).length
                            }), t.abrupt("return", e);
                        case 22:
                        case "end":
                            return t.stop()
                    }
                }, t, this)
            })), function() {
                return Q.apply(this, arguments)
            }),
            _isAddAction: function(e) {
                return !!this.shopPayInstallments || !!["customAddToCartButton", "customAddToCartForm"].some(function(t) {
                    return e && e.closest(OCUApi[t])
                }) || e && (/cart\/add/.test(e.action) || e.dataset.hasOwnProperty("zpAddToCartForm")) || this.context ? .integrations ? .pageFly.isPageFlyButton(e)
            },
            _emptyResolve: function(e) {
                return new Promise(function(t) {
                    t(e)
                })
            },
            _finalizeEvent: function() {
                document.dispatchEvent(new CustomEvent("ocuNativeClick", {
                    detail: {
                        redirect_url: null
                    }
                }))
            },
            _clearFlow: function() {
                return window.OCUIncart.preLoad && window.OCUIncart.preLoad.hideLoader(), window.Zipify.OCU.api.context.helpers.clearFallback(), _.store.set("submitted", !1), null
            },
            _selectedVariant: function(t) {
                var e = this._productPageVariant.variant_id,
                    r = 0,
                    n = null;
                return t.forEach(function(t) {
                    t.id === Number(e) && (r = t.price, n = t.id)
                }), {
                    price: r,
                    variantId: n
                }
            },
            _rechargeWidget: function(t) {
                return window ? .Recharge ? .widgets ? window ? .Recharge ? .widgets[t ? .product_id] : null
            },
            _rechargeProductPrice: function(e) {
                var r, t, n = this._rechargeWidget(e),
                    i = null;
                return i = n && (r = n ? .product ? .plans ? .find(function(t) {
                    return t.external_plan_id === n ? .state ? .sellingPlan
                }), t = n ? .product ? .variants ? .find(function(t) {
                    return t.external_variant_id === e ? .variant_id.toString()
                }), r) && t ? 100 * (t.prices ? .[0] ? .plans ? .find(function(t) {
                    return t.id === r ? .id
                })) ? .discounted_price : i
            },
            _getElementFormData: function(t) {
                return t && (t = t instanceof HTMLFormElement ? t : t.form ? ? t.closest("form")) instanceof HTMLFormElement ? Object.fromEntries(new FormData(t)) : null
            },
            _getFormTargetProductPageVariant: function(t) {
                function e(t) {
                    return {
                        id: +(t ? .id ? ? t ? .["id[]"]),
                        quantity: t ? .quantity ? +t.quantity : 1
                    }
                }
                try {
                    var r = e(this._getElementFormData(t) ? ? this._getElementFormData(this.target));
                    if (!r ? .id) {
                        var n = Array.from(document.querySelectorAll('form[action="/cart/add"]')).filter(function(t) {
                            var e = t.getBoundingClientRect();
                            return null !== t.offsetParent && 0 < e.width && 0 < e.height
                        });
                        if (!n.length) return null;
                        r = e(this._getElementFormData(n[0]))
                    }
                    return r ? .id ? r : null
                } catch (t) {
                    console.log(t.message)
                }
            },
            _getVariantDataFromCartPermalink: function(t) {
                try {
                    var e, r, n, i;
                    return "string" != typeof t ? null : (e = t.match(/\d+:\d+/g)) && (n = (r = l(e[0].split(":"), 2))[0], i = r[1], n) ? {
                        id: +n,
                        quantity: +i
                    } : null
                } catch (t) {
                    return console.log(t.message), null
                }
            },
            _getVariantDataFromCheckoutPermalink: function(t) {
                try {
                    var e, r, n, i;
                    return "string" != typeof t ? null : (e = l(t.split("?")[1].split("&"), 1), n = (r = l(e[0].match(/updates\[(\d+)\]=(\d+)/), 3))[1], i = r[2], n ? {
                        id: +n,
                        quantity: +i
                    } : null)
                } catch (t) {
                    return console.log(t.message), null
                }
            },
            _getProductPageVariant: function(t) {
                var e, r, n, i, o, a = f.product,
                    c = {};
                return this.permalinkType ? c = {
                    addToCart: this._getVariantDataFromCartPermalink,
                    checkout: this._getVariantDataFromCheckoutPermalink
                }[this.permalinkType](this.target.href) ? ? {} : (o = this.context.integrations.zipifyPages, r = t || this.target, o = o.getProductFromForm(r), e = this.context.helpers.getCustomAddToCartData(this), e = 0 === Object.keys(e).length ? g(g({}, r ? .[Symbol.iterator] ? Object.fromEntries(r) : {}), {}, {
                    product: o
                }) : e, o = r.querySelector('[name="id"], [name="id[]"]'), i = this._findQuantity(r), c = {
                    id: +(e.id || o && o.value),
                    quantity: +(e.quantity || i && i.value)
                }, i = (o = this.context.integrations).pageFly, o = o.gemPages, o = (i = i ? .isValidEntity(r = r) ? i.getPayload(r) : o ? .isValidEntity(r) ? o.getPayload(r) : {}).variant, r = i.product, (o || r) && (c = o || c, f.product = a = r || a), c.id || (c = this._getFormTargetProductPageVariant(t) ? ? {}), e.product && (a = e.product), this.isAcceptableAction("collection") && "collection" === f.template_name && (a || = f.collectionProducts.find(function(t) {
                    return t.variants.find(function(t) {
                        return t.id === c.id
                    })
                }))), a && (n = a.variants.find(function(t) {
                    return t.id === c.id && t.available
                }), a.available || n) && !Number.isNaN(c.id) ? (i = this._definePrice((n || a).price, {
                    id: a.id,
                    variant_id: c.id
                }), o = a.options.map(function(t, e) {
                    return {
                        name: t ? .name || t,
                        value: n ? .options[e]
                    }
                }), {
                    variant_id: +c.id,
                    product_id: a.id,
                    price: i,
                    handle: a.handle,
                    title: a.title,
                    quantity: +c.quantity || 1,
                    is_product_location: !0,
                    options_with_values: o,
                    properties: {}
                }) : null
            },
            _isAcceptableProduct: function() {
                var t;
                return !!f.product && (t = +this._productForm().querySelector('[name="product-id"]') ? .value, +f.product.id == t)
            },
            _shouldRefillDiscounts: function(t) {
                function e(t) {
                    return !!Object.keys(t ? .ocu || {}).length
                }
                var r = this.context.helpers.hasWidgetItem(this.actualCart ? .items || f.cart.items);
                return "Upgrade" === t ? .detail ? .type && r && window ? .Zipify ? .Cart && e(window.OCUApi.store.get("widgetDiscounts")) && e(window.OCUApi.store.get("incartDiscounts"))
            },
            _definePrice: function(t, e) {
                var r = _.store.get("sealSellingPlanPrice"),
                    e = this._rechargeProductPrice(e);
                return "number" == typeof r && NaN !== r ? r : "number" == typeof e && NaN !== e ? e : t
            },
            _getHCProduct: (K = v(S().mark(function t() {
                var e, r;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            if (r = +this._productForm() ? .querySelector('[name="product-id"]') ? .value || Zipify.OCU.api.getCustomProductId ? .() || 0, e = OCUIncart.triggerProducts, e = e[r.toString()]) {
                                t.next = 5;
                                break
                            }
                            return t.abrupt("return", "product" === f.template_name ? f.product : null);
                        case 5:
                            return t.next = 7, OCUApi.axios.get("/products/".concat(e, ".js"));
                        case 7:
                            return r = t.sent, t.abrupt("return", r.data);
                        case 9:
                        case "end":
                            return t.stop()
                    }
                }, t, this)
            })), function() {
                return K.apply(this, arguments)
            }),
            _productForm: function() {
                return document.querySelector(Zipify.OCU.api.customAddToCartForm) || this.target
            },
            _findQuantity: function(t) {
                return t.querySelector('[name="quantity"]') || t.closest('[id^="ProductInfo-template"], [id^="ProductInfo-quickadd-template"]') ? .querySelector('[name="quantity"]')
            },
            get _productPageVariant() {
                var t = this.context.helpers.getCustomAddToCartData(this),
                    e = this.context.integrations.zipifyPages,
                    r = document.querySelector(Zipify.OCU.api.customAddToCartForm),
                    n = e.isZipifyEntity() && e.isAcceptableZPLocation();
                return !(this.isProductAction && !t.subscription || e.isLandingPage || n) || e.isLandingPage && !["product", "zp_product", "zp_page"].includes(this.targetAction) ? {} : (this.triggerProduct = this._getProductPageVariant(r), this.triggerProduct)
            },
            get cartToken() {
                return f.cart.token || _.cookie.get("cart") ? .replace(/\?.+/, "")
            },
            get isProductAction() {
                return !f.skip_cart_only && w.includes(this.getTriggerAction())
            },
            get isHCAction() {
                return ["index", "page"].includes(this.getTriggerAction())
            },
            get destination() {
                return !_.store.get("isTargetBuyNow") && this.isProductAction ? "cart" : "checkout"
            },
            get popupAccepted() {
                var t = /\?.+/;
                return "accept_or_decline" === OCUIncart.settings.popup_frequency && _.cookie.get("cart") ? .replace(t, "") === _.cookie.get("ocu_popup_token") ? .replace(t, "") && !!_.cookie.get("ocu_accepted")
            },
            get targetAction() {
                var t = w.includes(f.template_name) ? f.template_name : "product",
                    e = OCUApi ? .enableCustomPages ? .includes(location.pathname),
                    e = OCUApi.customPageName || e,
                    e = e && !OCUIncart.popupLocation[e],
                    r = this.context ? .integrations ? .zipifyPages,
                    n = this.context ? .integrations ? .pageFly;
                return (r ? .isLandingPage || r ? .isZipifyEntity() || e) && (t = r.zpLocation() || "product"), this.target ? OCUIncart.integrations().stickyATC(this.target).button ? "product" : OCUApi.customAddToCartButton ? f.isPopupTriggerPage && this._isAddAction(this.target) ? t : "cart" : (e = this.target && "form" === this.target.tagName.toLowerCase() ? this.target : this.target.closest("form"), this._isAddAction(e) || this.permalinkType || n ? .isPageFlyButton(this.target) ? t : "cart") : "cart"
            },
            get eventTarget() {
                var t = this.context.integrations.pageFly ? .isPageFlyButton(this.event ? .target),
                    e = this.context.integrations.gemPages ? .isValidEntity(this.event ? .target);
                return this.isBuyNow || t || e ? this.event ? .target : this.target.querySelector('[type="submit"], [name="add"], [name="checkout"], [data-ocu-skip-cart]')
            },
            get _quantityOfProduct() {
                var t = document.querySelector('[name="quantity"]'),
                    e = this.context.integrations.pageFly,
                    r = e.getPFForm(this.target);
                return (r ? e.getPFQty(r) : null) || (t ? t.value : "1")
            }
        }, function() {
            function e(t) {
                s(this, e), this.cartToken = t && t.cart.token || _.cookie.get("cart") ? .replace(/\?.+/, ""), this.cartDiscounts = null, this.cartRequested = !1, this.selectors = {
                    productPrice: null,
                    totalProductsPrice: null,
                    cartSubtotal: null,
                    cartDiscount: null
                }, this.helpers = new F, this.cart = new A, this.cache = null, this.renderDiscounts = this.renderDiscounts.bind(this), this.renderOCUDiscounts = this.renderOCUDiscounts.bind(this), this.gettingDiscountsItems = []
            }
            var r;
            return u(e, [{
                key: "renderDiscounts",
                value: function(t, e, r) {
                    var n = this;
                    if (document.dispatchEvent(new Event("renderOCUDiscounts")), r && this.fillSelectors(r), !this.shouldGetDiscounts(e)) {
                        if (this.helpers.deepEqual(this.lineItems, e) && this.cache) return this.helpers.deepEqual(this.gettingDiscountsItems, e) ? void 0 : this.renderDiscountsFromCache();
                        this.lineItems = OCUIncart.cart_items = e, oneClickUpsellGetCheckoutUrl({
                            redirect: !1
                        }), this.gettingDiscountsItems = e, this.getDiscounts(t, e).then(function(t) {
                            var e = t.data.discounts.lineItems;
                            this.cartDiscounts = t.data.discounts, this.cache = t.data, e.map(function(t) {
                                if (t.price === t.discountedPrice) return OCUApi.cartDiscountSelectors ? .showOriginalPrice ? .(t, !0);
                                OCUApi.cartDiscountSelectors ? .showOriginalPrice ? .(t, !1), this.fillDiscountedPrice(t), this.fillItemTotal(t)
                            }.bind(this)), this.fillCartSubtotal(t.data.discounts.subtotal), this.fillCartDiscount(t.data.discounts.progressiveDiscount)
                        }.bind(this)).catch(function(t) {
                            console.log(t.message)
                        }).finally(function() {
                            return n.gettingDiscountsItems = []
                        })
                    }
                }
            }, {
                key: "renderDiscountsFromCache",
                value: function() {
                    var e = this,
                        t = this.cache.discounts.lineItems;
                    this.cartDiscounts = this.cache.discounts, t.map(function(t) {
                        if (t.price === t.discountedPrice) return OCUApi.cartDiscountSelectors ? .showOriginalPrice ? .(t, !0);
                        OCUApi.cartDiscountSelectors ? .showOriginalPrice ? .(t, !1), e.fillDiscountedPrice(t), e.fillItemTotal(t)
                    }), this.fillCartSubtotal(this.cache.discounts.subtotal), this.fillCartDiscount(this.cache.discounts.progressiveDiscount)
                }
            }, {
                key: "getDiscounts",
                value: (r = v(S().mark(function t(e, r) {
                    var n, i, o, a, c;
                    return S().wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (n = "/pre_purchase/v2/cart_discounts", i = window.OCUIncart && OCUIncart.appEndpoint, o = {
                                        "Content-Type": "application/json",
                                        "Shop-Domain": f.permanent_domain
                                    }, (a = this.helpers.getCartItems(r || f.cart.items)).cart_token = (this.cartToken || e) ? .replace(/\?.+/, ""), a.currency_rate = window.Shopify && Shopify.currency && +Shopify.currency.rate || 1, a.customer_tags = f.customer_tags || [], a.customer_location = OCUIncart.customer_location.handle ? ? "unknown", a.cart_token) {
                                    t.next = 10;
                                    break
                                }
                                return t.abrupt("return", Promise.reject(new Error("Cart Token is Missing")));
                            case 10:
                                return t.next = 12, OCUApi.axios.post(i + n, a, {
                                    headers: o
                                });
                            case 12:
                                return c = t.sent, t.abrupt("return", {
                                    data: c.data.context
                                });
                            case 14:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                })), function(t, e) {
                    return r.apply(this, arguments)
                })
            }, {
                key: "doesUrlMatch",
                value: function(e) {
                    var t;
                    return (t = ["add", "update", "change", "clear"].some(function(t) {
                        return e && e.includes("/cart/".concat(t)) && !e.includes("?ocu")
                    })) && this.setCartRequested(!1), t
                }
            }, {
                key: "shouldCartRequest",
                value: function(t) {
                    var e;
                    return !(!t || this.cartRequested) && (e = !/\/cart.(js|json)\?icu/.test(t), (t = t.includes("/cart.js") && !t.includes("/cart.js?ocu") && e) && this.setCartRequested(!0), t)
                }
            }, {
                key: "shouldRequest",
                value: function(t) {
                    return !!t && (this.doesUrlMatch(t) || this.shouldCartRequest(t))
                }
            }, {
                key: "shouldGetDiscounts",
                value: function(t) {
                    return this.helpers.getCartItems(t || f.cart.items).line_items.every(function(t) {
                        if (t.properties) return void 0 === t.properties._ocu_offer_id && void 0 === t.properties._ocu_cart_upsell_id && void 0 === t.properties._ocu_product_page_id
                    }.bind(this))
                }
            }, {
                key: "areAttributesPresent",
                value: function(t) {
                    var i = this;
                    return this.helpers.getCartItems(t || f.cart.items).line_items.some(function(t) {
                        var t = i.getSelectors(t),
                            e = document.querySelector(t.productPrice),
                            r = document.querySelector(t.totalProductsPrice),
                            n = document.querySelector(t.cartSubtotal),
                            t = document.querySelector(t.cartDiscount);
                        return !!(e || r || n || t)
                    })
                }
            }, {
                key: "fillDiscountedPrice",
                value: function(n) {
                    var i = this,
                        t = this.getSelectors(n).productPrice;
                    document.querySelectorAll(t).forEach(function(t) {
                        var e, r;
                        t && (r = t.dataset.ocuWithCurrency, e = i.getCurrency(n.discountedPrice, OCUIncart.money_format, r), r = i.getCurrency(n.price, OCUIncart.money_format, r), r = OCUApi.cartDiscountSelectors ? .disableWasPrice ? "" : '<del style="padding-right:16px">'.concat(i.sanitizeHTML(r), "</del>"), t.innerHTML = "".concat(r, "<span>").concat(i.sanitizeHTML(e), "</span>"))
                    })
                }
            }, {
                key: "fillItemTotal",
                value: function(i) {
                    var o = this,
                        t = this.getSelectors(i).totalProductsPrice;
                    document.querySelectorAll(t).forEach(function(t) {
                        var e, r, n;
                        t && (e = t.dataset.ocuWithCurrency, r = (n = function(t) {
                            return o.getCurrency(t * i.quantity, OCUIncart.money_format, e)
                        })(i.discountedPrice), n = n(i.price), n = OCUApi.cartDiscountSelectors ? .wasTotalPrice ? '<del style="padding-right:16px;text-decoration:line-through">'.concat(o.sanitizeHTML(n), "</del>") : "", t.innerHTML = "".concat(o.sanitizeHTML(n), "<span>").concat(o.sanitizeHTML(r), "</span>"))
                    })
                }
            }, {
                key: "fillCartSubtotal",
                value: function(t) {
                    var r = this,
                        e = this.getSelectors().cartSubtotal,
                        e = document.querySelectorAll(e),
                        n = Zipify.OCU.api.customShippingInsurance,
                        i = t + (n ? .price ? ? 0),
                        o = n ? .enabled ? i : t;
                    e.forEach(function(t) {
                        var e;
                        t && (e = t.dataset.ocuSubtotal, e = r.getCurrency(o, OCUIncart.money_format, e), t.innerHTML = r.sanitizeHTML(e))
                    }), this.fillCartSubtotalCustom(o)
                }
            }, {
                key: "fillCartSubtotalCustom",
                value: function(t) {
                    OCUApi.cartDiscountSelectors ? .cartSubtotalCustom ? .(this.getCurrency(t, OCUIncart.money_format))
                }
            }, {
                key: "fillCartDiscount",
                value: function(r) {
                    var t, n = this;
                    0 !== r && (t = this.getSelectors().cartDiscount, document.querySelectorAll(t).forEach(function(t) {
                        var e;
                        t && (e = n.getCurrency(r, OCUIncart.money_format), t.innerHTML = "-".concat(n.sanitizeHTML(e)))
                    }))
                }
            }, {
                key: "getCurrency",
                value: function(t, e, r) {
                    var n = window.Shopify && Shopify.currency && Shopify.currency.active || "USD",
                        r = !e.match(n) && r ? "".concat(e, " ").concat(n) : e;
                    return Shopify.formatMoney && Shopify.formatMoney(t, r) || window.OCUApi.currency(t / 100, r, n)
                }
            }, {
                key: "fillSelectors",
                value: function(t) {
                    var r = this;
                    if (OCUApi.cartDiscountSelectors) return Object.entries(OCUApi.cartDiscountSelectors).forEach(function(t) {
                        var t = l(t, 2),
                            e = t[0],
                            t = t[1];
                        t instanceof Function || (r.selectors[e] = t)
                    });
                    this.selectors.productPrice = "[".concat(t.productPrice), this.selectors.totalProductsPrice = "[".concat(t.totalProductsPrice), this.selectors.cartSubtotal = "[".concat(t.cartSubtotal, "]"), this.selectors.cartDiscount = "[".concat(t.cartDiscount, "]")
                }
            }, {
                key: "getSelectors",
                value: function(t) {
                    return {
                        productPrice: OCUApi.cartDiscountSelectors ? .productPrice ? .(t, this) || "".concat(this.selectors.productPrice || "[data-ocu-price-block", '="').concat(t ? .key, '"]'),
                        totalProductsPrice: OCUApi.cartDiscountSelectors ? .totalProductsPrice ? .(t, this) || "".concat(this.selectors.totalProductsPrice || "[data-ocu-total-block", '="').concat(t ? .key, '"]'),
                        cartSubtotal: OCUApi.cartDiscountSelectors ? .cartSubtotal || this.selectors.cartSubtotal || "[data-ocu-subtotal]",
                        cartDiscount: OCUApi.cartDiscountSelectors ? .cartDiscount || this.selectors.cartDiscount || "[data-ocu-cart-discount]"
                    }
                }
            }, {
                key: "renderOCUDiscounts",
                value: function(r) {
                    var n = this,
                        t = "?ocu";
                    OCUApi.resetCartCache && (t += "=".concat(Date.now())), O.get(t).then(function(t) {
                        var e = [t.data.token, t.data.items, r];
                        n.renderDiscounts.apply(n, e), OCUApi.forceRenderDiscounts ? .(function() {
                            return n.renderDiscounts.apply(n, e)
                        })
                    })
                }
            }, {
                key: "removePrivateAttributes",
                value: function(t) {
                    t && Array.from(document.querySelectorAll(t)).filter(function(t) {
                        return /_ocu_offer_/.test(t.innerHTML)
                    }).forEach(function(t) {
                        return t.remove()
                    })
                }
            }, {
                key: "proceedDiscounts",
                value: function(t, e) {
                    this.renderDiscounts(t.data.token, t.data.items), e && this.removePrivateAttributes(OCUApi.customLineItemAttributes)
                }
            }, {
                key: "setCartRequested",
                value: function(t) {
                    this.cartRequested = t
                }
            }, {
                key: "sanitizeHTML",
                value: function(t) {
                    function r(e) {
                        if (3 !== e.nodeType) {
                            if (1 === e.nodeType) {
                                var t = e.tagName.toLowerCase();
                                if (!n.includes(t)) return void e.remove();
                                d(e.attributes).forEach(function(t) {
                                    i.includes(t.name) || e.removeAttribute(t.name)
                                })
                            }
                            d(e.childNodes).forEach(r)
                        }
                    }
                    var e = document.createElement("div"),
                        n = (e.innerHTML = t, ["span", "del"]),
                        i = ["style", "class"];
                    return d(e.childNodes).forEach(r), e.innerHTML
                }
            }]), e
        }()),
        O = new A,
        P = window.OCUCartDispatcher = new b(Zipify.OCU.lqd),
        ct = window.XMLHttpRequest.prototype.open,
        st = window.XMLHttpRequest.prototype.send,
        x = (x = window, "function" == typeof(at = window.fetch) && (x.fetch = function() {
            var t = at.apply(this, arguments);
            return t.then(function(t) {
                P.shouldCartRequest(t.url) ? t.clone().json().then(function(t) {
                    P.renderDiscounts(t.token ? .replace(/\?.+/, ""), t.items)
                }) : P.doesUrlMatch(t.url) && O.get("?ocu").then(function(t) {
                    P.renderDiscounts(t.data.token ? .replace(/\?.+/, ""), t.data.items)
                })
            }), t
        }), window.XMLHttpRequest.prototype.open = J, window.OCUApi || (window.OCUApi = {}), window.OCUApi.renderOCUDiscounts = P.renderOCUDiscounts, function() {
            function t() {
                s(this, t), this.currenciesWithoutDec = ["BYR", "XAF", "XPF", "CLP", "KMF", "JPY", "PYG", "RWF", "KRW", "VND", "VUV", "XOF", "MGA", "UGX", "ISK"], this.entities = {
                    "&nbsp;": " ",
                    "&pound;": "£",
                    "&euro;": "€",
                    "&dollar;": "$"
                }, this.types = {
                    amount: [2, ",", "."],
                    amount_no_decimals: [2, ",", "."],
                    amount_with_comma_separator: [2, ".", ","],
                    amount_no_decimals_with_comma_separator: [2, ".", ","],
                    amount_with_space_separator: [2, " ", ","],
                    amount_no_decimals_with_space_separator: [2, " ", ","],
                    amount_with_apostrophe_separator: [2, "'", "."],
                    get default() {
                        return this.amount
                    }
                }, this.currency = this.currency.bind(this)
            }
            return u(t, [{
                key: "round",
                value: function(t) {
                    var e = Math.pow(10, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 1);
                    return Number.isInteger(t) ? t * e / e : Math.round(t * e) / e
                }
            }, {
                key: "thousand",
                value: function(t) {
                    return isNaN(t) || 0 === t ? t : t < 999 ? Math.round(100 * t) / 100 : t < 9999 || t < 1e6 ? this.round(Math.round(10 * t) / 1e4, 0) + "k" : t < 1e7 ? this.round(Math.round(10 * t) / 1e7, 0) + "m" : t < 1e9 ? this.round(Math.round(10 * t / 1e7), 0) + "m" : 1e9 <= t ? this.round(Math.round(10 * t / 1e10), 0) + "b" : void 0
                }
            }, {
                key: "replaceCharEntity",
                value: function(t) {
                    function e(t) {
                        return null !== r.entities[t] && void 0 !== r.entities[t] ? r.entities[t] : t
                    }
                    var r = this;
                    return t && null !== t.replace(/(&\w+;)/g, e) && void 0 !== t.replace(/(&\w+;)/g, e) ? t.replace(/(&\w+;)/g, e) : t
                }
            }, {
                key: "type",
                value: function(t) {
                    t = /\{\{\s*(\w+)\s*\}\}/.exec(t) && /\{\{\s*(\w+)\s*\}\}/.exec(t)[1];
                    return null !== this.types[t] && void 0 !== this.types[t] ? this.types[t] : this.types.default
                }
            }, {
                key: "toFixed",
                value: function(t, e) {
                    var r = Math.pow(10, e);
                    return (Math.round((t + 1e-8) * r) / r).toFixed(e)
                }
            }, {
                key: "formatNumber",
                value: function(t, e, r) {
                    var n, i, o, a = this;
                    return +t || 0 == +t ? (o = r.includes("thousand"), i = r.includes("noCurrency"), i = r.find(function(t) {
                        return a.currenciesWithoutDec.includes(t)
                    }) || i, r = r.includes("noPrecision"), o && (t = this.thousand(+t), n = /\d+\.?\d*([k-m])/.exec(t) && /\d+\.?\d*([k-m])/.exec(t)[1] || "", t = parseFloat(t)), e = {
                        precision: r ? 0 : e[0],
                        thousand: e[1],
                        decimal: e[2]
                    }, o = (t < 0 ? "-" : "") + ((r = 3 < (o = parseInt(this.toFixed(Math.abs(t), e.precision), 10) + "").length ? o.length % 3 : 0) ? o.substr(0, r) + e.thousand : "") + o.substr(r).replace(/(\d{3})(?=\d)/g, "$1" + e.thousand) + (0 < e.precision ? e.decimal + this.toFixed(Math.abs(t), e.precision).split(".")[1] : ""), n && (o = o.replace(/([,.]00|0)$/, "") + n), i && !n ? o.split(e.decimal)[0] : o) : "&mdash;"
                }
            }, {
                key: "formatNumberForView",
                value: function(t, e) {
                    e = this.replaceCharEntity(e);
                    for (var r = arguments.length, n = new Array(2 < r ? r - 2 : 0), i = 2; i < r; i++) n[i - 2] = arguments[i];
                    var o = n.includes("noCurrency");
                    return e && e.replace(o ? /.*\{\{\s*\w+\s*\}\}.*/ : /\{\{\s*\w+\s*\}\}/, this.formatNumber(t, this.type(e), n))
                }
            }, {
                key: "currency",
                value: function(t, e) {
                    for (var r = arguments.length, n = new Array(2 < r ? r - 2 : 0), i = 2; i < r; i++) n[i - 2] = arguments[i];
                    return this.formatNumberForView.apply(this, [t, e].concat(n))
                }
            }]), t
        }());

    function A() {
        var c = this;
        this.add = function() {
            var i = v(S().mark(function t(e, r, n, i) {
                var o, a;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return e && (o = function(t) {
                                return !/id/.test(t)
                            }, n = c.serialize(e), o(n) && (a = document.querySelector("#AddToCartForm")) && (n = c.serialize(a)), o(n)) && (a = document.querySelector("[data-cart-add]")) && (n = "id=" + a.dataset.cartAdd), t.abrupt("return", c._add(n));
                        case 2:
                        case "end":
                            return t.stop()
                    }
                }, t)
            }));
            return function(t, e, r, n) {
                return i.apply(this, arguments)
            }
        }(), this._add = function() {
            var r = v(S().mark(function t(e, r) {
                var n;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return n = {
                                method: "post",
                                url: "".concat(OCUApi.shopifyRoot, "cart/add.js").concat(r ? "" : "?ocu"),
                                data: e
                            }, t.next = 3, c.__lock(v(S().mark(function t() {
                                return S().wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return t.next = 2, k.request(n);
                                        case 2:
                                            return t.abrupt("return", t.sent);
                                        case 3:
                                        case "end":
                                            return t.stop()
                                    }
                                }, t)
                            })));
                        case 3:
                            return t.abrupt("return", t.sent);
                        case 4:
                        case "end":
                            return t.stop()
                    }
                }, t)
            }));
            return function(t, e) {
                return r.apply(this, arguments)
            }
        }(), this.bulkAdd = function() {
            var e = v(S().mark(function t(e) {
                var r;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return r = {
                                method: "post",
                                url: "".concat(OCUApi.shopifyRoot, "cart/update.js"),
                                data: e
                            }, t.next = 3, c.__lock(v(S().mark(function t() {
                                return S().wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return t.next = 2, k.request(r);
                                        case 2:
                                            return t.abrupt("return", t.sent);
                                        case 3:
                                        case "end":
                                            return t.stop()
                                    }
                                }, t)
                            })));
                        case 3:
                            return t.abrupt("return", t.sent);
                        case 4:
                        case "end":
                            return t.stop()
                    }
                }, t)
            }));
            return function(t) {
                return e.apply(this, arguments)
            }
        }(), this.get = function(t) {
            t = "string" == typeof t ? t : "", t = {
                method: "get",
                url: "".concat(OCUApi.shopifyRoot, "cart.js").concat(t)
            };
            return k.request(t)
        }, this.update = function() {
            var e = v(S().mark(function t(e) {
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return t.abrupt("return", new D(e).init());
                        case 1:
                        case "end":
                            return t.stop()
                    }
                }, t)
            }));
            return function(t) {
                return e.apply(this, arguments)
            }
        }(), this.updateCartItems = v(S().mark(function t() {
            var e, r;
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return r = function() {
                            return (r = v(S().mark(function t() {
                                return S().wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return t.prev = 0, t.next = 3, c.get("?ocu").then(function(t) {
                                                c.update(t), OCUIncart.cart_items = t.data.items || t.data.cart.items, f.cart = t.data.items ? t.data : t.data.cart
                                            });
                                        case 3:
                                            return t.abrupt("return", t.sent);
                                        case 6:
                                            t.prev = 6, t.t0 = t.catch(0), console.log("updateCartItems", t.t0);
                                        case 9:
                                        case "end":
                                            return t.stop()
                                    }
                                }, t, null, [
                                    [0, 6]
                                ])
                            }))).apply(this, arguments)
                        }, e = function() {
                            return r.apply(this, arguments)
                        }, t.next = 4, c.__lock(e);
                    case 4:
                        c.helpers.updateCartIconBubble();
                    case 5:
                    case "end":
                        return t.stop()
                }
            }, t)
        })), this.createToken = v(S().mark(function t() {
            var e, r, n, i;
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        if (e = !f.cart.token, r = f.cart.token ? .replace(/\?.+/, "") !== _.cookie.get("cart") ? .replace(/\?.+/, ""), n = !f.cart.line_items || 0 === f.cart.line_items.length, e || r || n) return i = {
                            method: "post",
                            url: "".concat(OCUApi.shopifyRoot, "cart/update.js"),
                            data: {
                                updates: {}
                            }
                        }, t.next = 7, c.__lock(v(S().mark(function t() {
                            return S().wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return t.next = 2, k.request(i);
                                    case 2:
                                        return t.abrupt("return", t.sent);
                                    case 3:
                                    case "end":
                                        return t.stop()
                                }
                            }, t)
                        })));
                        t.next = 8;
                        break;
                    case 7:
                        return t.abrupt("return", t.sent);
                    case 8:
                    case "end":
                        return t.stop()
                }
            }, t)
        })), this.save = function(t) {
            return c.disableMultiUpdate(t.data.cart.items), c.saveTags(t), f.cart_products_json = t.data.cart_products, f.cart_collections_json = t.data.cart_collections, f.subscription_products_json = t.data.subscription_products, f.subscription_variants_json = t.data.subscription_variants, c.resolve(t)
        }, this.modify = function(t) {
            var e = t.cart || t.data.cart || t.data;
            return t.data = e, t.data.subscription_products = f.subscription_products_json, t.data.cart_collections = f.cart_collections_json, t.data.cart_products = f.cart_products_json.filter(function(t) {
                return !t.error
            }), t.data.customer_id = f.customer_id, t = c.helpers.addBuyXGetYDiscount(t), e.cart_level_discount_applications && (t.data.automatic_discount = e.cart_level_discount_applications[0]), t
        }, this.serialize = function(t) {
            return /trident|edge/i.test(navigator.userAgent) ? _.serializeFormEdge(t) : _.serializeForm(t)
        }, this.attrubutes = function() {
            var e = v(S().mark(function t(e) {
                var r;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return r = {
                                method: "post",
                                url: "".concat(OCUApi.shopifyRoot, "cart/update.js"),
                                data: {
                                    attributes: e
                                }
                            }, t.next = 3, c.__lock(v(S().mark(function t() {
                                return S().wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return t.next = 2, k.request(r);
                                        case 2:
                                            return t.abrupt("return", t.sent);
                                        case 3:
                                        case "end":
                                            return t.stop()
                                    }
                                }, t)
                            })));
                        case 3:
                            return t.abrupt("return", t.sent);
                        case 4:
                        case "end":
                            return t.stop()
                    }
                }, t)
            }));
            return function(t) {
                return e.apply(this, arguments)
            }
        }(), this.prepareUpdate = function(t) {
            return t = t.length ? t : [t], {
                updates: Array.prototype.reduce.call(t, function(t, e) {
                    return t[e.id.replace(/(\w+_)(\d+)(:\w+)/, "$2")] = e.value, t
                }, {}),
                currency: f.shop_currency
            }
        }, this.saveTags = function(t) {
            t = t.data.cart_products.reduce(function(t, e) {
                return t.concat(e.tags)
            }, []);
            _.store.set("tags", t)
        }, this.disableMultiUpdate = function(t) {
            var e = document.querySelectorAll('input[name="updates[]"]'),
                r = "add" === _.store.get("offer");
            r && t.length === e.length + 1 || !r && t.length === e.length || Array.prototype.forEach.call(e, function(t) {
                t.offsetHeight || (t.disabled = !0)
            })
        }, this.state = function(t) {
            "updates[]" === t.target.name && _.store.set("cartChanged", !0)
        }, this.resolve = function(e) {
            return new Promise(function(t) {
                t(e)
            })
        }, this.needCurrencyUpdate = function() {
            return document.querySelector('[name="currency"]')
        }, this.updateCurrency = v(S().mark(function t() {
            var e;
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = {
                            method: "post",
                            url: "".concat(OCUApi.shopifyRoot, "cart/update.js"),
                            data: {
                                currency: f.shop_currency
                            }
                        }, t.abrupt("return", c.__lock(v(S().mark(function t() {
                            return S().wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return t.abrupt("return", k.request(e).then(function() {
                                            _.store.set("cartChanged", !1)
                                        }));
                                    case 1:
                                    case "end":
                                        return t.stop()
                                }
                            }, t)
                        }))));
                    case 2:
                    case "end":
                        return t.stop()
                }
            }, t)
        })), this.isNotePresent = function(t) {
            return Array.prototype.some.call(t, function(t) {
                return t.note && t.note.value
            })
        }, this.filterFormsIfNotes = function(t, e) {
            return Array.prototype.filter.call(t, function(t) {
                return t["updates[]"] && (!e || t.note && t.note.value)
            })[0]
        }, this.error = function(t) {
            var e, r = t.data.description;
            return 422 !== t.status ? alert(r || "Something went wrong. Please try again.") : (t = /all/i.test(r), e = /sold out/i.test(r), alert(r), t ? c.checkout({
                redirect: !0
            }) : void(e && location.reload()))
        }, this.__lock = function() {
            var e = v(S().mark(function t(e) {
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return t.next = 2, Zipify.OCU.api.context.helpers.withLock(e);
                        case 2:
                            return t.abrupt("return", t.sent);
                        case 3:
                        case "end":
                            return t.stop()
                    }
                }, t)
            }));
            return function(t) {
                return e.apply(this, arguments)
            }
        }()
    }
    window.OCUApi || (window.OCUApi = {}), window.OCUApi.currency = (new x).currency;
    var ut, lt, pt, dt;
    ({
        init: function() {
            this.fields.length && this.listenEvents()
        },
        get fields() {
            return document.querySelectorAll("[data-quantity-item]")
        },
        getFiledsForUpdate: function(t) {
            t = this.getId(t), t = document.querySelectorAll('[data-quantity-item="' + t + '"]');
            return this.getArray(t)
        },
        getId: function(t) {
            return t.dataset.quantityItem
        },
        getArray: function(t) {
            return Array.prototype.slice.call(t)
        },
        update: function(t, e) {
            this.getFiledsForUpdate(t).forEach(function(t) {
                t.value = e
            })
        },
        handle: function(t) {
            this.update(t.target, t.target.value)
        },
        listenEvents: function(t) {
            this.getArray(this.fields).forEach(function(t) {
                t.addEventListener("input", this.handle.bind(this))
            }.bind(this))
        }
    }).init();

    function I() {
        var t = this;
        OCUApi.axios = OCUApi.axios || axios, (k = OCUApi.axios.create({
            timeout: 2e4
        })).defaults.headers.common["X-Requested-With"] = "XMLHttpRequest", _.shareableDiscount({
            clear: !1
        }), new Rt, new jt, It(), this.helpers.getLocation().then(function() {
            if (f.skip_cart_only || t.setAttributes(), OCUIncart ? .productPageWidget ? .setData) return OCUIncart.productPageWidget.setData();
            t.helpers.listenWidgetEvent()
        })
    }

    function ht() {
        this.isWidgetPresent = function() {
            return document.querySelector("#ocu-widget") && OCUIncart.hasWidgetOffers && !_.store.get("widgetHandled")
        }, this.acceptableToProceed = function(t, e) {
            return window.OCUApi ? .widget ? .customProceedAccept ? OCUApi.widget.customProceedAccept(t, e) : e.isTrusted || t.helpers.isBuyNow(e)
        }, this.accept = function() {
            var e = v(S().mark(function t(e) {
                var r, n, i, o, a, c;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            if (OCUIncart.hasWidgetOffers) {
                                t.next = 2;
                                break
                            }
                            return t.abrupt("return");
                        case 2:
                            return n = Zipify.OCU.api.context, r = e ? ? document.querySelector(Zipify.OCU.api.customAddToCartForm), r = n.popupDispatcher ? ._getProductPageVariant ? .(r), t.next = 7, n.cart.get("?ocu");
                        case 7:
                            return n = t.sent, c = window.OCUIncart && OCUIncart.appEndpoint, i = {
                                "Content-Type": "application/json",
                                "Shop-Domain": f.permanent_domain
                            }, o = n.data, OCUIncart.cart_items = o.items, o = {
                                checkout: {
                                    attributes: o.attributes,
                                    cart_token: o.token ? .replace(/\?.+/, ""),
                                    line_items: [].concat(d(o.items), [r]),
                                    note: o.note,
                                    currency_rate: Number(window.Shopify ? .currency ? .rate) || 1
                                },
                                customer_location: OCUIncart.customer_location ? .handle,
                                customer_tags: f.customer_tags || []
                            }, t.next = 16, OCUApi.axios.post(c + "/product_page/v1/offers/accepted", o, {
                                headers: i
                            });
                        case 16:
                            if (a = t.sent, c = a.data ? .context ? .discount_data) return t.next = 21, OCUApi.handleAutomaticDiscounts(OCUIncart.cart_items, c);
                            t.next = 21;
                            break;
                        case 21:
                            return t.abrupt("return", a);
                        case 22:
                        case "end":
                            return t.stop()
                    }
                }, t)
            }));
            return function(t) {
                return e.apply(this, arguments)
            }
        }(), this.clearState = function() {
            OCUApi.store.set("productPageWidget", {}), OCUIncart.productPageWidget.clear()
        }, this.getCheckedVariants = function() {
            return window.OCUApi.store.get("productPageWidget")
        }, this.getCartAddRequestItems = function() {
            var t = window.OCUApi.store.get("productPageWidget"),
                n = window.OCUApi.store.get("widgetDiscounts");
            return Object.entries(t).reduce(function(t, e) {
                var e = l(e, 2),
                    r = e[0],
                    e = e[1];
                return r && e && t.push({
                    id: e.variantId,
                    quantity: e.quantity || 1,
                    properties: {
                        _ocu_product_page_id: +r,
                        _ocu_offer_reference_id: +e.referenceId,
                        _ocu_offer_data: n ? .ocu ? .[+e.referenceId] || null
                    }
                }), t
            }, [])
        }, this.proceed = function() {
            var t = Zipify.OCU.api.context,
                e = t.integrations.widget ? .getCartAddRequestItems() ? ? [];
            return e.length ? t.cart.add(null, null, {
                items: e
            }, !0) : new Promise(function(t) {
                t()
            })
        }, this.disable = function(t) {
            _.store.set("widgetHandled", t)
        }, this.listenEvents = function(e) {
            addEventListener("ocu:cart:opened", function() {
                var t = e.discount_data;
                t ? .ocu && Object.keys(t ? .ocu).length && oneClickUpsellGetCheckoutUrl({
                    redirect: !1
                })
            })
        }
    }

    function ft() {
        var n = this,
            i = "ocu_integration_data";
        this.ZP_LOCATIONS = ["product", "collection", "page", "index"].map(function(t) {
            return "zp_".concat(t)
        }), this.isLandingPage = f.template_suffix.includes("zipifypages"), this.isAcceptableZPLocation = function() {
            return n.ZP_LOCATIONS.includes(n.zpLocation())
        }, this.isZipifyEntity = function() {
            return (window.ZipifyPages ? .isPagesEntity ? ? window.ZipifyPages) && window.productJSON ? .length && (Zipify.OCU ? .api ? .context ? .popupDispatcher ? .event ? .target ? .dataset.hasOwnProperty("zpAddToCart") || Zipify.OCU ? .api ? .context ? .popupDispatcher ? .target ? .dataset.hasOwnProperty("zpAddToCartForm"))
        }, this.zpLocation = function() {
            var t = "zp_".concat(f.template_name);
            return OCUIncart.popupLocation[t] ? t : null
        }, this.isNotFormTarget = function(t) {
            return n.isLandingPage && "a" === t.target.tagName.toLowerCase() && !t.target.innerHTML && !t.isTrusted
        }, this.setProducts = function(t) {
            n.products = t
        }, this.setBlockId = function(t) {
            n.block_id = t
        }, this.getProduct = function() {
            return n.product
        }, this.appendZipifyPagesProduct = function(t) {
            var r;
            return n.products ? (r = n.products.find(function(t) {
                return t.discountHash
            }) ? .discountHash, t.map(function(e) {
                var t = n.products.find(function(t) {
                    return t.productData.key === e.key
                });
                return t && t ? .discountData.includes("dynamic") && (t = {
                    pages: !0,
                    discount_hash: r,
                    block_id: n.block_id
                }, e.properties = g(g({}, e.properties), t)), e
            })) : t
        }, this.init = function() {
            try {
                n.sessionData = JSON.parse(sessionStorage.getItem(i)), n.sessionData && n.sessionData.token !== f.cart.token && (n.sessionData = null, sessionStorage.removeItem(i))
            } catch (t) {
                console.error(t)
            }
        }, this.handleZPOutsidePage = function(e, r) {
            try {
                var t = JSON.stringify({
                    products: n.products,
                    block_id: n.block_id,
                    token: f.cart.token
                });
                sessionStorage.setItem(i, t), r({
                    detail: {}
                })
            } catch (t) {
                console.error(t), n._verifyFallback(e, r)
            }
        }, this._verifyFallback = function(e, r) {
            e.cart.get().then(function(t) {
                OCUIncart.cart_items = t.data.items, e.verify().then(function() {
                    r({
                        detail: {}
                    })
                })
            })
        }, this.clear = function() {
            n.products = null
        }, this.getProductFromForm = function(e) {
            return Array.isArray(window.productJSON) ? e && (window.productJSON ? ? []).find(function(t) {
                return t.id === (+e["product-id"] ? .value || +e.dataset.productid)
            }) : null
        }, this.isBlockOutsideProductPage = function() {
            return !f.isPopupTriggerPage && n.products.some(function(t) {
                return t.discountHash
            })
        }, this.init(), this.getPreOfferAppropriateLineItems = function() {
            return n.products ? .length ? n.products.map(function(t) {
                return g({
                    is_product_location: !0
                }, t.productData)
            }) : []
        }
    }

    function mt() {
        var i = this,
            e = "ProductATC";
        this.isPageFlyTemplate = function(t) {
            var e = t.closest("form");
            return e && (t = ["pf-product-form", "pf-form"].some(function(t) {
                return e.classList.contains(t)
            }), !!f.template_suffix.includes("pf-") || t)
        }, this.isPageFlyButton = function(t) {
            return t && (t.dataset ? .pfType ? .toString() ? .startsWith(e) ? t : t.closest('[data-pf-type^="'.concat(e, '"]')))
        }, this.getPFForm = function(t) {
            return i.isPageFlyButton(t) ? t.form ? ? t.closest("form") : null
        }, this.getPFProductData = function(t) {
            var e;
            return i.isPageFlyButton(t) || t.classList.contains("pf-product-form") ? (e = i.getPFProduct(t) || i._getProduct(+t.dataset.productid), t = "form" === t.tagName.toLocaleLowerCase() ? t : i.getPFForm(t), t = i.getPFQty(t), {
                "product-id": e.id,
                form_type: "product",
                id: e.variants[0].id,
                quantity: t
            }) : null
        }, this.isValidEntity = function(t) {
            return i.isPageFlyTemplate(t) || i.isPageFlyButton(t)
        }, this.getPFProduct = function(t) {
            t = (t.dataset.productid || t.dataset.productId) ? ? Object.fromEntries(new FormData(t.form ? ? t))["product-id"];
            return i._getProduct(+t)
        }, this.getPFVariant = function(t) {
            var e = "form" === t.tagName.toLocaleLowerCase() ? t : i.getPFForm(t),
                r = null,
                n = (e && (n = Object.fromEntries(new FormData(e)), r = n ? .id || n ? .["id[]"] || e ? .querySelector('[name="id"], [name="id[]"]') ? .value), i.getPFProduct(t)),
                t = r ? n ? .variants.find(function(t) {
                    return +t.id == +r
                }) : n ? .variants[0];
            return t ? (e = i.getPFQty(e), t.quantity = e || 1, t || n.variants[0]) : null
        }, this._getProduct = function(t) {
            return window.__pageflyProducts ? .[+t]
        }, this.getPFQty = function(t) {
            return +t ? .querySelector('[name="quantity"]') ? .value || 1
        }, this.getPayload = function(t) {
            return {
                variant: i.getPFVariant(t),
                product: i.getPFProduct(t)
            }
        }
    }
    I.prototype = {
        checkout: null,
        ocuSelectors: "".concat(_.store.get("ocuSelectors"), " ").concat(OCUApi.customCheckoutButton || ""),
        integrations: new Ut,
        helpers: new F,
        cart: new A,
        utils: new function() {
            var t = {
                overlay: ".slidecarthq-overlay",
                cartDrawer: "[cart-drawer-show], .slidecarthq, #sidebar-cart",
                chatWindow: "#chat-window",
                chatButton: "#chat-button"
            };
            this.beforePrecheckoutPopup = function() {
                this.adjustZIndex(), this.hideSlidecart()
            }, this.adjustZIndex = function() {
                Object.values(t).forEach(function(t) {
                    t = document.querySelector(t);
                    t && (t.style.zIndex = 1e3)
                })
            }, this.hideSlidecart = function() {
                this._hideSlideCart(), this._hideCartDrawerComponent()
            }, this._hideSlideCart = function() {
                this.isMobile() && window.SLIDECART_STATE && window.SLIDECART_STATE().open && window.SLIDECART_CLOSE && SLIDECART_CLOSE()
            }, this._hideCartDrawerComponent = function() {
                document.querySelector("cart-drawer-component") ? .closeDialog()
            }, this.isMobile = function() {
                return /Android|webOS|iPhone|iPod|BlackBerry|IEMobile|Mobile|Opera Mini/i.test(navigator.userAgent)
            }
        },
        popupDispatcher: new X,
        cartDispatcher: window.OCUCartDispatcher ? ? new b(Zipify.OCU.lqd),
        setAttributes: function() {
            var t = /register|account|login|reset_password|search|^$/.test(f.template_name),
                e = OCUApi.enableCustomPages && "" === f.template_name;
            t && !e || (this.cartDispatcher.renderDiscounts(), t = Array.prototype.forEach, e = document.querySelectorAll(this.ocuSelectors), document.querySelectorAll("a"), t.call(e, function(t) {
                /(update|plus|minus)/.test(t.name) || "FORM" === t.tagName || t.closest(OCUApi.excludeActionButton) || (t.dataset.ocuCheckout = !0)
            }), this.listenEvents(), setTimeout(this.helpers.showCheckoutButton))
        },
        check: function(t, e) {
            this.prevent(t);
            t = e.closest('[action="/cart"], [action="/checkout"]');
            return t && !this.validate(t) ? (clearTimeout(_.store.get("fallback").id), _.store.set("submitted", !1), t.reportValidity()) : _.store.get("cartChanged") ? void 0 : this.handle(e)
        },
        handle: (dt = v(S().mark(function t(e) {
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        if (this.integrations.discounts(), _.store.get("checkoutButtonState")) return t.abrupt("return");
                        t.next = 3;
                        break;
                    case 3:
                        if (_.store.set("checkoutButtonState", !0), this.helpers.payPal(e), OCUApi.customCheckoutRedirect) return t.abrupt("return", OCUApi.customCheckoutRedirect(e));
                        t.next = 7;
                        break;
                    case 7:
                        this.checkout({
                            redirect: !0
                        });
                    case 8:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        })), function(t) {
            return dt.apply(this, arguments)
        }),
        init: (pt = v(S().mark(function t(e, r) {
            var n, i, o, a, c, s, u, l, p, d = this;
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        if (n = this, i = e.target.closest(_.store.get("skipCartSelector")), OCUApi.callbackBeforeRedirect && _.store.get("submitted") && !OCUApi.preventReloadPersistedPage) return t.abrupt("return", n.prevent(e));
                        t.next = 4;
                        break;
                    case 4:
                        if (OCUApi.onCheckout && OCUApi.onCheckout()) return t.abrupt("return");
                        t.next = 6;
                        break;
                    case 6:
                        if ("cart" === f.template_name && _.store.get("submitted")) return e.stopPropagation(), t.abrupt("return", e.preventDefault());
                        t.next = 9;
                        break;
                    case 9:
                        if (_.store.set("submitted", !0), this.fallbackRedirect(), window.RevyApp && this.handleMonkeyPatching(), this.allowUpsells(r)) {
                            t.next = 14;
                            break
                        }
                        return t.abrupt("return");
                    case 14:
                        if ("product" !== f.template_name || "add" !== r.name || r.closest('form[action$="/cart/add"]') || OCUApi.customAddToCartForm || this.integrations.pageFly.isPageFlyButton(r)) {
                            t.next = 21;
                            break
                        }
                        if (o = document.querySelector('form[action$="/cart/add"]')) {
                            t.next = 18;
                            break
                        }
                        return t.abrupt("return", this.helpers.clearFallback());
                    case 18:
                        return e.preventDefault(), e.stopPropagation(), t.abrupt("return", o.submit());
                    case 21:
                        if ("collection" !== f.template_name || "add" !== r.name || r.closest('form[action$="/cart/add"]') || this.integrations.pageFly.isPageFlyButton(r) || OCUApi.customAddToCartForm) {
                            t.next = 28;
                            break
                        }
                        if (a = document.querySelector('form[action$="/cart/add"]')) {
                            t.next = 25;
                            break
                        }
                        return t.abrupt("return", this.helpers.clearFallback());
                    case 25:
                        return e.preventDefault(), e.stopPropagation(), t.abrupt("return", a.submit());
                    case 28:
                        if (c = window.OCUIncart && (OCUIncart.singleUpsells || OCUIncart.multipleUpsells)) {
                            if (this.helpers.getPermalinkType(r.href)) return t.abrupt("return", this.popupDispatcher.proceed(e, r, n));
                            t.next = 32
                        } else t.next = 40;
                        break;
                    case 32:
                        if (OCUApi.customFormValidate ? .(r), OCUApi.isFormInvalid) return n.prevent(e, !0), clearTimeout(_.store.get("fallback").id), _.store.set("submitted", !1), t.abrupt("return");
                        t.next = 38;
                        break;
                    case 38:
                        return OCUApi.originFetch && (fetch = OCUApi.originFetch), t.abrupt("return", this.popupDispatcher.proceed(e, r, n));
                    case 40:
                        if (this.popupDispatcher.target = r, _.store.set("submitted", !1), s = this.popupDispatcher._isAddAction(r), !c && f.isPopupTriggerPage && s) {
                            if (clearTimeout(_.store.get("fallback").id), this.popupDispatcher.ignoreTrust && this.helpers.isBuyNow(e)) return this.prevent(e, !0), t.abrupt("return", new L(e, this.integrations.widget));
                            t.next = 48
                        } else t.next = 53;
                        break;
                    case 48:
                        i ? (_.store.set("submitted", !0), t.next = 53) : t.next = 52;
                        break;
                    case 52:
                        return t.abrupt("return");
                    case 53:
                        if (i && _.store.get("submitted")) return e.preventDefault(), e.stopPropagation(), e.stopImmediatePropagation(), t.abrupt("return", this.cart.add(r).finally(function() {
                            return d.checkout({
                                redirect: !0
                            })
                        }));
                        t.next = 58;
                        break;
                    case 58:
                        return r.dataset.customBuyNow && (n.prevent(e), s = r.dataset.varientId, u = r.dataset.itemQuantity, u = {
                            id: s,
                            quantity: u
                        }, l = function() {
                            n.checkout({
                                redirect: !0
                            })
                        }, p = function() {
                            alert("Network Error")
                        }, this.cart.add(null, null, u).then(l).catch(p)), t.abrupt("return", this.check(e, r));
                    case 60:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        })), function(t, e) {
            return pt.apply(this, arguments)
        }),
        prevent: function(t, e) {
            t.preventDefault(), t.stopPropagation(), e && t.stopImmediatePropagation()
        },
        validate: function(t) {
            t = d(t.querySelectorAll('[type="text"], [type="checkbox"], select, textarea')).filter(function(t) {
                return !_.store.get("excludedRequiredFormIds").includes(t ? .form ? .id) && t && t.required
            });
            return !t.length || !t.some(function(t) {
                return !t.checkValidity()
            })
        },
        allowUpsells: function(t) {
            return OCUApi.customAllowUpsellsValidation ? OCUApi.customAllowUpsellsValidation() : !(window.popup_upsell && !document.querySelector("#upsellclosebtn") || window.ol_checkout_ok instanceof Function && !ol_checkout_ok() || "" === t.dataset.zpaSubmitButton) || void 0
        },
        fallbackRedirect: function() {
            var t = _.store.get("fallback");
            t.id || (t.id = setTimeout(function() {
                this.checkout({
                    redirect: !0
                })
            }.bind(this), t.timeout), _.store.set("fallback", t))
        },
        handleMonkeyPatching: function() {
            var t = _.store.get("XHR").send;
            XMLHttpRequest.prototype.send !== t && (XMLHttpRequest.prototype.send = t)
        },
        handleClick: (lt = v(S().mark(function t(e) {
            var r, n, i, o, a, c, s = this;
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        if ("page" !== f.template_name || e.isTrusted) {
                            t.next = 2;
                            break
                        }
                        return t.abrupt("return");
                    case 2:
                        if (this.integrations.zipifyPages.isNotFormTarget(e)) return t.abrupt("return");
                        t.next = 4;
                        break;
                    case 4:
                        if (/(update|plus|minus)/.test(e.target.name) || e.target.closest('[name="update"], [name="plus"], [name="minus"]')) return t.abrupt("return");
                        t.next = 6;
                        break;
                    case 6:
                        if (!f.amazon_pay && e.target.closest('form[action^="https://payments.amazon"]')) return t.abrupt("return");
                        t.next = 8;
                        break;
                    case 8:
                        if (this.helpers.zpPreventRedirect(e.target)) return t.abrupt("return");
                        t.next = 10;
                        break;
                    case 10:
                        if (this.helpers.isBuyNow(e) && !f.isPopupTriggerPage) return t.abrupt("return", new L(e, this.integrations.widget));
                        t.next = 12;
                        break;
                    case 12:
                        if (this.helpers.isCartPopupRedirectsToCart(e)) return t.abrupt("return");
                        t.next = 14;
                        break;
                    case 14:
                        if ((r = this.helpers.checkPermalink(e.target)) && "product" === f.template_name) return t.abrupt("return", this.init(e, r));
                        t.next = 17;
                        break;
                    case 17:
                        if ((n = this.helpers.checkAddToCart(e.target)) || r || !OCUIncart.integrations().minMaxify.invalid) {
                            t.next = 20;
                            break
                        }
                        return t.abrupt("return");
                    case 20:
                        if (OCUIncart.integrations().salesRocket.setup(), i = this.helpers.checkSelector(e, e.target), OCUIncart.preventHandle(i, n)) return t.abrupt("return");
                        t.next = 24;
                        break;
                    case 24:
                        if (o = this.integrations.widget, (f.isPopupTriggerPage || this.integrations.zipifyPages.isLandingPage || f.isSkipCartCondition) && (i = n || i), f.isPopupTriggerPage && this.integrations.bold.isSCPOForm(i)) return t.prev = 27, t.next = 30, this.integrations.bold.validateSCPO(i);
                        t.next = 35;
                        break;
                    case 30:
                        t.next = 35;
                        break;
                    case 32:
                        return t.prev = 32, t.t0 = t.catch(27), t.abrupt("return");
                    case 35:
                        if (c = this.integrations.widget, a = c.isWidgetPresent, c = c.proceed, !(a() && n && o.acceptableToProceed(this, e))) {
                            t.next = 40;
                            break
                        }
                        this.prevent(e, !0);
                        try {
                            OCUIncart.productPageWidget.trackAccepted(o.getCheckedVariants())
                        } catch (t) {
                            console.error("Error tracking upsell accepted", t)
                        }
                        return t.abrupt("return", c().catch(function() {
                            dispatchEvent(new CustomEvent(_.store.get("publicEvents").cartUpdated))
                        }).finally(function() {
                            s.proceedWidgetFlow(e, n)
                        }));
                    case 40:
                        i && this.init(e, i);
                    case 41:
                    case "end":
                        return t.stop()
                }
            }, t, this, [
                [27, 32]
            ])
        })), function(t) {
            return lt.apply(this, arguments)
        }),
        proceedWidgetFlow: (ut = v(S().mark(function t(e, r) {
            var n, i, o;
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return o = this.integrations.widget, n = o.disable, i = o.accept, o = o.clearState, (this.popupDispatcher.context = this).helpers.isBuyNow(e) ? (this.popupDispatcher.isBuyNow = !0, this.popupDispatcher.target = r, this.popupDispatcher.event = e) : this.popupDispatcher.target = r, n(!0), t.next = 6, i();
                    case 6:
                        o(), n(!1), this.popupDispatcher.ignoreTrust = !0, OCUIncart.popupLocation.product ? this.popupDispatcher.proceed(e, r, this) : this.popupDispatcher.nativeClick(!0);
                    case 10:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        })), function(t, e) {
            return ut.apply(this, arguments)
        }),
        handleFocus: function() {
            window.addEventListener("focus", function(t) {
                t.stopImmediatePropagation()
            }, !0)
        },
        listenEvents: function() {
            function t(t) {
                e = t
            }
            var e, r = {
                    capture: !0,
                    passive: !1
                },
                n = function(t) {
                    window.OCUDisableEvents || this.handleClick(t)
                }.bind(this),
                i = this.helpers.onClickLocation();
            document.addEventListener("mousedown", this.integrations.amazonPay.bind(this), !0), i.addEventListener("click", n, !0), window.addEventListener("pagehide", this.helpers.disableButtons), i.addEventListener("touchend", function(t) {
                e || n(t)
            }, r), i.addEventListener("touchmove", function() {
                t(!0)
            }, r), i.addEventListener("touchstart", function() {
                t(!1)
            }, r), window.addEventListener("locationchange", function() {
                i.removeEventListener("click", n, !0), i.addEventListener("click", n, !0)
            }.bind(this)), window.addEventListener("pageshow", function(t) {
                t.persisted && !OCUApi.preventReloadPersistedPage && location.reload(), this.helpers.disableButtons()
            }.bind(this)), OCUApi.listenFormEvents ? .()
        }
    };
    var E = function() {
            function t() {
                s(this, t), this.product = null
            }
            var e;
            return u(t, [{
                key: "setProduct",
                value: function(t) {
                    this.product = t
                }
            }, {
                key: "isValidEntity",
                value: function(t) {
                    return !!t && !!this.getForm(t)
                }
            }, {
                key: "getPayload",
                value: function(t) {
                    return {
                        product: this.getProduct(t),
                        variant: this.getVariant(t)
                    }
                }
            }, {
                key: "closePopupIfOpen",
                value: function(t) {
                    t && (t = t ? .closest("gp-dialog")) && (t = t.querySelector("dialog")) && t.open && t.close()
                }
            }, {
                key: "handleGPPopup",
                value: function() {
                    var r = this,
                        n = document.querySelector("gp-dialog");
                    n && n.addEventListener("gp:popup-open", function(t) {
                        var e = document.querySelector(".ocu-popup");
                        window.getComputedStyle(e).height && r.closePopupIfOpen(n)
                    })
                }
            }, {
                key: "getForm",
                value: function(t) {}
            }, {
                key: "getProduct",
                value: function(t) {}
            }, {
                key: "getVariant",
                value: function(t) {}
            }, {
                key: "setGMProductAsTrigger",
                value: function(t) {}
            }, {
                key: "isAjaxButton",
                value: function(t) {
                    return !1
                }
            }, {
                key: "handleGPAjaxCart",
                value: (e = v(S().mark(function t(e) {
                    return S().wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                            case "end":
                                return t.stop()
                        }
                    }, t)
                })), function(t) {
                    return e.apply(this, arguments)
                })
            }, {
                key: "getVersion",
                get: function() {
                    return null
                }
            }]), t
        }(),
        gt = function() {
            o(e, E);
            var r, t = a(e);

            function e() {
                return s(this, e), t.call(this)
            }
            return u(e, [{
                key: "getVersion",
                get: function() {
                    return "v7"
                }
            }, {
                key: "getForm",
                value: function(t) {
                    return t.closest("gp-product")
                }
            }, {
                key: "getProduct",
                value: function(t) {
                    return this.product
                }
            }, {
                key: "getVariant",
                value: function(t) {
                    var t = this.getForm(t) ? .getContext(),
                        e = t ? .variantSelected ? .id,
                        r = this.product ? .variants.find(function(t) {
                            return +t.id === e
                        });
                    return r ? (t = t ? .quantity || 1, r.quantity = t, r) : null
                }
            }, {
                key: "setGMProductAsTrigger",
                value: function(t) {
                    var t = this.getForm(t),
                        e = t.getState() ? .productHandle,
                        t = t.getContext() ? .productId || t.querySelector("form") ? .["product-id"] ? .value;
                    t !== f.product ? .id && e && t && (OCUIncart._externalHandles[t] = e)
                }
            }, {
                key: "handleGPAjaxCart",
                value: (r = v(S().mark(function t(e, r) {
                    var n;
                    return S().wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return n = this.getForm(e), n = n.querySelector("form"), t.next = 4, r.cart.add(n);
                            case 4:
                                return t.next = 6, Zipify.Cart.instance.openCart();
                            case 6:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                })), function(t, e) {
                    return r.apply(this, arguments)
                })
            }, {
                key: "isAjaxButton",
                value: function(t) {
                    var e = window.Zipify ? .Cart ? .instance,
                        t = t.closest("gp-product-button[gp-data], gp-product-dynamic[gp-data]") ? .getAttribute("gp-data"),
                        r = JSON.parse(t ? ? "{}"),
                        n = r ? .setting ? .actionEffect,
                        r = r ? .setting ? .customURL ? .link;
                    return !(!t || "continue-shopping" === n) && e && (["open-cart-drawer", "go-to-url"].includes(n) && !r ? .length || "open-cart-drawer" === n && !!r ? .length) && "buy-now" !== n
                }
            }]), e
        }(),
        yt = function() {
            o(n, E);
            var r, e = a(n);

            function n() {
                var t;
                return s(this, n), (t = e.call(this)).V6_SELECTORS = ["gf_add-to-cart"], t
            }
            return u(n, [{
                key: "getVersion",
                get: function() {
                    return "v6"
                }
            }, {
                key: "getForm",
                value: function(t) {
                    function e(e) {
                        return r.V6_SELECTORS.some(function(t) {
                            return e.classList.contains(t)
                        })
                    }
                    var r = this,
                        n = Zipify.OCU.api.context ? .popupDispatcher ? .event ? .target,
                        i = e(t);
                    return "form" === t.tagName.toLowerCase() && e(n) ? t : i ? n.closest("form") : null
                }
            }, {
                key: "getProduct",
                value: function(t) {
                    var e, t = this.getForm(t).querySelector("script.product-json") ? .innerText;
                    try {
                        e = JSON.parse(t), this.product = e
                    } catch (t) {
                        return console.error("Gem Pages: Error parsing product JSON", t), null
                    }
                    return this.product
                }
            }, {
                key: "getVariant",
                value: function(t) {
                    var t = this.getForm(t),
                        e = +t.querySelector('[name="id"]') ? .value,
                        r = this.product ? .variants.find(function(t) {
                            return +t.id == e
                        });
                    return r ? (t = +t.querySelector('[name="quantity"]') ? .value || 1, r.quantity = t, r) : null
                }
            }, {
                key: "handleGPAjaxCart",
                value: (r = v(S().mark(function t(e, r) {
                    var n;
                    return S().wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return n = this.getForm(e), t.next = 3, r.cart.add(n);
                            case 3:
                                return t.next = 5, Zipify.Cart.instance.openCart();
                            case 5:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                })), function(t, e) {
                    return r.apply(this, arguments)
                })
            }, {
                key: "isAjaxButton",
                value: function(t) {
                    var e = window.Zipify ? .Cart ? .instance,
                        t = t.closest("[data-cbto]"),
                        r = t ? .dataset;
                    return e && "custom" === r ? .cbto && "0" === r ? .ajaxcart && (t.dataset.ajaxcart = "1"), e && "1" === t ? .dataset ? .ajaxcart && (["cart", "custom"].includes(r ? .cbto) && !r ? .editlink ? .length || "cart" === r ? .cbto && !!r ? .editlink ? .length) && "checkout" !== r ? .cbto
                }
            }]), n
        }();

    function vt(t) {
        var e = t.target.closest('form[action^="https://payments.amazon"]');
        if (e && f.amazon_pay) {
            t.preventDefault(), t.stopPropagation(), _.store.set("amazonPayInitiated", !0);

            function r(t) {
                return t.status && (t = i(t.checkout_url)) ? (_.cookie.set("ocu_checkout_token", t), void location.assign(n)) : o()
            }
            var t = t.target.closest('form[action="/cart/add"]'),
                n = f.proxy_url + "/amazon/forward",
                i = function(t) {
                    var e = f.proxy_url.replace(/\//g, "\\/"),
                        e = new RegExp(e + "\\/((?:\\w+[-_]?)+)\\/?").exec(t);
                    return e && e[1]
                },
                o = function() {
                    e.submit()
                };
            if (!t) return this.checkout().then(r).catch(o);
            var t = document.querySelector('form[action="/cart/add"]'),
                a = e.querySelector('[type="submit"]');
            this.cart.add(t, a).then(this.checkout).then(r).catch(o)
        }
    }

    function bt() {
        var r = this;
        this.isBoldRecuring = function() {
            var t = document.querySelector("[data-bold-recurring]");
            return t && t.checked
        }, this.upsellPopup = function(t) {
            [t.querySelector('[data-bold-component-id="upsell_continue"]'), t.querySelector('[data-bold-component-id="upsell_no_thanks"]'), t.querySelector("#bold-modal__btn-close")].forEach(function(t) {
                t && t.addEventListener("click", function(t) {
                    setTimeout(function() {
                        self.checkout({
                            redirect: !0
                        })
                    }, 500)
                })
            })
        }, this.initRecurring = function() {
            var t = document.querySelectorAll("[data-ocu-clone]"),
                t = Array.prototype.filter.call(t, function(t) {
                    return t && !t.dataset.ocuCheckout
                })[0];
            t && t.click()
        }, this.redirect = function(t) {
            if (!(window.BOLD && BOLD.recurring_orders && BOLD.recurring_orders.app && t.isTrusted)) throw new Error("Bold Recurring not found");
            if (!BOLD.common.cartDoctor.cart.is_recurring) throw new Error("Bold Recurring cart error");
            t.preventDefault(), t.stopImmediatePropagation(), BOLD.recurring_orders.app.cartWidget.checkoutEvent = t, BOLD.recurring_orders.app.cartWidget.checkRecurringCheckout(t)
        }, this.recurring = function(t, e) {
            var r = "https://",
                n = "recurringcheckout.com",
                i = "/s/",
                o = /(\w+)\.myshopify\.com/.exec(BOLD.common.Shopify.shop.permanent_domain)[1],
                a = "/checkout/recurring/",
                c = "?shop_url=" + location.host;
            t.action = r + n + i + o + a + e + c, t.submit()
        }, this.isSCPOForm = function(t) {
            return window ? .BOLD ? .options ? .app ? .getOptionProductByForm(t)
        }, this.validateSCPO = function() {
            var e = v(S().mark(function t(e) {
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return t.prev = 0, t.next = 3, r.isSCPOForm(e) ? .validateOptions();
                        case 3:
                            t.next = 8;
                            break;
                        case 5:
                            throw t.prev = 5, t.t0 = t.catch(0), new Error("SCPO form invalid");
                        case 8:
                        case "end":
                            return t.stop()
                    }
                }, t, null, [
                    [0, 5]
                ])
            }));
            return function(t) {
                return e.apply(this, arguments)
            }
        }()
    }

    function kt() {
        var r, n, t, i;
        f.themeSkipCart && (r = this, n = document.querySelector('button[id="AddToCart"]')) && (t = n.querySelector("#AddToCartText"), /buy\s*(it)?\s*now/i.test(t && t.innerText)) && (i = function() {
            r.checkout({
                redirect: !0
            })
        }, n.addEventListener("click", function(t) {
            t.preventDefault();
            var e = n.closest('form[action="/cart/add"]');
            r.cart.add(e, t.target).then(i).catch(function(t) {
                t.submit()
            }.bind(null, e))
        }))
    }

    function _t() {
        return (_t = v(S().mark(function t(r, e) {
            var n, i, o, a, c, s, u, l, p = arguments;
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        if (n = (2 < p.length && void 0 !== p[2] ? p[2] : {}).redirect, n = void 0 === n || n, i = "checkout", a = (o = this).integrations.widget, c = {
                                addToCart: function() {
                                    var t, e = r.match(/(\d+:\d+)+/g);
                                    return e ? (t = r.match(/discount=\w+/gi) ? .[0].split("=")[1], r.match(/storefront=true/gi) && (i = "cart"), {
                                        items: e.map(function(t) {
                                            return {
                                                id: +t.split(":")[0],
                                                quantity: +t.split(":")[1] ? ? 1
                                            }
                                        }),
                                        discount: t
                                    }) : null
                                },
                                checkout: function(t) {
                                    t = t.match(/[&?](updates\[(\d+)\]=(\d+))/g);
                                    return t ? {
                                        items: t.map(function(t) {
                                            t = t.match(/updates\[(\d+)\]=(\d+)/);
                                            return {
                                                id: +t[1],
                                                quantity: +t[2] ? ? 1
                                            }
                                        })
                                    } : null
                                }
                            }[e](r), u = c ? .items ? ? [], s = a.getCartAddRequestItems() ? ? [], u = [].concat(d(u), d(s)), l = {
                                redirect: n,
                                destination: i
                            }, u) {
                            t.next = 11;
                            break
                        }
                        return t.abrupt("return", oneClickUpsellGetCheckoutUrl(l));
                    case 11:
                        return c ? .discount && (l.discount = c.discount), a.disable(!0), t.abrupt("return", o.cart.add(null, null, {
                            items: u
                        }).then(v(S().mark(function t() {
                            return S().wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        if (s.length) return t.next = 3, a.accept();
                                        t.next = 4;
                                        break;
                                    case 3:
                                        a.clearState();
                                    case 4:
                                        return t.abrupt("return", oneClickUpsellGetCheckoutUrl(l));
                                    case 5:
                                    case "end":
                                        return t.stop()
                                }
                            }, t)
                        }))).catch(function() {
                            window.OCUDisableEvents = !0, Zipify.OCU.api.context.popupDispatcher.target.click()
                        }).finally(function() {
                            return a.disable(!1)
                        }));
                    case 14:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function Ct(t) {
        t = t.querySelector('form[action="/cart"]'), t = t && t.querySelector('input[type="submit"]');
        t && (t.type = "button", t.addEventListener("click", function(t) {
            self.checkout({
                redirect: !0
            })
        }))
    }

    function wt() {
        var t, e, r, n, a = document.querySelector(".bkt--upsell-target-checkout");
        a && (t = "input ", e = 'type="button" ', r = 'style="position:absolute;left:0;top:0;width:100%;height:100%;cursor:pointer;opacity:0" ', n = "data-ocu-dialog-btn ", a.style.position = "relative", a.insertAdjacentHTML("beforeend", "<" + t + e + r + n + ">"), document.querySelector("[data-ocu-dialog-btn]").addEventListener("click", function(t) {
            t.stopPropagation(), a.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="bkt--nc-icon" x="0px" y="0px" width="64px" height="15px" viewBox="0 0 64 64"><g><circle class="nc-dots-7-2" data-color="color-2" fill="#445FFF" cx="32" cy="32" r="26" transform="translate(6.26687999999989 6.26687999999989) scale(0.8041600000000034)" style="opacity:0.8041600000000034"></circle><circle class="nc-dots-7-1" fill="#445FFF" cx="-72" cy="32" r="26" transform="translate(3.2332800000000272 12.933120000000109) scale(0.5958399999999966)" style="opacity:0.5958399999999966"></circle><circle class="nc-dots-7-3" fill="#445FFF" cx="132" cy="32" r="26" transform="translate(33.6 19.2) scale(0.4)" style="opacity:0.4"></circle></g></svg>', o = 0, window.requestAnimationFrame || (window.requestAnimationFrame = function(t) {
                var e = (new Date).getTime(),
                    r = Math.max(0, 16 - (e - o)),
                    n = window.setTimeout(function() {
                        t(e + r)
                    }, r);
                return o = e + r, n
            });
            var o, d = [],
                h = null;
            d[0] = document.getElementsByClassName("nc-dots-7-1"), d[1] = document.getElementsByClassName("nc-dots-7-2"), d[2] = document.getElementsByClassName("nc-dots-7-3"), circleDots7Number = d[0].length, window.requestAnimationFrame(function t(e) {
                var e = e - (h = h || e),
                    r = Math.min(e / 250, 4);
                if (decimalRot = (r = 4 == r ? 0 : r) % 1, upperInteger = Math.ceil(r), e < 1e3 || (h += 1e3), d[0][0]) {
                    window.requestAnimationFrame(t);
                    var n = [],
                        o = [],
                        a = [],
                        c = [-72, 32, 132],
                        s = [32, 32, 32];
                    for (j = 0; circleDots7Number > j; j++)
                        for (n[0] = n[1] = n[2] = .4, 1 == upperInteger ? (n[0] = 1 - 3 * decimalRot / 5, n[1] = .4 + 3 * decimalRot / 5) : 2 == upperInteger ? (n[1] = 1 - 3 * decimalRot / 5, n[2] = .4 + 3 * decimalRot / 5) : 3 == upperInteger ? (n[1] = .4 + 3 * decimalRot / 5, n[2] = 1 - 3 * decimalRot / 5) : 4 == upperInteger ? (n[0] = .4 + 3 * decimalRot / 5, n[1] = 1 - 3 * decimalRot / 5) : n[0] = 1, i = 0; i < 3; i++) {
                            o[i] = (1 - n[i]) * c[i], a[i] = (1 - n[i]) * s[i], u = p = l = void 0;
                            var u, l = d[i][j],
                                p = {
                                    transform: "translate(" + o[i] + " " + a[i] + ") scale(" + n[i] + ")",
                                    style: "opacity:" + n[i] + ";"
                                };
                            for (u in p) l.setAttribute(u, p[u])
                        }
                }
            }), self.checkout({
                redirect: !0
            })
        }))
    }

    function Ot() {
        var t = document.querySelectorAll('a[href="/checkout"]');
        Array.prototype.forEach.call(t, function(t) {
            t && t.addEventListener("click", function(t) {
                t.stopPropagation(), t.preventDefault(), self.checkout({
                    redirect: !0
                })
            })
        })
    }

    function Pt() {
        var t, e = document.querySelector('input[name="discount"]'),
            r = _.cookie.get("ocu-share-discount"),
            n = _.cookie.get("popupcookie");
        window._chpmgr && !n || (e || r) && (e && (t = e.value), r && (t = r, _.cookie.remove("ocu-share-discount")), n = {
            name: "discount",
            value: encodeURIComponent(t)
        }, e = _.store.get("params"), r && "page" === f.template_name || !n.value || (e.arr.push(n), _.store.set("params", e)))
    }

    function xt() {
        var t = this;
        this.isSubscription = function(t) {
            return (t.cart || t.data.cart || t.data).items.some(function(t) {
                return t.selling_plan_allocation ? null : t.properties && (t.properties.subscription_id || t.properties.shipping_interval_frequency)
            })
        }, this.processCart = function() {
            window.reChargeProcessCart = function() {
                t.checkout({
                    redirect: !0
                })
            }
        }, this.redirect = function(t, e, i) {
            var r = OCUApi.customRechargeUrl || "https://checkout.rechargeapps.com";

            function o() {
                var t = ["myshopify_domain=" + Shopify.shop];
                return r + "/r/checkout?" + (t = t.concat(function() {
                    try {
                        return ["cart_token=" + (document.cookie.match("(^|; )cart=([^;]*)") || 0)[2]]
                    } catch (t) {
                        return []
                    }
                }()).concat(function() {
                    try {
                        return [ga.getAll()[0].get("linkerParam")]
                    } catch (t) {
                        return []
                    }
                }())).join("&")
            }

            function l(t) {
                return t.filter(function(t) {
                    var e = "radio" === t.getAttribute("type") && t.checked,
                        r = "checkbox" === t.getAttribute("type") && t.checked,
                        n = "checkbox" !== t.getAttribute("type") && "radio" !== t.getAttribute("type");
                    return !!t.value && (n || e || r)
                })
            }

            function a() {
                var t, n = /attributes\[(.*?)\]/,
                    i = /\[(.*?)\]/,
                    e = document.querySelectorAll(['[name*="attributes"]'].join(",")),
                    e = l(Array.prototype.slice.apply(e)),
                    o = {},
                    r = function() {
                        var e = /^_shopify_sa_p/,
                            r = /^utm_/,
                            n = /^_shopify_sa_t/,
                            i = {},
                            o = "",
                            a = "",
                            t = (document.cookie.split(";").map(function(t) {
                                return t.trim()
                            }).forEach(function(t) {
                                e.test(t) && (o = t), n.test(t) && (a = decodeURIComponent(t.split("=")[1]))
                            }), o.split("=")[1]);
                        if (decodeURIComponent(t).split("&").forEach(function(t) {
                                var e = t.split("=")[0],
                                    t = t.split("=")[1];
                                if (r.test(e)) return i[e] = t
                            }), Object.keys(i).length) return i.utm_timestamp = a, i.utm_data_source = "shopify_cookie", i
                    }(),
                    a = new URLSearchParams(decodeURIComponent(window.location.search)),
                    c = h(a);
                try {
                    for (c.s(); !(t = c.n()).done;) {
                        var s, u = t.value;
                        n.test(u[0]) && (s = (s = u[0].match(i)[0]).substring(1, s.length - 1), o[s] = a.get(u[0]))
                    }
                } catch (t) {
                    c.e(t)
                } finally {
                    c.f()
                }
                return e.forEach(function(t) {
                    var e, r = t.getAttribute("name"),
                        t = t.value;
                    return n.test(r) ? (e = (e = r.match(i)[0]).substring(1, e.length - 1), o[e] = t) : o[r] = t
                }), r && Object.keys(r).forEach(function(t) {
                    o[t] = r[t]
                }), Object.keys(o).length ? {
                    attributes: Object.assign({}, o)
                } : {}
            }

            function n() {
                return fetch("/cart.js").then(function(t) {
                    return t.json()
                }).then(function(t) {
                    return {
                        cart: JSON.stringify(t)
                    }
                }).catch(function(t) {
                    return console.error("Error retreiving cart: ", t), {
                        cart: {}
                    }
                }).then(function(t) {
                    var e, r, n = {};
                    return [(r = document.querySelectorAll(["#terms", "#agree"].join(",")), (r = l(Array.prototype.slice.apply(r)).map(function(t) {
                        return t.value
                    })).length ? {
                        terms_and_conditions: r.join(", ")
                    } : {}), (r = document.querySelectorAll(['[name="note"]'].join(",")), r = Array.prototype.slice.apply(r).filter(function(t) {
                        return !!(t.offsetWidth || t.offsetHeight || t.getClientRects().length)
                    }).map(function(t) {
                        return t.value
                    }), (e = new URLSearchParams(decodeURIComponent(window.location.search)).get("note")) && r.push(e), r.length ? {
                        note: r.filter(function(t, e, r) {
                            return r.indexOf(t) === e
                        }).join(", ")
                    } : ""), a(), n = t].forEach(function(t) {
                        Object.assign(n, t)
                    }), n
                })
            }

            function c(t, e) {
                var r, n, i = document.createElement("form");
                return i.setAttribute("method", "post"), i.setAttribute("action", e), i.setAttribute("id", "rc_form"), i.style.display = "none", r = i, n = t, Object.keys(n).forEach(function(t) {
                    var e = document.createElement("input");
                    e.setAttribute("type", "hidden"), e.setAttribute("name", t), e.setAttribute("value", "object" == U(n[t]) ? JSON.stringify(n[t]) : n[t]), r.appendChild(e)
                }), i
            }
            n().then(function(e) {
                var r, n;
                d(JSON.parse(e.cart).items).some(function(t) {
                    return t.properties && (t.properties.shipping_interval_unit_type || t.properties.shipping_interval_frequency)
                }) ? (r = o(), e ? ((n = new XMLHttpRequest).open("POST", "/cart/update.js"), n.setRequestHeader("Content-Type", "application/json"), n.onload = function() {
                    200 === n.status ? window.console.log("done", JSON.parse(n.responseText)) : 200 !== n.status && window.console.log("fail", JSON.parse(n.responseText));
                    var t = c(e, r);
                    document.body.appendChild(t), t.submit()
                }, n.send(JSON.stringify(e))) : window.location.href = r) : window.location.href = i || "/checkout"
            })
        }
    }

    function At() {
        var t, e, r, n, i = this;
        ~document.head.innerHTML.indexOf("bundle-upsell") && (t = document.querySelectorAll("[name='checkout'], [href^='/checkout'], form[action='/checkout'] [type='submit'], #checkout, [name='goto_pp'], .checkout_button"), Array.prototype.forEach.call(t, function(t) {
            t.disabled = !0
        }), e = 0, r = setInterval(function() {
            (++e && 7 < e || window.SMAR7 && SMAR7.bundle) && (Array.prototype.forEach.call(t, function(t) {
                t.disabled = !1
            }), clearInterval(r))
        }, 3e3), n = function(t) {
            var e = _.store.get("params");
            t ? (SMAR7.util.setCookie("smar7coupon", t, 3600), e.arr.push({
                name: "discount",
                value: encodeURIComponent(t)
            })) : t = SMAR7.bundle.helper.determineCoupon && SMAR7.bundle.helper.determineCoupon(), SMAR7.paypal ? (encodeURIComponent(t), document.querySelector('[name="goto_pp"]')) : (encodeURIComponent(t), document.querySelector('[name="checkout"], [href="/checkout"], form[action="/checkout"] input[type="submit"], #checkout')), _.store.set("params", e), i.checkout({
                redirect: !0
            })
        }, document.addEventListener("click", function() {
            window.SMAR7 && SMAR7.bundle && (SMAR7.bundle.redirect = n)
        }, !0))
    }

    function St() {
        var e = this;
        this.initSeal = function() {
            document.addEventListener("sealsubs:subscription_widget_created", function(t) {
                e.initPriceUpdate()
            })
        }, this.initPriceUpdate = function() {
            document.addEventListener("sealsubs:price_update", function(t) {
                _.store.set("sealSellingPlanPrice", t.detail.price)
            })
        }
    }

    function Ut() {
        var i = this,
            t = new bt,
            e = new xt,
            r = new St,
            n = new ft,
            o = new mt,
            a = new ht;
        this.list = {
            bold: {
                get isInstalled() {
                    return window.BOLD && BOLD.apps_installed
                },
                get productOptions() {
                    return this.isInstalled && BOLD.apps_installed["Product Options"]
                },
                get productUpsell() {
                    return this.isInstalled && BOLD.apps_installed["Product Upsell"]
                }
            },
            recharge: {
                isSubscriptionProduct: function(t) {
                    return t.items.some(function(t) {
                        return t.properties && (t.properties.subscription_id || t.properties.shipping_interval_frequency)
                    })
                }
            }
        }, this.boldUpsellCheckoutOffer = function() {
            var t;
            if (window.BOLD && window.Shopify) return t = {
                data: {
                    cart: {
                        items: f.cart.items,
                        total_price: f.cart.total_price
                    }
                }
            }, k.request({
                method: "post",
                url: window.BOLD.upsell.path + window.Shopify.shop + "/validate_checkout_offer",
                data: JSON.stringify(t)
            })
        }, this.needSkipClick = this.list.bold.productOptions || this.list.bold.productUpsell, this.start = function() {
            "cart" !== f.template_name && this.sealUpdatePrice(), f.upsell_cart_include_upsells && "cart" !== f.template_name && this.main()
        }, this.main = function() {
            var e = function(t) {
                if ("attributes" === t.type && t.target === document.querySelector(i.ocuSelectors) && /cart-?(popup|container|drawer)/i.test(t.target.id) && /bold-upsell-modal-window/i.test(t.target.id)) {
                    if ("bold-upsell-modal-window" === t.target.id) return i.boldUpsellPopup(t.target);
                    var e = document.querySelectorAll(i.ocuSelectors),
                        r = "true" === e[0].dataset.disableRecharge,
                        n = Array.prototype.forEach;
                    n.call(e, function(t) {
                        "Checkout" === t.innerHTML && t.removeAttribute("onclick")
                    }), f.disabled_by_subscription_app && r || (n.call(e, function(t) {
                        t.disableRecharge = !0
                    }), i.cartPopup(), i.cartDrawer(t.target), i.checkoutLinks(), i.listenEvents())
                }
            };
            new MutationObserver(function(t) {
                t.forEach(e)
            }).observe(document, {
                childList: !0,
                subtree: !0,
                attributes: !0
            }), i.buyNowBtns(), i.recharge.processCart(), i.revy()
        }, this.createGemPages = function(t) {
            t = t.closest("gp-product");
            this.gemPages = new E, t && (this.gemPages = new gt), window ? .__gemStoreData && (this.gemPages = new yt), this.gemPages.handleGPPopup()
        }, this.revy = function() {
            window.RevyApp && RevyApp.events && (RevyApp.events.updatedCart = [])
        }, this.discounts = Pt, this.smar7 = At, this.isBoldRecuring = t.isBoldRecuring, this.boldRecurring = t.initRecurring, this.bold = t, this.boldUpsellPopup = t.upsellPopup, this.cartPopup = wt, this.cartDrawer = Ct, this.checkoutLinks = Ot, this.handlePermalink = window.oneClickUpsellHandlePermalink = function(t, e) {
            return _t.apply(this, arguments)
        }.bind(this), this.buyNowBtns = kt, this.recharge = e, this.amazonPay = vt, this.zipifyPages = n, this.pageFly = o, this.widget = a, this.sealUpdatePrice = r.initSeal, this.start()
    }

    function It() {
        var e, r;
        history.pushState = (e = history.pushState, function() {
            var t = e.apply(this, arguments);
            return window.dispatchEvent(new Event("pushState")), window.dispatchEvent(new Event("locationchange")), t
        }), history.replaceState = (r = history.replaceState, function() {
            var t = r.apply(this, arguments);
            return window.dispatchEvent(new Event("replaceState")), window.dispatchEvent(new Event("locationchange")), t
        }), window.addEventListener("popstate", function() {
            window.dispatchEvent(new Event("locationchange"))
        })
    }
    var Et, Tt, qt, Dt, Lt, T, q, Ft = window.Symbol ? Symbol("appendChain") : "oneClickUpsellAppendChain";

    function D(t) {
        this.res = t, this.isCartUpdated = _.store.get("cartUpdated"), this.isOfferDeclined = _.store.get("offerDeclined"), this.options = {
            add: {
                method: "post",
                url: "".concat(OCUApi.shopifyRoot, "cart/add.js")
            },
            change: {
                method: "post",
                url: "".concat(OCUApi.shopifyRoot, "cart/change.js")
            },
            update: {
                method: "post",
                url: "".concat(OCUApi.shopifyRoot, "cart/update.js")
            }
        }, this.regs = {
            attributes: /\[(.+?)\]/,
            key: /(?:(?:updates|quantity)_(?:.*?))?(\d+:\w+)/,
            id: /(?:(?:updates|quantity)_(?:.*?))?(\d+):?/,
            noId: /(\d+(:\w+)?)$/
        }, this.selectors = {
            form: 'form[action^="/checkout"], form[action^="/cart"]',
            attributes: '[name^="attributes["]',
            currency: '[name="currency"]',
            localization: 'form[action="/localization"]',
            geolocation_currency: 'input[name="currency_code"]',
            updates: '[name^="updates["], [data-cart-item-input-quantity], [data-cart-item-quantity], input[data-line], [name="quantity"], [data-quantity-input]' + (OCUApi.customQuantityInput || ""),
            note: '[name="note"]',
            noteOutOfForm: '[form="cart"][name="note"]',
            noteOnCart: '.ocu-cart-drawer [name="note"]',
            cartItemKey: "[data-cart-item-key], [data-cart-item], [data-variant]"
        }, this.data = {
            currency: Shopify.currency.active !== f.shop_currency ? Shopify.currency.active : f.shop_currency,
            attributes: {},
            lineItems: [],
            updates: {},
            changes: [],
            sameIds: [],
            note: ""
        }, this.payload = {
            updates: {},
            currency: "",
            note: null,
            attributes: {}
        }, window.klpixel || OCUApi.preventRestoreXMLHttp || this._restoreXMLHttp()
    }

    function jt() {
        var n = this;
        this.init = function() {
            var t = /index|collection|product/.test(f.template_name);
            f.skip_cart && t && setTimeout(n.prepare)
        }, this.prepare = function() {
            function e(t) {
                return Array.prototype.slice.call(t)
            }
            Array.prototype.forEach;
            var t = e(document.querySelectorAll(".product-form__cart")),
                r = (r = e(document.querySelectorAll('form[action*="cart"], [data-zp-add-to-cart-form], #AddToCartForm1'))).filter(function(t) {
                    return "zipify_page" !== t.dataset.zpLinkType
                });
            (r = t.length ? r.concat(t) : r).forEach(function(t) {
                e(t.querySelectorAll('*[type="submit"], input[type="button"], button')).forEach(function(t) {
                    t.dataset.pfType && "ProductATC" !== t.dataset.pfType || /plus|minus|zpa-quantity/.test(t.className) || /error_txt|quantity|sold-out/i.test(t.id) || /amount|review/i.test(t.value) || t.dataset.qty || t.dataset.quantityAction || t.getAttribute("aria-controls") || "product" === t.dataset.zpLinkType || t.closest("quantity-input, cart-remove-button") || (t.removeAttribute("onclick"), t.dataset.ocuSkipCart = !0, t.type = "button")
                })
            }), n.listenEvents(r)
        }, this.handle = function(e) {
            var t = n.handleZPEvent(e);
            if (!t) {
                t = OCUApi.customButtonLoader ? .(e);
                if (t ? .startLoading(), n.popupDispatcher.target || (n.popupDispatcher.target = e.target), !n.popupDispatcher.isProductAction || n.popupDispatcher.secondAttempt) {
                    t = e.target.dataset.ocuSkipCart ? e.target : null;
                    if (!(t = t || e.target.closest("[data-ocu-skip-cart]"))) return n.popupDispatcher.target = null;
                    t.disabled = !0, e.stopImmediatePropagation(), e.stopPropagation(), e.preventDefault();
                    var r = (r = t.closest("form")) || document.querySelector('form[action="/cart/add"]');
                    n.cart.add(r, t, OCUApi.getCustomAddToCartData ? .().payload).then(n.cart.get).then(function(t) {
                        return (OCUApi.customButtonLoader ? .(e)) ? .endLoading(), t
                    }).then(n.onSuccess).catch(n.onError.bind(null, r))
                }
            }
        }, this.onSuccess = function(t) {
            if (OCUApi.fireAddToCartEvent && OCUApi.fireAddToCartEvent(t.data), _.store.set("cart_token", t.data.token), n.helpers.isSubscriptionProductInCart(t.data)) return location = "/cart";
            n.checkout({
                redirect: !0
            })
        }, this.onError = function(t) {
            t.submit()
        }, this.listenEvents = function(t) {
            OCUIncart.metafields.main.general.settings ? .offer_scripts ? .["zipify-oneclickupsell-on-page"] || OCUIncart.popupLocation.product || document.addEventListener("click", n.handle, !0)
        }, this.handleZPEvent = function(t) {
            var e, r;
            return OCUApi.customSkipCartZPEventHandler ? OCUApi.customSkipCartZPEventHandler() : !!((r = (e = function(t) {
                return void 0 !== t.dataset.zpAddToCart
            })(r = t.target) ? r : r.closest("[data-zp-add-to-cart]")) && t.isTrusted && e(r)) && (r.type = "submit", r.click(), !0)
        }, this.init()
    }

    function L(t, a) {
        var c, e, s = this;
        f.themePopup && f.isThemePopupTag || (t.isTrusted || this.popupDispatcher.ignoreTrust) && (c = t.target.closest('form[action="/cart/add"]') || document.querySelector('form[action="/cart/add"]')) && (t.stopImmediatePropagation(), t.preventDefault(), t.target.disabled = !0, e = function() {
            var t = v(S().mark(function t() {
                var e, r, n, i, o;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            if (e = a.isWidgetPresent, r = a.proceed, n = a.disable, i = a.accept, o = a.clearState, e()) return t.next = 4, r();
                            t.next = 9;
                            break;
                        case 4:
                            return n(!0), t.next = 7, i(c);
                        case 7:
                            o(), n(!1);
                        case 9:
                            s.checkout({
                                redirect: !0,
                                destination: "checkout"
                            });
                        case 10:
                        case "end":
                            return t.stop()
                    }
                }, t)
            }));
            return function() {
                return t.apply(this, arguments)
            }
        }(), s.cart.add(c, t.target).then(e).catch(function(t) {
            t.submit()
        }.bind(null, c)))
    }

    function Rt() {
        var a = this,
            r = a.__proto__.__proto__,
            i = OCUIncart.integrations(),
            c = !1;
        this.init = function() {
            window.oneClickUpsellGetCheckoutUrl = r.checkout = a.create, r.verify = a._verify.bind(this)
        }, this.create = function() {
            var e = v(S().mark(function t(n) {
                var e, r, i, o;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            if (c) return t.abrupt("return");
                            t.next = 2;
                            break;
                        case 2:
                            if (c = !0, setTimeout(function() {
                                    return c = !1
                                }, 50), "skip_cart" === n) return t.abrupt("return", new Promise(function(t) {
                                t(f.skip_cart)
                            }));
                            t.next = 6;
                            break;
                        case 6:
                            if (e = _.cookie.get("ocu_progress_bar") && _.cookie.get("ocu_progress_bar").length, o = OCUIncart.hasNotOfferInCart, r = _.cookie.get("ocu_header"), i = n && n.redirect_url, !o && !i || r || e || Zipify.Cart ? .loaded) {
                                t.next = 12;
                                break
                            }
                            return t.abrupt("return", a._checkout(n));
                        case 12:
                            if (n.discount && _.cookie.set("ocu-share-discount", n.discount), OCUIncart.hasWidgetOffersInCart) return t.next = 16, a.cart.get("?ocu");
                            t.next = 18;
                            break;
                        case 16:
                            o = t.sent, OCUIncart.cart_items = o.data.items;
                        case 18:
                            return t.abrupt("return", a._verify().then(function() {
                                var e = v(S().mark(function t(e) {
                                    var r;
                                    return S().wrap(function(t) {
                                        for (;;) switch (t.prev = t.next) {
                                            case 0:
                                                if (r = e ? .data ? .discount_data) return t.next = 4, OCUApi.handleAutomaticDiscounts(OCUIncart.cart_items, r);
                                                t.next = 4;
                                                break;
                                            case 4:
                                                if (e ? .data ? .remove_free_shipping && !_.store.get("removed_free_shipping")) return t.next = 7, OCUApi.updateCartDetails({
                                                    attributes: {
                                                        __ocu_shipping_offer_data: null
                                                    }
                                                });
                                                t.next = 8;
                                                break;
                                            case 7:
                                                _.store.set("removed_free_shipping", !0);
                                            case 8:
                                                return t.abrupt("return", a._checkout(Object.assign(n, {
                                                    redirect_url: e.data.redirect_url || f.checkoutUrl,
                                                    verified: e.data.verified
                                                })));
                                            case 9:
                                            case "end":
                                                return t.stop()
                                        }
                                    }, t)
                                }));
                                return function(t) {
                                    return e.apply(this, arguments)
                                }
                            }()).catch(function() {
                                a._checkout(n)
                            }));
                        case 19:
                        case "end":
                            return t.stop()
                    }
                }, t)
            }));
            return function(t) {
                return e.apply(this, arguments)
            }
        }(), this.prepare = function(t) {
            var e = _.store.get("params");
            a.config = t || {}, a.config.discount && _.cookie.set("ocu-share-discount", t.discount), a.config.incarts && _.store.set("incarts", a.config.incarts), a.config.path && _.store.set("amazonPath", a.config.path), a.config.button && a.helpers.payPal(a.config.button), a.integrations.discounts(), a.params(), a.handleDeclineOffer(t), i.tidio.present && i.tidio.track(), OCUApi.preventReloadPersistedPage && (c = !1), e.str = e.str ? e.str.replace(/^\?*/, "?") : "", a.config.checkoutUrl = (a.config.redirect_url || f.checkoutUrl) + e.str, _.store.set("params", e)
        }, this.redirect = function(t) {
            window.OCUApi ? .context ? .popupDispatcher ? ._upsellAppInstance() ? .hide();
            var e = a.integrations.recharge,
                r = i.bundlerBuilder;
            return r.present ? r.submit() : e.isSubscription(f) ? e.redirect(null, null, t.checkout_url) : "checkout" === t.destination || f.skip_cart ? location.assign(t.checkout_url) : void location.assign("/" + t.destination)
        }, this._checkout = function(t) {
            a.prepare(t);
            var e = {
                status: !1,
                verified: t.verified,
                checkout_url: a.config.checkoutUrl,
                skip_cart: f.skip_cart,
                get redirect_url() {
                    return this.checkout_url
                },
                destination: t.destination || r.popupDispatcher.destination
            };
            return a.config.redirect ? this.redirect(e) : new Promise(function(t) {
                t(e)
            })
        }, this._verify = function() {
            var t = window.OCUIncart && OCUIncart.appEndpoint,
                e = {
                    "Content-Type": "application/json",
                    "Shop-Domain": f.permanent_domain
                },
                r = this._verifyPayload();
            return a.helpers.validateAppropriate(r, ["cart_token", "line_items"]) ? new Promise(function(t) {
                return t(response)
            }) : OCUApi.axios.post(t + "/pre_purchase/v1/draft_orders/verify", r, {
                headers: e
            })
        }, this._verifyPayload = function() {
            var t = _.cookie.get("cart").replace(/\?.+/, ""),
                e = a.helpers.getCartItems(OCUApi.cart ? ? OCUIncart.cart_items),
                r = {
                    checkout: {
                        line_items: e = a.integrations.zipifyPages.appendZipifyPagesProduct(e.line_items)
                    }
                },
                n = +_.cookie.get("ocu_progress_bar"),
                i = OCUIncart.header_type || _.cookie.get("ocu_header");
            return r.checkout = Object.assign(r.checkout, {
                cart_token: t,
                verify_draft_order: !0,
                note: f.cart.note,
                attributes: f.cart.attributes,
                currency_rate: window.Shopify && Shopify.currency && +Shopify.currency.rate || 1,
                threshold: n,
                header_type: i,
                selling_plan: a.helpers.hasSellingPlan(e)
            }), r.currency = this.helpers.currencyRate(), r.customer_tags = f.customer_tags || [], r.customer_location = OCUIncart.customer_location.handle, r.snippet_version = OCUIncart.version, r
        }, this.params = function() {
            var e = _.store.get("params"),
                n = i.zapiet,
                t = i.simpleInStorePickup,
                r = i.weglot;
            n.present && (a.config.params = n.merge(a.config.params)), t.present && (a.config.params = t.merge(a.config.params)), r.present && (a.config.params = r.merge(a.config.params)), (a.config.params || []).concat(a.gaLinker()).concat({
                t: +Date.now()
            }).map(function(r) {
                return Object.keys(r).map(function(t) {
                    var e = "discount" === t || n.present ? r[t] : encodeURIComponent(r[t]);
                    return {
                        name: encodeURIComponent(t),
                        value: e
                    }
                })[0]
            }).forEach(function(t) {
                e.arr.push(t)
            }), _.store.set("params", e), a.helpers.params()
        }, this.handleDeclineOffer = function(e) {
            var t;
            e && e.incarts && (t = Object.keys(e.incarts).some(function(t) {
                return "declined" === e.incarts[t].status
            }), _.store.set("offerDeclined", t))
        }, this.gaLinker = function() {
            try {
                var t = ga.getAll()[0].get("linkerParam").split("="),
                    e = {};
                return e[t[0]] = t[1], [e]
            } catch (t) {
                return []
            }
        }, this.init()
    }

    function F() {
        var a = this;
        this.disableButtons = function() {
            _.store.set("checkoutButtonState", !1)
        }, this.params = function() {
            var t = _.store.get("params"),
                e = Object.fromEntries(t.arr.map(function(t) {
                    return [t.name, t.value]
                }));
            t.str = Object.entries(e).map(function(t) {
                var t = l(t, 2),
                    e = t[0],
                    t = t[1];
                return "".concat(e, "=").concat(t)
            }).join("&"), _.store.set("params", t)
        }, this.redirect = function(t) {
            var e;
            return t.redirect_url ? location.assign(t.redirect_url) : f.subscription_products_size ? (e = document.querySelector('form[action="/checkout"], form[action="/cart"]')) ? void e.submit() : a.checkout({
                redirect: !0
            }) : location.assign(t.checkout_url)
        }, this.simulateSubmit = function() {
            var t = document.querySelectorAll(a.ocuSelectors);
            if (!t.length) return location = "/cart";
            Array.prototype.slice.call(t, -1)[0].dispatchEvent(new MouseEvent("click"))
        }, this.simulateDocumentClick = function() {
            var t = new Event("click"),
                e = document.createElement("button");
            e.type = "submit", e.name = "checkout", Object.defineProperty(t, "target", {
                value: e
            }), document.dispatchEvent(t)
        }, this.preventMouseDown = function(t) {
            t.preventDefault(), t.stopPropagation()
        }, this.payPal = function(t) {
            var e;
            "goto_pp" === t.name && "paypal_express" === t.value && ((e = _.store.get("params")).arr.push({
                name: t.name,
                value: t.value
            }), _.store.set("requirePayPal", !0), _.store.set("params", e))
        }, this.filterFields = function(t) {
            var e = _.store.get("neededCartFileds"),
                r = _.store.get("neededCartItemsFields");
            return (t = _.filterObject(t, e)).items = t.items.map(function(t) {
                return _.filterObject(t, r)
            }), t
        }, this.filterCartItemFields = function(t) {
            return t.map(function(r) {
                return Object.keys(r).reduce(function(t, e) {
                    return "product_description" !== e && (t[e] = r[e]), t
                }, {})
            })
        }, this.checkSelector = function(t, e) {
            if (e.closest(OCUApi.excludeActionButton)) return null;
            if ("true" === e.dataset.ocuCheckout) return e;
            if ("open" === e.shadowRoot ? .mode) {
                t = OCUIncart.integrations().cartWithShadowRoot(t);
                if (t) return t
            }

            function r(t) {
                return (t = e.closest(t)) && "FORM" !== t.tagName ? t : null
            }
            var t = document.querySelectorAll(a.ocuSelectors),
                t = Array.prototype.some.call(t, function(t) {
                    return t === e
                }),
                n = e.closest(".cart_content") && e.closest('form[action="/checkout"] [type="submit"]'),
                i = "cart" === f.template_name && e.closest('form[action="/cart"] [type="submit"]'),
                n = r(a.ocuSelectors) || n || i,
                i = !e.closest(".nudge-offer"),
                o = "product" === f.template_name && !e.closest('form[action$="/cart/add"]') && (("add" === e.name && "submit" === e.type ? e : null) || e.closest('[name="add"]') && e.closest('[type="submit"]')),
                n = !t && (n || r('[name="checkout"]')) || o;
            return (t || n) && i ? t ? e : n : void 0
        }, this.checkDirectCheckoutButtons = function(t) {
            return /\/checkout/.test(t.onclick && t.onclick.toString())
        }, this.checkAddToCart = function(t) {
            var e, r, n;
            return t.closest(OCUApi.excludeActionButton) || t.closest(_.store.get("excludeAddToCartButton")) ? null : (e = OCUIncart.integrations().stickyATC(t)).present ? e.button : (e = OCUApi.context.integrations.pageFly.isPageFlyButton(t), (r = /^(submit|add|checkout)$/.test(t.name) || this.isActionButton(t) || e) && OCUApi.customAddToCartButton || this.isShopPayInstallments({
                target: t
            }) ? t : (n = OCUApi.customAddToCartForm || 'form[action*="/cart/add"],form[data-zp-add-to-cart-form]', (r || this.isBuyNow({
                target: t
            })) && (e || t.closest(n))))
        }, this.checkPermalink = function(t) {
            return this.getPermalinkType(t.href) || (t = t.closest('a[href*="/cart/"],a[href*="/checkout?updates["]'), this.getPermalinkType(t ? .href)) ? t : null
        }, this.zpPreventRedirect = function(t) {
            if ("crm_dest" === t.dataset.type || "" === t.dataset.zpProductRedirectLink || "" === t.dataset.zpAddToCart || t.closest('[data-type="crm_dest"]') || t.closest("[data-zp-product-redirect-link]") || t.closest("[data-zp-add-to-cart]")) return !0
        }, this.isOfferProduct = function() {
            return f.cart_variants_json.some(function(t) {
                return t.properties && t.properties._ocu_offer_id
            })
        }, this.addBuyXGetYDiscount = function(t) {
            var e = t.data.items.reduce(function(t, e) {
                var r;
                return e.discounts[0] && (r = {
                    item_key: e.key,
                    discount: e.discounts
                }, e.line_level_discount_allocations[0] && (r.discount_data = e.line_level_discount_allocations), t.push(r)), t
            }, []);
            return e.length && (t.data.per_item_discounts = e), t
        }, this.getPermalinkType = function(e) {
            return "string" != typeof e ? null : [{
                type: "addToCart",
                regexp: /\/cart\/(\d+):(\d+)/g
            }, {
                type: "checkout",
                regexp: /\/checkout.?[?]updates\[(\d+)]=(\d+)/g
            }].find(function(t) {
                return e.match ? .(t.regexp)
            }) ? .type ? ? null
        }, this.isActionButton = function(r) {
            var t = ['[type="submit"]', '[name="add"]', '[name="checkout"]', '[data-ocu-skip-cart="true"]', 'a[href*="/cart/"]', 'a[href*="/checkout?updates["]'];
            return OCUApi.customAddToCartButton && t.push(OCUApi.customAddToCartButton), t.reduce(function(t, e) {
                e = r.closest(e);
                return t = e && "FORM" !== e.tagName ? !0 : t
            }, !1)
        }, this.isCheckoutButton = function(t) {
            return !!t && "checkout" === t.name
        }, this.isBuyNow = function(t) {
            var e;
            return !!t && (e = _.store.get("classList"), t.target.classList.contains(e.buyNow) && !t.target.classList.contains(e.buyNowBranded) || !!t.target.closest(e.customBuyNowButton) || this.isShopPayInstallments(t))
        }, this.isShopPayInstallments = function(t) {
            var e = _.store.get("shopPayInstallments").parent;
            return !!t && t.target.closest(e)
        }, this.getCartItems = function(t) {
            var r = OCUIncart.integrations().advancedProductOptions,
                e = ["key", "properties", "quantity", "variant_id", "product_id", "price", "original_price", "discounted_price", "line_price", "original_line_price", "final_price", "final_line_price", "handle", "title", "options_with_values", "selling_plan_allocation"];
            return {
                line_items: t.map(function(r) {
                    return e.reduce(function(t, e) {
                        return t[e] = r[e] || 0 === r[e] ? r[e] : {}, t
                    }, {})
                }).map(function(t) {
                    var e;
                    return r ? .present && (e = l(t.properties._mw_option_relation ? .split("_") ? ? [], 1)[0], isNaN(e) || (t.variant_id = Number(e))), t
                })
            }
        }, this.isSameCart = function(t) {
            var e = _.cookie.get("ocu_cart_items"),
                t = t.items.map(function(t) {
                    return t.key
                });
            return _.cookie.set("ocu_cart_items", JSON.stringify(t)), !!e && (t = new Set(t), e = new Set(JSON.parse(e)), this.areSetsEqual(t, e))
        }, this.isSameCartToken = function(t) {
            return t.token === _.cookie.get("ocu_popup_token")
        }, this.areSetsEqual = function(t, e) {
            return t.size === e.size && Array.from(t).every(function(t) {
                return e.has(t)
            })
        }, this.isSubscriptionProductInCart = function(t) {
            return t.items.reduce(this.isSubscriptionItem, null)
        }, this.isSubscriptionItem = function(t, e) {
            var r = _.store.get("subscriptionProperties"),
                n = t;
            return Object.entries(r).some(function(t) {
                return t[1].some(function(t) {
                    return e.properties && e.properties[t]
                }) && !e.selling_plan_allocation ? n = t[0] : n
            }), n
        }, this.showCheckoutButton = function() {
            var t = _.store.get("checkoutButton"),
                e = document.querySelector(t.selector),
                r = OCUIncart.integrations().exemptify;
            e && !r.present && Object.entries(t.excludes).every(function(t) {
                return !t[1].test(e[t[0]])
            }) && "none" === e.style.display && (e.style.display = "inline-block")
        }, this.clearFallback = function() {
            var t = _.store.get("fallback").id;
            clearTimeout(t)
        }, this.beforeCreate = function() {
            _.store.get("salesRocketIntegrationApplied") && (e = document.querySelector(_.store.get("cartDrawerSalesRocketControl").selector)) && e.click();
            var t, e = document.querySelector(_.store.get("cartDrawerTimberControl").selector),
                e = (e && e.click(), document.querySelector(_.store.get("cartDrawerControl").selector)),
                e = (e && e.click(), document.querySelector(_.store.get("chatButton").selector)),
                e = (e && e.remove(), document.querySelector(OCUApi.customCartDrawerCloseButton)),
                r = (e && e.click(), h(document.querySelectorAll("dialog")));
            try {
                for (r.s(); !(t = r.n()).done;) {
                    var n = t.value;
                    n.open && n.close()
                }
            } catch (t) {
                r.e(t)
            } finally {
                r.f()
            }
            window.upcartCloseCart ? .(), OCUApi.beforeCreate ? .(), "checkout" === OCUApi.context.popupDispatcher.destination && document.querySelector("#dynamic-checkout-cart") ? .remove()
        }, this.isDisabledButton = function(t) {
            var e;
            return !OCUApi.isButtonDisabledAfterClick && (e = t.closest("button"), t = "button" === t.tagName.toLowerCase() ? t : e) && (t.disabled || !!t.ariaDisabled)
        }, this.termsOfServiceConfirmation = function(t) {
            t = t.closest('form[action="/checkout"], form[action="/cart"]'), t = t && t.querySelector(_.store.get("termsOfServiceCheckbox").selector);
            return t && !t.checked
        }, this.isCartPopupRedirectsToCart = function(t) {
            if (t.target.dataset.ocuCheckout && "cart" !== f.template_name) return Shopify.theme_settings && !1 === Shopify.theme_settings.go_to_checkout
        }, this.removeExtraClassList = function(t) {
            var e;
            t && (e = _.store.get("extraClassListToRemove").join(","), t.classList.remove(e))
        }, this.currencyRate = function() {
            return window.Shopify ? .currency ? ? (OCUApi.currencyCode ? {
                active: OCUApi.currencyCode,
                rate: 1
            } : {})
        }, this.validateAppropriate = function(n, i) {
            var t = ["cart_token", "currency", "line_items", "customer_location"].reduce(function(t, e) {
                var r = "object" === U(n[e]);
                return i ? .includes(e) || (!n[e] || r && 0 === Object.keys(n[e]).length) && t.push(e), t
            }, []);
            return t.length && console.log("Undefined payload keys OCU:", t), !!t.length
        }, this.getLocation = function() {
            return OCUApi.axios.get("/browsing_context_suggestions.json").then(function(t) {
                return OCUIncart.customer_location = t.data ? .detected_values ? .country || {
                    handle: null
                }
            }).catch(function() {
                return OCUIncart.customer_location = {
                    handle: null
                }
            })
        }, this.preventFallbackRedirect = function() {
            clearTimeout(_.store.get("fallback").id)
        }, this.deepEqual = function t(e, r) {
            function n(t) {
                return null != t && "object" === U(t)
            }
            if (!e || !r) return !1;
            var i = Object.keys(e),
                o = Object.keys(r);
            if (i.length !== o.length) return !1;
            for (var a = 0, c = i; a < c.length; a++) {
                var s = c[a],
                    u = e[s],
                    s = r[s],
                    l = n(u) && n(s);
                if (l && !t(u, s) || !l && u !== s) return !1
            }
            return !0
        }, this.getCustomAddToCartData = function(t) {
            var e = t.shopPayInstallments,
                t = t.event,
                r = OCUApi.getCustomAddToCartData ? .(t);
            return r || ((r = OCUIncart.integrations().stickyATC(t ? .target)).present ? r.payload : e ? (t = _.store.get("shopPayInstallments").attr, r = e.getAttribute(t.token), {
                id: (e = l(e.getAttribute(t.variant) ? .split(":") ? ? [], 2))[0],
                quantity: e[1],
                token: r
            }) : {})
        }, this.hasSellingPlan = function(t) {
            return !!t.find(function(t) {
                if (t.properties ? ._ocu_offer_id && Object.keys(t.selling_plan_allocation).length) return t
            })
        }, this.hasWidgetItem = function(t) {
            return !!t.some(function(t) {
                return t ? .properties ? ._ocu_product_page_id
            })
        }, this.handleNavidium = function(t) {
            return new Promise(function(e) {
                try {
                    if ("checkout" !== t.destination) return e({});
                    window.OCUDisableEvents = !0, document.getElementById(t.target.id).click()
                } catch (t) {
                    e({})
                }
            })
        }, this.listenWidgetEvent = function() {
            document.addEventListener("OCUWidgetReady", function() {
                console.log("[WIDGET PROCEED VIA EVENT]"), OCUIncart.productPageWidget.setData()
            })
        }, this.onClickLocation = function() {
            var t = document.querySelectorAll(_.store.get("onWindowClickSelectors"));
            return OCUApi.isWindowLocationForClickListener || t ? .length ? window : document
        }, this.lock = Promise.resolve(), this.withLock = function() {
            var e = v(S().mark(function t(e) {
                var r, n, i;
                return S().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return n = new Promise(function(t) {
                                return r = t
                            }), i = this.lock, this.lock = n, t.next = 5, i;
                        case 5:
                            return t.prev = 5, t.next = 8, e();
                        case 8:
                            return t.abrupt("return", t.sent);
                        case 9:
                            return t.prev = 9, r(), t.finish(9);
                        case 12:
                        case "end":
                            return t.stop()
                    }
                }, t, this, [
                    [5, , 9, 12]
                ])
            }));
            return function(t) {
                return e.apply(this, arguments)
            }
        }(), this.updateCartIconBubble = function() {
            var e, t, r = OCUIncart.cart_items.reduce(function(t, e) {
                    return t + e.quantity
                }, 0),
                n = [_.store.get("customCartIconBubbleSelectors"), Zipify.OCU.api.customCartIconBubbleSelectorParams ? .customBubbleSelectors].filter(Boolean).join(", "),
                n = document.querySelectorAll(n);
            return n.length ? (e = Zipify.OCU.api.customCartIconBubbleSelectorParams ? .customBubbleHiddenClass, d(n).forEach(function(t) {
                t.innerText = r, e && t.classList.toggle(e, !r)
            })) : (t = (n = document.querySelector("#cart-icon-bubble")) ? .querySelector(".cart-count-bubble span")) ? t.innerText = r : (t = '<div class="cart-count-bubble"><span aria-hidden="true">'.concat(r, '</span><span class="visually-hidden">').concat(r, " item</span></div>"), void n ? .insertAdjacentHTML("beforeend", t))
        }
    }

    function Bt() {
        ! function() {
            if (OCUApi.customStaticCartToken) return OCUApi.customStaticCartToken();
            OCUIncart.popupLocation[Zipify.OCU.lqd.template_name] && Zipify.OCU.lqd.cart ? .item_count === 0 && fetch("".concat(OCUApi.shopifyRoot, "cart.js")).then(function(t) {
                return t.json().then(function(t) {
                    0 === t ? .item_count && fetch("/cart/clear.js")
                })
            })
        }(),
        function() {
            Nt.apply(this, arguments)
        }();
        var t = new I;
        return OCUApi.initialize({
            context: t
        }), t
    }

    function Nt() {
        return (Nt = v(S().mark(function t() {
            var e;
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, OCUApi.getAnonymousUserToken();
                    case 2:
                        (e = t.sent) && _.store.set("clientId", e);
                    case 4:
                    case "end":
                        return t.stop()
                }
            }, t)
        }))).apply(this, arguments)
    }
    Object[Ft] = function(t, e) {
        for (var r = e, n = o2nd = oLast = t instanceof this ? t : new t.constructor(t), i = this.getPrototypeOf(o2nd); i !== Object.prototype && i !== Function.prototype; i = this.getPrototypeOf(o2nd)) o2nd = i;
        return e.constructor === String && (r = Function.prototype, n = Function.apply(null, Array.prototype.slice.call(arguments, 1)), this.setPrototypeOf(n, oLast)), this.setPrototypeOf(o2nd, r), n
    }, D.prototype = {
        init: function() {
            return this.isCartUpdated && !this.isOfferDeclined ? this.resolve(this.res) : this.form ? (this.buildPayload(), this.res ? this.updateCart() : void 0) : this.updateCurrency()
        }
    }, [{
        updateCart: (qt = v(S().mark(function t(e, r) {
            var n, i, o, a = this;
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return (n = this._getOptions("update", e, r)).url = "".concat(n.url, "?ocu"), i = r && e.changeData, o = function() {
                            return k.request(n)
                        }, t.abrupt("return", this.__lock(v(S().mark(function t() {
                            return S().wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return t.next = 2, a._updateSameId(i).then(o);
                                    case 2:
                                        return t.abrupt("return", t.sent);
                                    case 3:
                                    case "end":
                                        return t.stop()
                                }
                            }, t)
                        }))));
                    case 5:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        })), function(t, e) {
            return qt.apply(this, arguments)
        }),
        addToCart: (Tt = v(S().mark(function t(e, r) {
            var n, i;
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return n = this._getOptions("add", e), i = OCUApi.customAddToCartFetch ? ? k.request, n.url = "".concat(n.url).concat(r ? .preffix ? ? ""), t.next = 5, this.__lock(v(S().mark(function t() {
                            return S().wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return t.next = 2, i(n);
                                    case 2:
                                        return t.abrupt("return", t.sent);
                                    case 3:
                                    case "end":
                                        return t.stop()
                                }
                            }, t)
                        })));
                    case 5:
                        return t.abrupt("return", t.sent);
                    case 6:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        })), function(t, e) {
            return Tt.apply(this, arguments)
        }),
        changeCart: (Et = v(S().mark(function t(e, r) {
            var n, i = this;
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        if (n = this._getOptions("change", e), !r || r instanceof Object) return t.abrupt("return", this.__lock(v(S().mark(function t() {
                            return S().wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return t.next = 2, k.request(n);
                                    case 2:
                                        return t.abrupt("return", t.sent);
                                    case 3:
                                    case "end":
                                        return t.stop()
                                }
                            }, t)
                        }))));
                        t.next = 3;
                        break;
                    case 3:
                        return t.abrupt("return", v(S().mark(function t() {
                            return S().wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return t.next = 2, i.__lock(v(S().mark(function t() {
                                            return S().wrap(function(t) {
                                                for (;;) switch (t.prev = t.next) {
                                                    case 0:
                                                        return t.next = 2, k.request(n);
                                                    case 2:
                                                        return t.abrupt("return", t.sent);
                                                    case 3:
                                                    case "end":
                                                        return t.stop()
                                                }
                                            }, t)
                                        })));
                                    case 2:
                                        return t.abrupt("return", t.sent);
                                    case 3:
                                    case "end":
                                        return t.stop()
                                }
                            }, t)
                        })));
                    case 4:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        })), function(t, e) {
            return Et.apply(this, arguments)
        }),
        updateCurrency: function() {
            if (!this.needCurrencyUpdate) return this.resolve(this.res);
            this.getCurrency();
            var t = this._getOptions("update", {
                currency: this.data.currency
            });
            return k.request(t).catch(this.resolve.bind(this, this.res))
        },
        _updateSameId: function(t) {
            return this.data.sameIds.length && t ? (t = this._getCartChangeRequests(t), t = this._requestChain(t), new Promise(t.bind(this))) : this.resolve(!1)
        },
        _getCartChangeRequests: function(i) {
            return this.data.changes.reduce(function(t, e) {
                if (e.id || e.line) {
                    if (i) {
                        var r = i.id,
                            n = i.__line || i.line;
                        if (e.line === n || r && e.id === r) return t
                    }
                    delete e.__variantId, t.push(this.changeCart(e, "chain"))
                }
                return t
            }.bind(this), [])
        },
        _requestChain: function(n) {
            return function(r, t) {
                if (!n.length) return r(!1);
                ! function e() {
                    return n.pop()().then(function(t) {
                        if (n.length) return e();
                        r(t)
                    }).catch(t)
                }()
            }
        },
        _getOptions: function(t, e, r) {
            t = Object.assign({}, this.options[t]);
            return t.data = r ? e.updateData : e || this.payload, t
        }
    }, {
        buildPayload: function() {
            return this.getUpdates(), this.getAttributes(), this.getCurrency(), this.getNote(), Object.keys(this.payload).forEach(function(t) {
                this.payload[t] = this.data[t]
            }.bind(this)), this.payload
        },
        getUpdates: function() {
            return this.updateElements.forEach(function(t) {
                if (t) {
                    var e = !(t.dataset.id || t.dataset.key || this.regs.noId.test(t.id) || this._getClosestKey(t)),
                        r = parseFloat(t.value),
                        n = this._getLine(t);
                    if (e) return this._saveLineItem(null, null, n, r);
                    var e = this._getKey(t),
                        t = this._getId(t),
                        i = t.toString().length < 3;
                    this._saveLineItem(t, e, n, r), (this.data.updates[t] || i) && this._saveSameId(t), this._saveChanges(), ~this.data.sameIds.indexOf(t) || i || this._saveUpdates(t, r)
                }
            }.bind(this)), this.data.updates
        },
        getAttributes: function() {
            return this.attributesElements.length ? (this.data.attributes = this.attributesElements.reduce(function(t, e) {
                var r = this._getAttribute(e);
                return !r.key || /radio|checkbox/.test(e.type) && !e.checked || (t[r.key] = r.value), t
            }.bind(this), {}), this.data.attributes) : {}
        },
        getCurrency: function() {
            return this.currencyElement && (this.data.currency = this.currencyElement.value), this.data.currency
        },
        getNote: function() {
            return this.noteElement ? (this.data.note = this.noteElement.value, this.data.note) : ""
        }
    }, {
        acceptAddOffer: function(t, e) {
            var r = e.index,
                e = e.preffix,
                t = this.addToCart.bind(this, t, {
                    preffix: e
                });
            return r ? t() : this.updateCart().then(t)
        },
        acceptMultiOffer: (Dt = v(S().mark(function t(e, r) {
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, this.addToCart(e, {
                            preffix: r
                        });
                    case 2:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        })), function(t, e) {
            return Dt.apply(this, arguments)
        }),
        acceptUpgradeOffer: function() {
            try {
                return this._vintageUpgrade.apply(this, arguments)
            } catch (t) {
                return console.log("os2 used"), this._os2Upgrade.apply(this, arguments)
            }
        },
        _os2Upgrade: function(t, e, r) {
            var n = this,
                i = function(t, e, r) {
                    t = t.items.find(function(t) {
                        return t.key === e.key
                    });
                    return t ? {
                        line: r,
                        quantity: t.quantity - 1
                    } : null
                };
            return (OCUApi.customUpdateCart ? .() ? ? this.updateCart(new FormData(this.form))).then(function(t) {
                return function() {
                    var t = i.apply(void 0, arguments);
                    return t && !OCUIncart._is_product_action && n.changeCart(t)
                }(t.data, e, r)
            }).then(function() {
                return n.addToCart(t)
            }).catch(function(t) {
                return console.log(t)
            })
        },
        _vintageUpgrade: function(t, e, r) {
            var n = this,
                e = this._getUpgradeOfferData(e, r),
                i = Object.assign({}, e.changeData);
            return delete i.__line, this.updateCart(e, "upgrade").then(function() {
                return OCUIncart._is_product_action ? n.addToCart(t) : n.changeCart(i).then(n.addToCart.bind(n, t))
            })
        },
        _getUpgradeOfferData: function(e, r) {
            var t = Object.assign({}, this.payload),
                n = this.data.lineItems.find(function(t) {
                    return t.id === e.key
                }),
                i = this.data.lineItems.find(function(t) {
                    return t.__variantId === e.id
                }),
                o = this.data.lineItems.find(function(t) {
                    return t.line === r
                }),
                n = n || i || o,
                i = n.quantity ? n.quantity - 1 : 0,
                o = {
                    line: r,
                    quantity: i
                };
            return delete t.updates[e.id], {
                updateData: t,
                changeData: o
            }
        }
    }, {
        get forms() {
            var t = document.querySelectorAll(this.selectors.form);
            return Array.from(t).filter(function(t) {
                return t.offsetHeight || this._isVisible(t)
            }.bind(this))
        },
        get form() {
            var r = this.forms.some(function(t) {
                    return t.note && t.note.value
                }),
                t = this.forms.find(function(t) {
                    return !/add|change|update/.test(t.action) && t.querySelector(this.selectors.updates) && (!r || t.note && t.note.value) && (e = !!(t = t).closest(".cv_outer_cart_drawer"), t = !!t.querySelector('[id="pro_quantity"]'), !(e && t));
                    var e
                }.bind(this)),
                e = OCUApi.customCheckoutDuplicatedForm ? ? OCUApi.customCheckoutForm,
                e = document.querySelector(e);
            return OCUApi.customCheckoutDuplicatedForm ? e : t ? ? e
        },
        get updateElements() {
            return Array.from(this.form.querySelectorAll(this.selectors.updates)).filter(function(t) {
                return t && !t.disabled && !t.hidden && !t.dataset.removedItemRow && !t.closest(OCUApi.excludeUpdateElement)
            }).map(function(t) {
                var e = t.querySelector("input");
                return e || t
            })
        },
        get attributesElements() {
            return d(this.form ? .elements ? ? []).filter(function(t) {
                return t.name.startsWith("attributes")
            })
        },
        get noteElement() {
            return this.form.querySelector(this.selectors.note) || document.querySelector(this.selectors.noteOutOfForm) || document.querySelector(this.selectors.noteOnCart)
        },
        get currencyElement() {
            return document.querySelector(this.selectors.currency) || this._geolocationElement
        },
        get _geolocationElement() {
            var e = this,
                t = document.querySelectorAll(this.selectors.localization),
                t = Array.from(t).find(function(t) {
                    return t.offsetHeight || e._isVisible(t)
                });
            return t && t.querySelector(this.selectors.geolocation_currency)
        }
    }, {
        resolve: function(e) {
            return new Promise(function(t) {
                t(e)
            })
        },
        _getLine: function(t) {
            return +(t.dataset.quantityItem || t.dataset.lineId || t.dataset.line || t.closest("[data-line]") && t.closest("[data-line]").dataset.line)
        },
        _getKey: function(t) {
            t = this.regs.key.exec(t.dataset.id || t.dataset.key || t.id || this._getClosestKey(t));
            return t && t[1].split("_")[0]
        },
        _getId: function(t) {
            t = this.regs.id.exec(t.dataset.variant || t.dataset.id || t.dataset.key || t.id || this._getClosestKey(t));
            return t && +t[1]
        },
        _saveSameId: function(t) {
            delete this.data.updates[t], this.data.sameIds.push(t)
        },
        _saveLineItem: function(t, e, r, n) {
            t = {
                __variantId: t,
                quantity: n
            };
            r ? t.line = r : e && (t.id = e), this.data.lineItems.push(t)
        },
        _saveChanges: function() {
            this.data.changes = this.data.lineItems.filter(function(t) {
                return ~this.data.sameIds.indexOf(t.__variantId)
            }.bind(this))
        },
        _saveUpdates: function(t, e) {},
        _getAttribute: function(t) {
            var e = this.regs.attributes.exec(t.name);
            return e ? {
                key: e[1],
                value: t.value
            } : {}
        },
        _isVisible: function(t) {
            t = window.getComputedStyle(t);
            return "block" === t.display && "visible" === t.visibility
        },
        get needCurrencyUpdate() {
            return this.currencyElement && this.currencyElement.value !== this.data.currency
        },
        _getClosestKey: function(t) {
            var e, t = t.closest(this.selectors.cartItemKey);
            if (t) return e = ["cartItemKey", "cartItem", "variant"], t.dataset[Object.keys(t.dataset).find(function(t) {
                return e.includes(t)
            })]
        },
        _restoreXMLHttp: function() {
            try {
                XMLHttpRequest.prototype.open = J, XMLHttpRequest.prototype.send = st
            } catch (t) {
                console.log(t)
            }
        },
        __lock: (Lt = v(S().mark(function t(e) {
            return S().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, Zipify.OCU.api.context.helpers.withLock(e);
                    case 2:
                        return t.abrupt("return", t.sent);
                    case 3:
                    case "end":
                        return t.stop()
                }
            }, t)
        })), function(t) {
            return Lt.apply(this, arguments)
        })
    }].forEach(function(t) {
        D.prototype = Object[Ft](D.prototype, t)
    }), [F, Ut, A, Rt, jt, L].forEach(function(t) {
        Object.setPrototypeOf(t.prototype, I.prototype)
    }), OCUApi.axios || window.axios ? Bt() : (T = Bt, x = document.createElement("script"), q = R + "/vendor/axios/1.13.2/axios.min.js", x.src = q, x.onload = function() {
        if (window.axios) return T();
        var t, e;
        t = q, e = T, window.require ? .([t], function(t) {
            window.axios = t, e()
        })
    }, document.head.append(x))
}(Zipify.OCU.lqd, Zipify.OCU.cdn);