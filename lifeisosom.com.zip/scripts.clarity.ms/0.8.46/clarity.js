/* clarity-js v0.8.46: https://github.com/microsoft/clarity (License: MIT) */ ! function() {
    "use strict";
    var t = Object.freeze({
            __proto__: null,
            get add() {
                return Ba
            },
            get get() {
                return rr
            },
            get getId() {
                return Va
            },
            get getNode() {
                return nr
            },
            get getValue() {
                return ar
            },
            get has() {
                return or
            },
            get hashText() {
                return er
            },
            get iframe() {
                return Ga
            },
            get iframeContent() {
                return Za
            },
            get lookup() {
                return ir
            },
            get parse() {
                return Fa
            },
            get removeIFrame() {
                return Qa
            },
            get sameorigin() {
                return Ka
            },
            get start() {
                return Ha
            },
            get stop() {
                return qa
            },
            get update() {
                return Ja
            },
            get updates() {
                return ur
            }
        }),
        e = Object.freeze({
            __proto__: null,
            get queue() {
                return ei
            },
            get start() {
                return ti
            },
            get stop() {
                return ni
            },
            get track() {
                return Br
            }
        }),
        n = Object.freeze({
            __proto__: null,
            get data() {
                return Pi
            },
            get start() {
                return Ri
            },
            get stop() {
                return ji
            },
            get upgrade() {
                return Ai
            }
        }),
        a = Object.freeze({
            __proto__: null,
            get check() {
                return Li
            },
            get compute() {
                return Wi
            },
            get data() {
                return Di
            },
            get start() {
                return Xi
            },
            get stop() {
                return Hi
            },
            get trigger() {
                return zi
            }
        }),
        r = Object.freeze({
            __proto__: null,
            get compute() {
                return Ki
            },
            get data() {
                return qi
            },
            get log() {
                return Ji
            },
            get reset() {
                return Gi
            },
            get start() {
                return Vi
            },
            get stop() {
                return Bi
            },
            get updates() {
                return Ui
            }
        }),
        i = Object.freeze({
            __proto__: null,
            get compute() {
                return oo
            },
            get config() {
                return no
            },
            get consent() {
                return ao
            },
            get data() {
                return Zi
            },
            get start() {
                return $i
            },
            get stop() {
                return to
            },
            get trackConsentv2() {
                return io
            }
        }),
        o = Object.freeze({
            __proto__: null,
            get callback() {
                return ko
            },
            get callbacks() {
                return co
            },
            get clear() {
                return So
            },
            get consent() {
                return mo
            },
            get consentv2() {
                return yo
            },
            get data() {
                return uo
            },
            get electron() {
                return so
            },
            get id() {
                return go
            },
            get metadata() {
                return vo
            },
            get save() {
                return Oo
            },
            get shortid() {
                return To
            },
            get start() {
                return po
            },
            get stop() {
                return ho
            }
        }),
        u = Object.freeze({
            __proto__: null,
            get data() {
                return xo
            },
            get envelope() {
                return Do
            },
            get start() {
                return Io
            },
            get stop() {
                return Co
            }
        }),
        c = {
            projectId: null,
            delay: 1e3,
            lean: !1,
            lite: !1,
            track: !0,
            content: !0,
            drop: [],
            mask: [],
            unmask: [],
            regions: [],
            cookies: [],
            fraud: !0,
            checksum: [],
            report: null,
            upload: null,
            fallback: null,
            upgrade: null,
            action: null,
            dob: null,
            delayDom: !1,
            throttleDom: !0,
            conversions: !1,
            includeSubdomains: !0
        };

    function s(t) {
        return window.Zone && "__symbol__" in window.Zone ? window.Zone.__symbol__(t) : t
    }
    var l = 0;

    function d() {
        return performance.now() + performance.timeOrigin
    }

    function f(t) {
        void 0 === t && (t = null);
        var e = 0 === l ? d() : l,
            n = t && t.timeStamp > 0 ? t.timeStamp : performance.now(),
            a = t && t.view ? t.view.performance.timeOrigin : performance.timeOrigin;
        return Math.max(Math.round(n + a - e), 0)
    }
    var p = "0.8.46";

    function h(t, e) {
        void 0 === e && (e = null);
        for (var n, a = 5381, r = a, i = 0; i < t.length; i += 2) {
            if (a = (a << 5) + a ^ t.charCodeAt(i), i + 1 < t.length) r = (r << 5) + r ^ t.charCodeAt(i + 1)
        }
        return n = Math.abs(a + 11579 * r), (e ? n % Math.pow(2, e) : n).toString(36)
    }
    var v = /\S/gi,
        g = 255,
        m = !0,
        y = null,
        b = null,
        w = null;

    function S(t, e, n, a, r) {
        if (void 0 === a && (a = !1), t) {
            if ("input" == e && ("checkbox" === r || "radio" === r)) return t;
            switch (n) {
                case 0:
                    return t;
                case 1:
                    switch (e) {
                        case "*T":
                        case "value":
                        case "placeholder":
                        case "click":
                            return function(t) {
                                var e = -1,
                                    n = 0,
                                    a = !1,
                                    r = !1,
                                    i = !1,
                                    o = null;
                                N();
                                for (var u = 0; u < t.length; u++) {
                                    var c = t.charCodeAt(u);
                                    if (a = a || c >= 48 && c <= 57, r = r || 64 === c, i = 9 === c || 10 === c || 13 === c || 32 === c, 0 === u || u === t.length - 1 || i) {
                                        if (a || r) {
                                            null === o && (o = t.split(""));
                                            var s = t.substring(e + 1, i ? u : u + 1);
                                            s = m && null !== w ? s.match(w) ? s : T(s, "▪", "▫") : E(s), o.splice(e + 1 - n, s.length, s), n += s.length - 1
                                        }
                                        i && (a = !1, r = !1, e = u)
                                    }
                                }
                                return o ? o.join("") : t
                            }(t);
                        case "input":
                        case "change":
                            return _(t)
                    }
                    return t;
                case 2:
                case 3:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? O(t) : E(t);
                        case "src":
                        case "srcset":
                        case "title":
                        case "alt":
                        case "href":
                        case "xlink:href":
                            return 3 === n ? "src" === e && (null == t ? void 0 : t.startsWith("blob:")) ? "blob:" : "" : t;
                        case "value":
                        case "click":
                        case "input":
                        case "change":
                            return _(t);
                        case "placeholder":
                            return E(t)
                    }
                    break;
                case 4:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? O(t) : E(t);
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                            return ""
                    }
                    break;
                case 5:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return T(t, "▪", "▫");
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                        case "src":
                        case "srcset":
                        case "alt":
                        case "title":
                            return ""
                    }
            }
        }
        return t
    }

    function k(t, e, n) {
        void 0 === e && (e = !1), void 0 === n && (n = !1);
        var a = t;
        if (e) a = "".concat("https://").concat("Electron");
        else {
            var r = c.drop;
            if (r && r.length > 0 && t && t.indexOf("?") > 0) {
                var i = t.split("?"),
                    o = i[0],
                    u = i[1];
                a = o + "?" + u.split("&").map((function(t) {
                    return r.some((function(e) {
                        return 0 === t.indexOf("".concat(e, "="))
                    })) ? "".concat(t.split("=")[0], "=").concat("*na*") : t
                })).join("&")
            }
        }
        return n && (a = a.substring(0, g)), a
    }

    function O(t) {
        var e = t.trim();
        if (e.length > 0) {
            var n = e[0],
                a = t.indexOf(n),
                r = t.substr(0, a),
                i = t.substr(a + e.length);
            return "".concat(r).concat(e.length.toString(36)).concat(i)
        }
        return t
    }

    function E(t) {
        return t.replace(v, "•")
    }

    function T(t, e, n) {
        return N(), t ? t.replace(b, e).replace(y, n) : t
    }

    function _(t) {
        for (var e = 5 * (Math.floor(t.length / 5) + 1), n = "", a = 0; a < e; a++) n += a > 0 && a % 5 == 0 ? " " : "•";
        return n
    }

    function N() {
        if (m && null === y) try {
            y = new RegExp("\\p{N}", "gu"), b = new RegExp("\\p{L}", "gu"), w = new RegExp("\\p{Sc}", "gu")
        } catch (t) {
            m = !1
        }
    }
    var M = null,
        x = null,
        I = !1;

    function C() {
        I && (M = {
            time: f(),
            event: 4,
            data: {
                visible: x.visible,
                docWidth: x.docWidth,
                docHeight: x.docHeight,
                screenWidth: x.screenWidth,
                screenHeight: x.screenHeight,
                scrollX: x.scrollX,
                scrollY: x.scrollY,
                pointerX: x.pointerX,
                pointerY: x.pointerY,
                activityTime: x.activityTime,
                scrollTime: x.scrollTime,
                pointerTime: x.pointerTime,
                moveX: x.moveX,
                moveY: x.moveY,
                moveTime: x.moveTime,
                downX: x.downX,
                downY: x.downY,
                downTime: x.downTime,
                upX: x.upX,
                upY: x.upY,
                upTime: x.upTime,
                pointerPrevX: x.pointerPrevX,
                pointerPrevY: x.pointerPrevY,
                pointerPrevTime: x.pointerPrevTime,
                modules: x.modules
            }
        }), x = x || {
            visible: 1,
            docWidth: 0,
            docHeight: 0,
            screenWidth: 0,
            screenHeight: 0,
            scrollX: 0,
            scrollY: 0,
            pointerX: 0,
            pointerY: 0,
            activityTime: 0,
            scrollTime: 0,
            pointerTime: void 0,
            moveX: void 0,
            moveY: void 0,
            moveTime: void 0,
            downX: void 0,
            downY: void 0,
            downTime: void 0,
            upX: void 0,
            upY: void 0,
            upTime: void 0,
            pointerPrevX: void 0,
            pointerPrevY: void 0,
            pointerPrevTime: void 0,
            modules: null
        }
    }

    function D(t, e, n, a) {
        switch (t) {
            case 8:
                x.docWidth = e, x.docHeight = n;
                break;
            case 11:
                x.screenWidth = e, x.screenHeight = n;
                break;
            case 10:
                x.scrollX = e, x.scrollY = n, x.scrollTime = a;
                break;
            case 12:
                x.moveX = e, x.moveY = n, x.moveTime = a, x.pointerPrevX = x.pointerX, x.pointerPrevY = x.pointerY, x.pointerPrevTime = x.pointerTime, x.pointerX = e, x.pointerY = n, x.pointerTime = a;
                break;
            case 13:
                x.downX = e, x.downY = n, x.downTime = a, x.pointerPrevX = x.pointerX, x.pointerPrevY = x.pointerY, x.pointerPrevTime = x.pointerTime, x.pointerX = e, x.pointerY = n, x.pointerTime = a;
                break;
            case 14:
                x.upX = e, x.upY = n, x.upTime = a, x.pointerPrevX = x.pointerX, x.pointerPrevY = x.pointerY, x.pointerPrevTime = x.pointerTime, x.pointerX = e, x.pointerY = n, x.pointerTime = a;
                break;
            default:
                x.pointerPrevX = x.pointerX, x.pointerPrevY = x.pointerY, x.pointerPrevTime = x.pointerTime, x.pointerX = e, x.pointerY = n, x.pointerTime = a
        }
        I = !0
    }

    function P(t) {
        x.activityTime = t
    }

    function R(t, e) {
        x.visible = e, x.visible || P(t), I = !0
    }

    function A(t) {
        x.modules = Array.from(t), I = !0
    }

    function j() {
        I && Yi(4)
    }
    var Y = Object.freeze({
            __proto__: null,
            activity: P,
            compute: j,
            dynamic: A,
            reset: C,
            start: function() {
                I = !1, C()
            },
            get state() {
                return M
            },
            stop: function() {
                C()
            },
            track: D,
            visibility: R
        }),
        X = null;

    function L(t, e) {
        $o() && t && "string" == typeof t && t.length < 255 && (X = e && "string" == typeof e && e.length < 255 ? {
            key: t,
            value: e
        } : {
            value: t
        }, Yi(24))
    }
    var z, W = null,
        H = null;

    function q(t) {
        t in W || (W[t] = 0), t in H || (H[t] = 0), W[t]++, H[t]++
    }

    function U(t, e) {
        null !== e && (t in W || (W[t] = 0), t in H || (H[t] = 0), W[t] += e, H[t] += e)
    }

    function F(t, e) {
        null !== e && !1 === isNaN(e) && (t in W || (W[t] = 0), (e > W[t] || 0 === W[t]) && (H[t] = e, W[t] = e))
    }

    function V(t, e, n) {
        return window.setTimeout(Ao(t), e, n)
    }

    function B(t) {
        return window.clearTimeout(t)
    }
    var J = 0,
        K = 0,
        G = null;

    function Z() {
        G && B(G), G = V(Q, K), J = f()
    }

    function Q() {
        var t = f();
        z = {
            gap: t - J
        }, Yi(25), z.gap < 3e5 ? G = V(Q, K) : Go && (L("clarity", "suspend"), Eu(), ["mousemove", "touchstart"].forEach((function(t) {
            return Yo(document, t, tu)
        })), ["resize", "scroll", "pageshow"].forEach((function(t) {
            return Yo(window, t, tu)
        })))
    }
    var $ = Object.freeze({
            __proto__: null,
            get data() {
                return z
            },
            reset: Z,
            start: function() {
                K = 6e4, J = 0
            },
            stop: function() {
                B(G), J = 0, K = 0
            }
        }),
        tt = null;

    function et(t, e) {
        if (t in tt) {
            var n = tt[t],
                a = n[n.length - 1];
            e - a[0] > 100 ? tt[t].push([e, 0]) : a[1] = e - a[0]
        } else tt[t] = [
            [e, 0]
        ]
    }

    function nt() {
        Yi(36)
    }

    function at() {
        tt = {}
    }
    var rt = Object.freeze({
        __proto__: null,
        compute: nt,
        get data() {
            return tt
        },
        reset: at,
        start: function() {
            tt = {}
        },
        stop: function() {
            tt = {}
        },
        track: et
    });

    function it(t, e, n, a) {
        return new(n || (n = Promise))((function(r, i) {
            function o(t) {
                try {
                    c(a.next(t))
                } catch (t) {
                    i(t)
                }
            }

            function u(t) {
                try {
                    c(a.throw(t))
                } catch (t) {
                    i(t)
                }
            }

            function c(t) {
                var e;
                t.done ? r(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                    t(e)
                }))).then(o, u)
            }
            c((a = a.apply(t, e || [])).next())
        }))
    }

    function ot(t, e) {
        var n, a, r, i, o = {
            label: 0,
            sent: function() {
                if (1 & r[0]) throw r[1];
                return r[1]
            },
            trys: [],
            ops: []
        };
        return i = {
            next: u(0),
            throw: u(1),
            return: u(2)
        }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
            return this
        }), i;

        function u(u) {
            return function(c) {
                return function(u) {
                    if (n) throw new TypeError("Generator is already executing.");
                    for (; i && (i = 0, u[0] && (o = 0)), o;) try {
                        if (n = 1, a && (r = 2 & u[0] ? a.return : u[0] ? a.throw || ((r = a.return) && r.call(a), 0) : a.next) && !(r = r.call(a, u[1])).done) return r;
                        switch (a = 0, r && (u = [2 & u[0], r.value]), u[0]) {
                            case 0:
                            case 1:
                                r = u;
                                break;
                            case 4:
                                return o.label++, {
                                    value: u[1],
                                    done: !1
                                };
                            case 5:
                                o.label++, a = u[1], u = [0];
                                continue;
                            case 7:
                                u = o.ops.pop(), o.trys.pop();
                                continue;
                            default:
                                if (!(r = o.trys, (r = r.length > 0 && r[r.length - 1]) || 6 !== u[0] && 2 !== u[0])) {
                                    o = 0;
                                    continue
                                }
                                if (3 === u[0] && (!r || u[1] > r[0] && u[1] < r[3])) {
                                    o.label = u[1];
                                    break
                                }
                                if (6 === u[0] && o.label < r[1]) {
                                    o.label = r[1], r = u;
                                    break
                                }
                                if (r && o.label < r[2]) {
                                    o.label = r[2], o.ops.push(u);
                                    break
                                }
                                r[2] && o.ops.pop(), o.trys.pop();
                                continue
                        }
                        u = e.call(t, o)
                    } catch (t) {
                        u = [6, t], a = 0
                    } finally {
                        n = r = 0
                    }
                    if (5 & u[0]) throw u[1];
                    return {
                        value: u[0] ? u[1] : void 0,
                        done: !0
                    }
                }([u, c])
            }
        }
    }
    var ut = "CompressionStream" in window;

    function ct(t) {
        return it(this, void 0, void 0, (function() {
            var e, n;
            return ot(this, (function(a) {
                switch (a.label) {
                    case 0:
                        return a.trys.push([0, 3, , 4]), ut ? (e = new ReadableStream({
                            start: function(e) {
                                return it(this, void 0, void 0, (function() {
                                    return ot(this, (function(n) {
                                        return e.enqueue(t), e.close(), [2]
                                    }))
                                }))
                            }
                        }).pipeThrough(new TextEncoderStream).pipeThrough(new window.CompressionStream("gzip")), n = Uint8Array.bind, [4, st(e)]) : [3, 2];
                    case 1:
                        return [2, new(n.apply(Uint8Array, [void 0, a.sent()]))];
                    case 2:
                        return [3, 4];
                    case 3:
                        return a.sent(), [3, 4];
                    case 4:
                        return [2, null]
                }
            }))
        }))
    }

    function st(t) {
        return it(this, void 0, void 0, (function() {
            var e, n, a, r, i;
            return ot(this, (function(o) {
                switch (o.label) {
                    case 0:
                        e = t.getReader(), n = [], a = !1, r = [], o.label = 1;
                    case 1:
                        return a ? [3, 3] : [4, e.read()];
                    case 2:
                        return i = o.sent(), a = i.done, r = i.value, a ? [2, n] : (n.push.apply(n, r), [3, 1]);
                    case 3:
                        return [2, n]
                }
            }))
        }))
    }
    var lt = null;

    function dt(t, e) {
        pt(t, "string" == typeof e ? [e] : e)
    }

    function ft(t, e, n, a) {
        return void 0 === e && (e = null), void 0 === n && (n = null), void 0 === a && (a = null), it(this, void 0, void 0, (function() {
            var r, i;
            return ot(this, (function(o) {
                switch (o.label) {
                    case 0:
                        return i = {}, [4, gt(t)];
                    case 1:
                        return i.userId = o.sent(), i.userHint = a || ((u = t) && u.length >= 5 ? "".concat(u.substring(0, 2)).concat(T(u.substring(2), "*", "*")) : T(u, "*", "*")), pt("userId", [(r = i).userId]), pt("userHint", [r.userHint]), pt("userType", [mt(t)]), e && (pt("sessionId", [e]), r.sessionId = e), n && (pt("pageId", [n]), r.pageId = n), [2, r]
                }
                var u
            }))
        }))
    }

    function pt(t, e) {
        if ($o() && t && e && "string" == typeof t && t.length < 255) {
            for (var n = (t in lt ? lt[t] : []), a = 0; a < e.length; a++) "string" == typeof e[a] && e[a].length < 255 && n.push(e[a]);
            lt[t] = n
        }
    }

    function ht() {
        Yi(34)
    }

    function vt() {
        lt = {}
    }

    function gt(t) {
        return it(this, void 0, void 0, (function() {
            var e;
            return ot(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return n.trys.push([0, 4, , 5]), crypto && t ? [4, crypto.subtle.digest("SHA-256", (new TextEncoder).encode(t))] : [3, 2];
                    case 1:
                        return e = n.sent(), [2, Array.prototype.map.call(new Uint8Array(e), (function(t) {
                            return ("00" + t.toString(16)).slice(-2)
                        })).join("")];
                    case 2:
                        return [2, ""];
                    case 3:
                        return [3, 5];
                    case 4:
                        return n.sent(), [2, ""];
                    case 5:
                        return [2]
                }
            }))
        }))
    }

    function mt(t) {
        return t && t.indexOf("@") > 0 ? "email" : "string"
    }
    var yt = Object.freeze({
            __proto__: null,
            compute: ht,
            get data() {
                return lt
            },
            identify: ft,
            reset: vt,
            set: dt,
            start: function() {
                vt()
            },
            stop: function() {
                vt()
            }
        }),
        bt = {},
        wt = new Set,
        St = {},
        kt = {},
        Ot = {},
        Et = {};

    function Tt(t) {
        try {
            var e = t && t.length > 0 ? t.split(/ (.*)/) : [""],
                n = e[0].split(/\|(.*)/),
                a = parseInt(n[0]),
                r = n.length > 1 ? n[1] : "",
                i = e.length > 1 ? JSON.parse(e[1]) : {};
            for (var o in St[a] = {}, kt[a] = {}, Ot[a] = {}, Et[a] = r, i) {
                var u = parseInt(o),
                    c = i[o],
                    s = 2;
                switch (c.startsWith("~") ? s = 0 : c.startsWith("!") && (s = 4), s) {
                    case 0:
                        var l = c.slice(1);
                        St[a][u] = It(l);
                        break;
                    case 2:
                        kt[a][u] = c;
                        break;
                    case 4:
                        var d = c.slice(1);
                        Ot[a][u] = d
                }
            }
        } catch (t) {
            pi(8, 1, t ? t.name : null)
        }
    }

    function _t(t) {
        return JSON.parse(JSON.stringify(t))
    }

    function Nt() {
        try {
            for (var t in St) {
                var e = parseInt(t);
                if ("" == Et[e] || document.querySelector(Et[e])) {
                    var n = St[e];
                    for (var a in n) {
                        var r = parseInt(a),
                            i = (m = Ct(_t(n[r]))) ? JSON.stringify(m).slice(0, 1e4) : m;
                        i && xt(e, r, i)
                    }
                    var o = kt[e];
                    for (var u in o) {
                        var c = !1,
                            s = parseInt(u),
                            l = o[s];
                        l.startsWith("@") && (c = !0, l = l.slice(1));
                        var d = document.querySelectorAll(l);
                        if (d) {
                            var f = Array.from(d).map((function(t) {
                                return t.textContent
                            })).join("<SEP>");
                            xt(e, s, (c ? h(f).trim() : f).slice(0, 1e4))
                        }
                    }
                    var p = Ot[e];
                    for (var v in p) {
                        var g = parseInt(v);
                        xt(e, g, er(p[g]).trim().slice(0, 1e4))
                    }
                }
            }
            wt.size > 0 && Yi(40)
        } catch (t) {
            pi(5, 1, t ? t.name : null)
        }
        var m
    }

    function Mt() {
        wt.clear()
    }

    function xt(t, e, n) {
        var a, r = !1;
        t in bt || (bt[t] = {}, r = !0), a = Ot[t], 0 == Object.keys(a).length || e in bt[t] && bt[t][e] == n || (r = !0), bt[t][e] = n, r && wt.add(t)
    }

    function It(t) {
        for (var e = [], n = t.split("."); n.length > 0;) {
            var a = n.shift(),
                r = a.indexOf("["),
                i = a.indexOf("{"),
                o = a.indexOf("}");
            e.push({
                name: r > 0 ? a.slice(0, r) : i > 0 ? a.slice(0, i) : a,
                type: r > 0 ? 1 : i > 0 ? 2 : 3,
                condition: i > 0 ? a.slice(i + 1, o) : null
            })
        }
        return e
    }

    function Ct(t, e) {
        if (void 0 === e && (e = window), 0 == t.length) return e;
        var n, a = t.shift();
        if (e && e[a.name]) {
            var r = e[a.name];
            if (1 !== a.type && Dt(r, a.condition)) n = Ct(t, r);
            else if (Array.isArray(r)) {
                for (var i = [], o = 0, u = r; o < u.length; o++) {
                    var c = u[o];
                    if (Dt(c, a.condition)) {
                        var s = Ct(t, c);
                        s && i.push(s)
                    }
                }
                n = i
            }
            return n
        }
        return null
    }

    function Dt(t, e) {
        if (e) {
            var n = e.split(":");
            return n.length > 1 ? t[n[0]] == n[1] : t[n[0]]
        }
        return !0
    }
    var Pt = Object.freeze({
        __proto__: null,
        clone: _t,
        compute: Nt,
        data: bt,
        keys: wt,
        reset: Mt,
        start: function() {
            Mt()
        },
        stop: function() {
            Mt()
        },
        trigger: Tt,
        update: xt
    });

    function Rt(t, e) {
        try {
            return !!t[e]
        } catch (t) {
            return !1
        }
    }

    function At(t) {
        try {
            var e = decodeURIComponent(t);
            return [e != t, e]
        } catch (t) {}
        return [!1, t]
    }
    var jt = null,
        Yt = "^";

    function Xt(t, e) {
        var n;
        if (void 0 === e && (e = !1), Rt(document, "cookie")) {
            var a = document.cookie.split(";");
            if (a)
                for (var r = 0; r < a.length; r++) {
                    var i = a[r].split("=");
                    if (i.length > 1 && i[0] && i[0].trim() === t) {
                        for (var o = At(i[1]), u = o[0], c = o[1]; u;) u = (n = At(c))[0], c = n[1];
                        return e ? c.endsWith("".concat("~", "1")) ? c.substring(0, c.length - 2) : null : c
                    }
                }
        }
        return null
    }

    function Lt(t, e, n) {
        if ((c.track || "" == e) && (navigator && navigator.cookieEnabled || Rt(document, "cookie"))) {
            var a = function(t) {
                    return encodeURIComponent(t)
                }(e),
                r = new Date;
            r.setDate(r.getDate() + n);
            var i = r ? "expires=" + r.toUTCString() : "",
                o = "".concat(t, "=").concat(a).concat(";").concat(i).concat(";path=/");
            try {
                if (null === jt) {
                    for (var u = location.hostname ? location.hostname.split(".") : [], s = u.length - 1; s >= 0; s--)
                        if (jt = ".".concat(u[s]).concat(jt || ""), s < u.length - 1 && (document.cookie = "".concat(o).concat(";").concat("domain=").concat(jt), Xt(t) === e)) return;
                    jt = ""
                }
            } catch (t) {
                jt = ""
            }
            document.cookie = jt ? "".concat(o).concat(";").concat("domain=").concat(jt) : o
        }
    }
    var zt = null;

    function Wt(t) {
        try {
            if (!zt) return;
            var e = function(t) {
                try {
                    return JSON.parse(t)
                } catch (t) {
                    return []
                }
            }(t);
            e.forEach((function(t) {
                zt(t)
            }))
        } catch (t) {}
    }
    var Ht = [Y, r, yt, a, rt, Object.freeze({
        __proto__: null,
        COOKIE_SEP: Yt,
        getCookie: Xt,
        setCookie: Lt,
        start: function() {
            jt = null
        },
        stop: function() {
            jt = null
        }
    }), i, o, u, e, $, n, Pt];

    function qt() {
        W = {}, H = {}, q(5), Ht.forEach((function(t) {
            return Ao(t.start)()
        }))
    }

    function Ut() {
        Ht.slice().reverse().forEach((function(t) {
            return Ao(t.stop)()
        })), W = {}, H = {}
    }

    function Ft() {
        ht(), j(), Ki(), Yi(0), nt(), Wi(), Nt(), oo()
    }
    var Vt, Bt = [];

    function Jt(t, e, n) {
        c.fraud && null !== t && n && n.length >= 5 && (Vt = {
            id: t,
            target: e,
            checksum: h(n, 28)
        }, Bt.indexOf(Vt.checksum) < 0 && (Bt.push(Vt.checksum), li(41)))
    }
    var Kt = [];

    function Gt(t) {
        var e = Er(t);
        if (e) {
            var n = e.value,
                a = n && n.length >= 5 && c.fraud && -1 === "password,secret,pass,social,ssn,code,hidden".indexOf(e.type) ? h(n, 28) : "";
            Kt.push({
                time: f(t),
                event: 42,
                data: {
                    target: Er(t),
                    type: e.type,
                    value: n,
                    checksum: a
                }
            }), Si(_r.bind(this, 42))
        }
    }

    function Zt() {
        Kt = []
    }

    function Qt(t) {
        var e = {
            x: 0,
            y: 0
        };
        if (t && t.offsetParent)
            do {
                var n = t.offsetParent,
                    a = null === n ? Ga(t.ownerDocument) : null;
                e.x += t.offsetLeft, e.y += t.offsetTop, t = a || n
            } while (t);
        return e
    }
    var $t = ["input", "textarea", "radio", "button", "canvas", "select"],
        te = [];

    function ee(t, e, n) {
        var a = Ga(e),
            r = a && a.contentDocument ? a.contentDocument.documentElement : document.documentElement,
            i = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + r.scrollLeft) : null,
            o = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + r.scrollTop) : null;
        if (a) {
            var u = Qt(a);
            i = i ? i + Math.round(u.x) : i, o = o ? o + Math.round(u.y) : o
        }
        var c = Er(n),
            s = function(t) {
                for (; t && t !== document;) {
                    if (t.nodeType === Node.ELEMENT_NODE) {
                        var e = t;
                        if ("A" === e.tagName) return e
                    }
                    t = t.parentNode
                }
                return null
            }(c),
            l = function(t) {
                var e = null,
                    n = document.documentElement;
                if ("function" == typeof t.getBoundingClientRect) {
                    var a = t.getBoundingClientRect();
                    a && a.width > 0 && a.height > 0 && (e = {
                        x: Math.floor(a.left + ("pageXOffset" in window ? window.pageXOffset : n.scrollLeft)),
                        y: Math.floor(a.top + ("pageYOffset" in window ? window.pageYOffset : n.scrollTop)),
                        w: Math.floor(a.width),
                        h: Math.floor(a.height)
                    })
                }
                return e
            }(c);
        0 === n.detail && l && (i = Math.round(l.x + l.w / 2), o = Math.round(l.y + l.h / 2));
        var d = l ? Math.max(Math.floor((i - l.x) / l.w * 32767), 0) : 0,
            p = l ? Math.max(Math.floor((o - l.y) / l.h * 32767), 0) : 0;
        if (null !== i && null !== o) {
            var h = function(t) {
                var e = null,
                    n = !1;
                if (t) {
                    var a = t.textContent || String(t.value || "") || t.alt;
                    if (a) {
                        var r = a.replace(/\s+/g, " ").trim();
                        n = (e = r.substring(0, 25)).length === r.length
                    }
                }
                return {
                    text: e,
                    isFullText: n ? 1 : 0
                }
            }(c);
            te.push({
                time: f(n),
                event: t,
                data: {
                    target: c,
                    x: i,
                    y: o,
                    eX: d,
                    eY: p,
                    button: n.button,
                    reaction: ne(c),
                    context: re(s),
                    text: h.text,
                    link: s ? s.href : null,
                    hash: null,
                    trust: n.isTrusted ? 1 : 0,
                    isFullText: h.isFullText,
                    w: l ? l.w : 0,
                    h: l ? l.h : 0,
                    tag: ae(c, "tagName").substring(0, 10),
                    class: ae(c, "className").substring(0, 50),
                    id: ae(c, "id").substring(0, 25)
                }
            }), Si(_r.bind(this, t))
        }
    }

    function ne(t) {
        var e = ae(t, "tagName");
        return $t.indexOf(e) >= 0 ? 0 : 1
    }

    function ae(t, e) {
        if (t.nodeType === Node.ELEMENT_NODE) {
            var n = null == t ? void 0 : t[e];
            return "string" == typeof n ? null == n ? void 0 : n.toLowerCase() : ""
        }
        return ""
    }

    function re(t) {
        if (t && t.hasAttribute("target")) switch (t.getAttribute("target")) {
            case "_blank":
                return 1;
            case "_parent":
                return 2;
            case "_top":
                return 3
        }
        return 0
    }

    function ie() {
        te = []
    }
    var oe = [];

    function ue(t, e) {
        oe.push({
            time: f(e),
            event: 38,
            data: {
                target: Er(e),
                action: t
            }
        }), Si(_r.bind(this, 38))
    }

    function ce() {
        oe = []
    }
    var se = null,
        le = [];

    function de(t) {
        var e = Er(t),
            n = rr(e);
        if (e && e.type && n) {
            var a = e.value,
                r = e.type;
            switch (e.type) {
                case "radio":
                case "checkbox":
                    a = e.checked ? "true" : "false"
            }
            var i = {
                target: e,
                value: a,
                type: r,
                trust: t.isTrusted ? 1 : 0
            };
            le.length > 0 && le[le.length - 1].data.target === i.target && le.pop(), le.push({
                time: f(t),
                event: 27,
                data: i
            }), B(se), se = V(fe, 1e3, 27)
        }
    }

    function fe(t) {
        Si(_r.bind(this, t))
    }

    function pe() {
        le = []
    }
    var he, ve = [],
        ge = null,
        me = !1,
        ye = 0,
        be = new Set;

    function we(t, e, n) {
        var a = Ga(e),
            r = a && a.contentDocument ? a.contentDocument.documentElement : document.documentElement,
            i = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + r.scrollLeft) : null,
            o = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + r.scrollTop) : null;
        if (a) {
            var u = Qt(a);
            i = i ? i + Math.round(u.x) : i, o = o ? o + Math.round(u.y) : o
        }
        null !== i && null !== o && ke({
            time: f(n),
            event: t,
            data: {
                target: Er(n),
                x: i,
                y: o
            }
        })
    }

    function Se(t, e, n) {
        var a = Ga(e),
            r = a && a.contentDocument ? a.contentDocument.documentElement : document.documentElement,
            i = n.changedTouches,
            o = f(n);
        if (i)
            for (var u = 0; u < i.length; u++) {
                var c = i[u],
                    s = "clientX" in c ? Math.round(c.clientX + r.scrollLeft) : null,
                    l = "clientY" in c ? Math.round(c.clientY + r.scrollTop) : null;
                s = s && a ? s + Math.round(a.offsetLeft) : s, l = l && a ? l + Math.round(a.offsetTop) : l;
                var d = "identifier" in c ? c.identifier : void 0;
                switch (t) {
                    case 17:
                        0 === be.size && (me = !0, ye = d), be.add(d);
                        break;
                    case 18:
                    case 20:
                        be.delete(d)
                }
                var p = me && ye === d;
                null !== s && null !== l && ke({
                    time: o,
                    event: t,
                    data: {
                        target: Er(n),
                        x: s,
                        y: l,
                        id: d,
                        isPrimary: p
                    }
                }), 20 !== t && 18 !== t || ye === d && (me = !1)
            }
    }

    function ke(t) {
        switch (t.event) {
            case 12:
            case 15:
            case 19:
                var e = ve.length,
                    n = e > 1 ? ve[e - 2] : null;
                n && function(t, e) {
                    var n = t.data.x - e.data.x,
                        a = t.data.y - e.data.y,
                        r = Math.sqrt(n * n + a * a),
                        i = e.time - t.time,
                        o = e.data.target === t.data.target,
                        u = void 0 === e.data.id || e.data.id === t.data.id;
                    return e.event === t.event && o && r < 20 && i < 25 && u
                }(n, t) && ve.pop(), ve.push(t), B(ge), ge = V(Oe, 500, t.event);
                break;
            default:
                ve.push(t), Oe(t.event)
        }
    }

    function Oe(t) {
        Si(_r.bind(this, t))
    }

    function Ee() {
        ve = []
    }

    function Te(t, e) {
        var n = 0,
            a = null,
            r = null;

        function i() {
            for (var i = this, o = [], u = 0; u < arguments.length; u++) o[u] = arguments[u];
            var c = performance.now(),
                s = c - n;
            if (0 !== n && s < e) {
                if (r = o, a) return;
                a = setTimeout((function() {
                    n = performance.now(), t.apply(i, r), r = null, a = null
                }), e - s)
            } else n = c, t.apply(this, o)
        }
        return i.cleanup = function() {
            a && (clearTimeout(a), a = null, r = null)
        }, i
    }
    var _e = null,
        Ne = !1,
        Me = Te(xe, 500);

    function xe() {
        var t = document.documentElement;
        he = {
            width: t && "clientWidth" in t ? Math.min(t.clientWidth, window.innerWidth) : window.innerWidth,
            height: t && "clientHeight" in t ? Math.min(t.clientHeight, window.innerHeight) : window.innerHeight
        }, Ne ? (B(_e), _e = V(Ie, 500, 11)) : (_r(11), Ne = !0)
    }

    function Ie(t) {
        Si(_r.bind(this, t))
    }

    function Ce() {
        he = null, B(_e), Me.cleanup()
    }
    var De = [],
        Pe = null,
        Re = null,
        Ae = null;

    function je(t) {
        void 0 === t && (t = null);
        var e = window,
            n = document.documentElement,
            a = t ? Er(t) : n;
        if (a) {
            if (a && a.nodeType === Node.DOCUMENT_NODE) {
                var r = Ga(a);
                e = r ? r.contentWindow : e, a = n = a.documentElement
            }
            var i = a === n && "pageXOffset" in e ? Math.round(e.pageXOffset) : Math.round(a.scrollLeft),
                o = a === n && "pageYOffset" in e ? Math.round(e.pageYOffset) : Math.round(a.scrollTop),
                u = window.innerWidth,
                c = window.innerHeight,
                s = u / 3,
                l = u > c ? .15 * c : .2 * c,
                d = c - l,
                p = Xe(s, l),
                h = Xe(s, d),
                v = {
                    time: f(t),
                    event: 10,
                    data: {
                        target: a,
                        x: i,
                        y: o,
                        top: p,
                        bottom: h
                    }
                };
            if (null === t && 0 === i && 0 === o || null === i || null === o) return Pe = p, void(Re = h);
            var g = De.length,
                m = g > 1 ? De[g - 2] : null;
            m && function(t, e) {
                var n = t.data.x - e.data.x,
                    a = t.data.y - e.data.y;
                return n * n + a * a < 400 && e.time - t.time < 50
            }(m, v) && De.pop(), De.push(v), B(Ae), Ae = V(Le, 500, 10)
        }
    }
    var Ye = Te(je, 25);

    function Xe(t, e) {
        var n, a, r;
        return "caretPositionFromPoint" in document ? r = null === (n = document.caretPositionFromPoint(t, e)) || void 0 === n ? void 0 : n.offsetNode : "caretRangeFromPoint" in document && (r = null === (a = document.caretRangeFromPoint(t, e)) || void 0 === a ? void 0 : a.startContainer), r || (r = document.elementFromPoint(t, e)), r && r.nodeType === Node.TEXT_NODE && (r = r.parentNode), r
    }

    function Le(t) {
        Si(_r.bind(this, t))
    }

    function ze() {
        var t, e;
        if (Pe) {
            var n = Tr(Pe, null);
            Ji(31, null === (t = null == n ? void 0 : n.hash) || void 0 === t ? void 0 : t.join("."))
        }
        if (Re) {
            var a = Tr(Re, null);
            Ji(32, null === (e = null == a ? void 0 : a.hash) || void 0 === e ? void 0 : e.join("."))
        }
    }
    var We = null,
        He = null,
        qe = null;

    function Ue(t) {
        var e = (t.nodeType === Node.DOCUMENT_NODE ? t : document).getSelection();
        if (null !== e && !(null === e.anchorNode && null === e.focusNode || e.anchorNode === e.focusNode && e.anchorOffset === e.focusOffset)) {
            var n = We.start ? We.start : null;
            null !== He && null !== We.start && n !== e.anchorNode && (B(qe), Fe(21)), We = {
                start: e.anchorNode,
                startOffset: e.anchorOffset,
                end: e.focusNode,
                endOffset: e.focusOffset
            }, He = e, B(qe), qe = V(Fe, 500, 21)
        }
    }

    function Fe(t) {
        Si(_r.bind(this, t))
    }

    function Ve() {
        He = null, We = {
            start: 0,
            startOffset: 0,
            end: 0,
            endOffset: 0
        }
    }
    var Be, Je, Ke, Ge = [];

    function Ze(t) {
        Ge.push({
            time: f(t),
            event: 39,
            data: {
                target: Er(t)
            }
        }), Si(_r.bind(this, 39))
    }

    function Qe() {
        Ge = []
    }

    function $e(t) {
        Be = {
            name: t.type,
            persisted: t.persisted ? 1 : 0
        }, _r(26, f(t)), Eu()
    }

    function tn() {
        Be = null
    }

    function en(t) {
        if (void 0 === t && (t = null), "visibilityState" in document) {
            var e = "visible" === document.visibilityState ? 1 : 0;
            Je = {
                visible: e
            }, _r(28, f(t))
        }
    }

    function nn() {
        Je = null
    }

    function an() {
        Ke = null
    }

    function rn(t) {
        Ke = {
            focused: t
        }, _r(50)
    }

    function on(t) {
        ! function(t) {
            var e = Ga(t);
            Yo(e ? e.contentWindow : t === document ? window : t, "scroll", Ye, !0)
        }(t), t.nodeType === Node.DOCUMENT_NODE && (function(t) {
            Yo(t, "click", ee.bind(this, 9, t), !0), Yo(t, "contextmenu", ee.bind(this, 48, t), !0)
        }(t), function(t) {
            Yo(t, "cut", ue.bind(this, 0), !0), Yo(t, "copy", ue.bind(this, 1), !0), Yo(t, "paste", ue.bind(this, 2), !0)
        }(t), function(t) {
            Yo(t, "mousedown", we.bind(this, 13, t), !0), Yo(t, "mouseup", we.bind(this, 14, t), !0), Yo(t, "mousemove", we.bind(this, 12, t), !0), Yo(t, "wheel", we.bind(this, 15, t), !0), Yo(t, "dblclick", we.bind(this, 16, t), !0), Yo(t, "touchstart", Se.bind(this, 17, t), !0), Yo(t, "touchend", Se.bind(this, 18, t), !0), Yo(t, "touchmove", Se.bind(this, 19, t), !0), Yo(t, "touchcancel", Se.bind(this, 20, t), !0)
        }(t), function(t) {
            Yo(t, "input", de, !0)
        }(t), function(t) {
            Yo(t, "selectstart", Ue.bind(this, t), !0), Yo(t, "selectionchange", Ue.bind(this, t), !0)
        }(t), function(t) {
            Yo(t, "change", Gt, !0)
        }(t), function(t) {
            Yo(t, "submit", Ze, !0)
        }(t))
    }
    var un = Object.freeze({
        __proto__: null,
        observe: on,
        start: function() {
            Nr = [], xr(), ie(), ce(), Ee(), pe(), Ne = !1, Yo(window, "resize", Me), xe(), Yo(document, "visibilitychange", en), en(), Yo(window, "focus", (function() {
                return rn(1)
            })), Yo(window, "blur", (function() {
                return rn(0)
            })), De = [], je(), Ve(), Zt(), Qe(), Yo(window, "pagehide", $e)
        },
        stop: function() {
            Nr = [], xr(), ie(), ce(), B(ge), ve.length > 0 && Oe(ve[ve.length - 1].event), B(se), pe(), Ce(), nn(), an(), B(Ae), Ye.cleanup(), De = [], Pe = null, Re = null, Ve(), B(qe), Zt(), Qe(), tn()
        }
    });

    function cn(t) {
        for (var e = [], n = {}, a = 0, r = null, i = 0; i < t.length; i++)
            if ("string" == typeof t[i]) {
                var o = t[i],
                    u = n[o] || -1;
                u >= 0 ? r ? r.push(u) : (r = [u], e.push(r), a++) : (r = null, e.push(o), n[o] = a++)
            } else r = null, e.push(t[i]), a++;
        return e
    }
    var sn = [],
        ln = [],
        dn = "claritySheetId",
        fn = {},
        pn = {},
        hn = [],
        vn = [];

    function gn(t) {
        c.lean && c.lite || null == t || (t.clarityOverrides = t.clarityOverrides || {}, t.CSSStyleSheet && t.CSSStyleSheet.prototype && (void 0 === t.clarityOverrides.replace && (t.clarityOverrides.replace = t.CSSStyleSheet.prototype.replace, t.CSSStyleSheet.prototype.replace = function() {
            return $o() && vn.indexOf(this[dn]) > -1 && wn(f(), this[dn], 1, arguments[0]), t.clarityOverrides.replace.apply(this, arguments)
        }), void 0 === t.clarityOverrides.replaceSync && (t.clarityOverrides.replaceSync = t.CSSStyleSheet.prototype.replaceSync, t.CSSStyleSheet.prototype.replaceSync = function() {
            return $o() && vn.indexOf(this[dn]) > -1 && wn(f(), this[dn], 2, arguments[0]), t.clarityOverrides.replaceSync.apply(this, arguments)
        })))
    }

    function mn() {
        gn(window)
    }

    function yn(t, e) {
        if ((!c.lean || !c.lite) && (-1 === hn.indexOf(t) && (hn.push(t), t.defaultView && gn(t.defaultView)), e = e || f(), null == t ? void 0 : t.adoptedStyleSheets)) {
            for (var n = [], a = 0, r = t.adoptedStyleSheets; a < r.length; a++) {
                var i = r[a];
                i[dn] && -1 !== vn.indexOf(i[dn]) || (i[dn] = To(), vn.push(i[dn]), wn(e, i[dn], 0), wn(e, i[dn], 2, Sa(i))), n.push(i[dn])
            }
            var o = Va(t, !0);
            fn[o] || (fn[o] = []),
                function(t, e) {
                    if (t.length !== e.length) return !1;
                    return t.every((function(t, n) {
                        return t === e[n]
                    }))
                }(n, fn[o]) || (! function(t, e, n, a) {
                    ln.push({
                        time: t,
                        event: 45,
                        data: {
                            id: e,
                            operation: n,
                            newIds: a
                        }
                    }), zn(45)
                }(e, t == document ? -1 : Va(t), 3, n), fn[o] = n, pn[o] = e)
        }
    }

    function bn() {
        ln = [], sn = []
    }

    function wn(t, e, n, a) {
        sn.push({
            time: t,
            event: 46,
            data: {
                id: e,
                operation: n,
                cssRules: a
            }
        }), zn(46)
    }
    var Sn = [],
        kn = null,
        On = null,
        En = null,
        Tn = null,
        _n = null,
        Nn = null,
        Mn = "clarityAnimationId",
        xn = "clarityOperationCount",
        In = 20;

    function Cn() {
        Sn = []
    }

    function Dn(t, e, n, a, r, i, o) {
        Sn.push({
            time: t,
            event: 44,
            data: {
                id: e,
                operation: n,
                keyFrames: a,
                timing: r,
                targetId: i,
                timeline: o
            }
        }), zn(44)
    }

    function Pn(t, e) {
        null === t && (t = Animation.prototype[e], Animation.prototype[e] = function() {
            return Rn(this, e), t.apply(this, arguments)
        })
    }

    function Rn(t, e) {
        if ($o()) {
            var n = t.effect,
                a = (null == n ? void 0 : n.target) ? Va(n.target) : null;
            if (null !== a && n.getKeyframes && n.getTiming) {
                if (!t[Mn]) {
                    t[Mn] = To(), t[xn] = 0;
                    var r = n.getKeyframes(),
                        i = n.getTiming();
                    Dn(f(), t[Mn], 0, JSON.stringify(r), JSON.stringify(i), a)
                }
                if (t[xn]++ < In) {
                    var o = null;
                    switch (e) {
                        case "play":
                            o = 1;
                            break;
                        case "pause":
                            o = 2;
                            break;
                        case "cancel":
                            o = 3;
                            break;
                        case "finish":
                            o = 4;
                            break;
                        case "commitStyles":
                            o = 5
                    }
                    o && Dn(f(), t[Mn], o)
                }
            }
        }
    }
    var An, jn = [],
        Yn = new Set;

    function Xn(t) {
        Yn.has(t) || (Yn.add(t), jn.push(t), Si(zn.bind(this, 51)))
    }

    function Ln() {
        jn.length = 0
    }

    function zn(t, e, n) {
        return void 0 === e && (e = null), void 0 === n && (n = null), it(this, void 0, void 0, (function() {
            var a, r, i, o, u, s, l, d, p, h, v, g, m, y, b, w, k, O, E, T, _, N, M, x, I, C, R, A, j, Y, X, L;
            return ot(this, (function(z) {
                switch (z.label) {
                    case 0:
                        switch (a = n || f(), r = [a, t], t) {
                            case 8:
                                return [3, 1];
                            case 7:
                                return [3, 2];
                            case 45:
                            case 46:
                                return [3, 3];
                            case 44:
                                return [3, 4];
                            case 5:
                            case 6:
                                return [3, 5];
                            case 51:
                                return [3, 12]
                        }
                        return [3, 13];
                    case 1:
                        return i = An, r.push(i.width), r.push(i.height), D(t, i.width, i.height), ei(r), [3, 13];
                    case 2:
                        for (o = 0, u = dr; o < u.length; o++) s = u[o], (r = [s.time, 7]).push(s.data.id), r.push(s.data.interaction), r.push(s.data.visibility), r.push(s.data.name), ei(r, !1);
                        return Or(), [3, 13];
                    case 3:
                        for (l = 0, d = ln; l < d.length; l++) m = d[l], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.newIds), ei(r);
                        for (p = 0, h = sn; p < h.length; p++) m = h[p], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.cssRules), ei(r, !1);
                        return bn(), [3, 13];
                    case 4:
                        for (v = 0, g = Sn; v < g.length; v++) m = g[v], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.keyFrames), r.push(m.data.timing), r.push(m.data.timeline), r.push(m.data.targetId), ei(r);
                        return Cn(), [3, 13];
                    case 5:
                        if (2 === Oi(e)) return [3, 13];
                        if (!((y = ur()).length > 0)) return [3, 11];
                        b = 0, w = y, z.label = 6;
                    case 6:
                        return b < w.length ? (k = w[b], 0 !== (O = Oi(e)) ? [3, 8] : [4, _i(e)]) : [3, 10];
                    case 7:
                        O = z.sent(), z.label = 8;
                    case 8:
                        if (2 === O) return [3, 10];
                        for (E = k.data, T = k.metadata.active, _ = k.metadata.suspend, N = k.metadata.privacy, M = function(t) {
                                var e = t.metadata.privacy;
                                return "*T" === t.data.tag && !(0 === e || 1 === e)
                            }(k), x = 0, I = T ? ["tag", "attributes", "value"] : ["tag"]; x < I.length; x++)
                            if (E[C = I[x]] || "" === E[C]) switch (C) {
                                case "tag":
                                    R = Wn(k), A = M ? -1 : 1, r.push(k.id * A), k.parent && T && (r.push(k.parent), k.previous && r.push(k.previous)), r.push(_ ? "*M" : E[C]), R && 2 === R.length && r.push("".concat("#").concat(Hn(R[0]), ".").concat(Hn(R[1])));
                                    break;
                                case "attributes":
                                    for (j in E[C]) void 0 !== E[C][j] && r.push(qn(j, E[C][j], N));
                                    break;
                                case "value":
                                    Jt(k.metadata.fraud, k.id, E[C]), r.push(S(E[C], E.tag, N, M))
                            }
                        z.label = 9;
                    case 9:
                        return b++, [3, 6];
                    case 10:
                        6 === t && P(a), ei(cn(r), !c.lean), z.label = 11;
                    case 11:
                        return [3, 13];
                    case 12:
                        for (Y = 0, X = jn; Y < X.length; Y++) L = X[Y], ei([a, 51, L]);
                        return Ln(), [3, 13];
                    case 13:
                        return [2]
                }
            }))
        }))
    }

    function Wn(t) {
        if (null !== t.metadata.size && 0 === t.metadata.size.length) {
            var e = nr(t.id);
            if (e) return [Math.floor(100 * e.offsetWidth), Math.floor(100 * e.offsetHeight)]
        }
        return t.metadata.size
    }

    function Hn(t) {
        return t.toString(36)
    }

    function qn(t, e, n) {
        return "".concat(t, "=").concat(S(e, 0 === t.indexOf("data-") ? "data-" : t, n))
    }

    function Un() {
        An = null
    }

    function Fn() {
        var t = document.body,
            e = document.documentElement,
            n = t ? t.clientWidth : null,
            a = t ? t.scrollWidth : null,
            r = t ? t.offsetWidth : null,
            i = e ? e.clientWidth : null,
            o = e ? e.scrollWidth : null,
            u = e ? e.offsetWidth : null,
            c = Math.max(n, a, r, i, o, u),
            s = t ? t.clientHeight : null,
            l = t ? t.scrollHeight : null,
            d = t ? t.offsetHeight : null,
            f = e ? e.clientHeight : null,
            p = e ? e.scrollHeight : null,
            h = e ? e.offsetHeight : null,
            v = Math.max(s, l, d, f, p, h);
        null !== An && c === An.width && v === An.height || null === c || null === v || (An = {
            width: c,
            height: v
        }, zn(8))
    }

    function Vn(t, e, n, a) {
        return it(this, void 0, void 0, (function() {
            var r, i, o, u, c;
            return ot(this, (function(s) {
                switch (s.label) {
                    case 0:
                        r = [t], s.label = 1;
                    case 1:
                        if (!(r.length > 0)) return [3, 4];
                        for (i = r.shift(), o = i.firstChild; o;) r.push(o), o = o.nextSibling;
                        return 0 !== (u = Oi(e)) ? [3, 3] : [4, _i(e)];
                    case 2:
                        u = s.sent(), s.label = 3;
                    case 3:
                        return 2 === u ? [3, 4] : ((c = ma(i, n, a)) && r.push(c), [3, 1]);
                    case 4:
                        return [2]
                }
            }))
        }))
    }
    var Bn = new Set,
        Jn = [],
        Kn = {},
        Gn = [],
        Zn = null,
        Qn = null,
        $n = null,
        ta = {},
        ea = new WeakMap,
        na = ["data-google-query-id", "data-load-complete", "data-google-container-id"];

    function aa() {
        Bn = new Set, Gn = [], Zn = null, $n = 0, ta = {}, ea = new WeakMap, da(window)
    }

    function ra(t) {
        var e = f();
        et(6, e), Jn.push({
            time: e,
            mutations: t
        }), Si(oa, 1).then((function() {
            V(Fn), Ao(br)()
        }))
    }

    function ia(t, e, n, a) {
        return it(this, void 0, void 0, (function() {
            var r, i, o;
            return ot(this, (function(u) {
                switch (u.label) {
                    case 0:
                        return 0 !== (r = Oi(t)) ? [3, 2] : [4, _i(t)];
                    case 1:
                        r = u.sent(), u.label = 2;
                    case 2:
                        if (2 === r) return [2];
                        switch (i = e.target, o = c.throttleDom ? function(t, e, n, a) {
                            var r = t.target ? rr(t.target.parentNode) : null;
                            if (r && "HTML" !== r.data.tag) {
                                var i = a > $n,
                                    o = rr(t.target),
                                    u = o && o.selector ? o.selector.join() : t.target.nodeName,
                                    c = [r.selector ? r.selector.join() : "", u, t.attributeName, ua(t.addedNodes), ua(t.removedNodes)].join();
                                ta[c] = c in ta ? ta[c] : [0, n];
                                var s = ta[c];
                                if (!1 === i && s[0] >= 10 && ca(s[2], 2, e, a), s[0] = i ? s[1] === n ? s[0] : s[0] + 1 : 1, s[1] = n, s[0] >= 10) return s[2] = t.removedNodes, n > a + 3e3 ? t.type : (Kn[c] = {
                                    mutation: t,
                                    timestamp: a
                                }, "throttle")
                            }
                            return t.type
                        }(e, t, n, a) : e.type, o && i && i.ownerDocument && Fa(i.ownerDocument), o && i && i.nodeType == Node.DOCUMENT_FRAGMENT_NODE && i.host && Fa(i), o) {
                            case "attributes":
                                na.indexOf(e.attributeName) < 0 && ma(i, 3, a);
                                break;
                            case "characterData":
                                ma(i, 4, a);
                                break;
                            case "childList":
                                ca(e.addedNodes, 1, t, a), ca(e.removedNodes, 2, t, a)
                        }
                        return [2]
                }
            }))
        }))
    }

    function oa() {
        return it(this, void 0, void 0, (function() {
            var t, e, n, a, r, i, o, u, c, s, l;
            return ot(this, (function(d) {
                switch (d.label) {
                    case 0:
                        Ei(t = {
                            id: go(),
                            cost: 3
                        }), d.label = 1;
                    case 1:
                        if (!(Jn.length > 0)) return [3, 7];
                        e = Jn.shift(), n = f(), a = 0, r = e.mutations, d.label = 2;
                    case 2:
                        return a < r.length ? (i = r[a], [4, ia(t, i, n, e.time)]) : [3, 5];
                    case 3:
                        d.sent(), d.label = 4;
                    case 4:
                        return a++, [3, 2];
                    case 5:
                        return [4, zn(6, t, e.time)];
                    case 6:
                        return d.sent(), [3, 1];
                    case 7:
                        o = !1, u = 0, c = Object.keys(Kn), d.label = 8;
                    case 8:
                        return u < c.length ? (s = c[u], l = Kn[s], delete Kn[s], [4, ia(t, l.mutation, f(), l.timestamp)]) : [3, 11];
                    case 9:
                        d.sent(), o = !0, d.label = 10;
                    case 10:
                        return u++, [3, 8];
                    case 11:
                        return Object.keys(Kn).length > 0 && function() {
                            Qn && B(Qn);
                            Qn = V((function() {
                                Si(oa, 1)
                            }), 33)
                        }(), 0 === Object.keys(Kn).length && o ? [4, zn(6, t, f())] : [3, 13];
                    case 12:
                        d.sent(), d.label = 13;
                    case 13:
                        return function() {
                            var t = f();
                            Object.keys(ta).length > 1e4 && (ta = {}, q(38));
                            for (var e = 0, n = Object.keys(ta); e < n.length; e++) {
                                var a = n[e];
                                t > ta[a][1] + 3e4 && delete ta[a]
                            }
                        }(), Ti(t), [2]
                }
            }))
        }))
    }

    function ua(t) {
        for (var e = [], n = 0; t && n < t.length; n++) e.push(t[n].nodeName);
        return e.join()
    }

    function ca(t, e, n, a) {
        return it(this, void 0, void 0, (function() {
            var r, i, o, u;
            return ot(this, (function(c) {
                switch (c.label) {
                    case 0:
                        r = t ? t.length : 0, i = 0, c.label = 1;
                    case 1:
                        return i < r ? (o = t[i], 1 !== e ? [3, 2] : (Vn(o, n, e, a), [3, 5])) : [3, 6];
                    case 2:
                        return 0 !== (u = Oi(n)) ? [3, 4] : [4, _i(n)];
                    case 3:
                        u = c.sent(), c.label = 4;
                    case 4:
                        if (2 === u) return [3, 6];
                        ma(o, e, a), c.label = 5;
                    case 5:
                        return i++, [3, 1];
                    case 6:
                        return [2]
                }
            }))
        }))
    }

    function sa(t) {
        return Gn.indexOf(t) < 0 && Gn.push(t), Zn && B(Zn), Zn = V((function() {
            ! function() {
                for (var t = 0, e = Gn; t < e.length; t++) {
                    var n = e[t];
                    if (n) {
                        var a = n.nodeType === Node.DOCUMENT_FRAGMENT_NODE;
                        if (a && or(n)) continue;
                        la(n, a ? "childList" : "characterData")
                    }
                }
                Gn = []
            }()
        }), 33), t
    }

    function la(t, e) {
        Ao(ra)([{
            addedNodes: [t],
            attributeName: null,
            attributeNamespace: null,
            nextSibling: null,
            oldValue: null,
            previousSibling: null,
            removedNodes: [],
            target: t,
            type: e
        }])
    }

    function da(t) {
        if (null != t && (t.clarityOverrides = t.clarityOverrides || {}, void 0 === t.clarityOverrides.InsertRule && (t.clarityOverrides.InsertRule = t.CSSStyleSheet.prototype.insertRule, t.CSSStyleSheet.prototype.insertRule = function() {
                return $o() && sa(this.ownerNode), t.clarityOverrides.InsertRule.apply(this, arguments)
            }), "CSSMediaRule" in t && void 0 === t.clarityOverrides.MediaInsertRule && (t.clarityOverrides.MediaInsertRule = t.CSSMediaRule.prototype.insertRule, t.CSSMediaRule.prototype.insertRule = function() {
                return $o() && sa(this.parentStyleSheet.ownerNode), t.clarityOverrides.MediaInsertRule.apply(this, arguments)
            }), void 0 === t.clarityOverrides.DeleteRule && (t.clarityOverrides.DeleteRule = t.CSSStyleSheet.prototype.deleteRule, t.CSSStyleSheet.prototype.deleteRule = function() {
                return $o() && sa(this.ownerNode), t.clarityOverrides.DeleteRule.apply(this, arguments)
            }), "CSSMediaRule" in t && void 0 === t.clarityOverrides.MediaDeleteRule && (t.clarityOverrides.MediaDeleteRule = t.CSSMediaRule.prototype.deleteRule, t.CSSMediaRule.prototype.deleteRule = function() {
                return $o() && sa(this.parentStyleSheet.ownerNode), t.clarityOverrides.MediaDeleteRule.apply(this, arguments)
            }), void 0 === t.clarityOverrides.AttachShadow)) {
            t.clarityOverrides.AttachShadow = t.Element.prototype.attachShadow;
            try {
                t.Element.prototype.attachShadow = function() {
                    return $o() ? sa(t.clarityOverrides.AttachShadow.apply(this, arguments)) : t.clarityOverrides.AttachShadow.apply(this, arguments)
                }
            } catch (e) {
                t.clarityOverrides.AttachShadow = null
            }
        }
    }
    var fa = /[^0-9\.]/g;

    function pa(t) {
        for (var e = 0, n = Object.keys(t); e < n.length; e++) {
            var a = n[e],
                r = t[a];
            if ("@type" === a && "string" == typeof r) switch (r = (r = r.toLowerCase()).indexOf("article") >= 0 || r.indexOf("posting") >= 0 ? "article" : r) {
                case "article":
                case "recipe":
                    Ji(5, t[a]), Ji(8, t.creator), Ji(18, t.headline);
                    break;
                case "product":
                    Ji(5, t[a]), Ji(10, t.name), Ji(12, t.sku), t.brand && Ji(6, t.brand.name);
                    break;
                case "aggregaterating":
                    t.ratingValue && (F(11, ha(t.ratingValue, 100)), F(18, ha(t.bestRating)), F(19, ha(t.worstRating))), F(12, ha(t.ratingCount)), F(17, ha(t.reviewCount));
                    break;
                case "offer":
                    Ji(7, t.availability), Ji(14, t.itemCondition), Ji(13, t.priceCurrency), Ji(12, t.sku), F(13, ha(t.price));
                    break;
                case "brand":
                    Ji(6, t.name)
            }
            null !== r && "object" == typeof r && pa(r)
        }
    }

    function ha(t, e) {
        if (void 0 === e && (e = 1), null !== t) switch (typeof t) {
            case "number":
                return Math.round(t * e);
            case "string":
                return Math.round(parseFloat(t.replace(fa, "")) * e)
        }
        return null
    }
    var va = ["title", "alt", "onload", "onfocus", "onerror", "data-drupal-form-submit-last", "aria-label"],
        ga = /[\r\n]+/g;

    function ma(e, n, a) {
        var r, i = null;
        if (2 === n && !1 === or(e)) return i;
        0 !== n && e.nodeType === Node.TEXT_NODE && e.parentElement && "STYLE" === e.parentElement.tagName && (e = e.parentNode);
        var o = !1 === or(e) ? "add" : "update",
            u = e.parentElement ? e.parentElement : null,
            c = e.ownerDocument !== document;
        switch (e.nodeType) {
            case Node.DOCUMENT_TYPE_NODE:
                u = c && e.parentNode ? Ga(e.parentNode) : u;
                var s = e,
                    l = {
                        tag: (c ? "iframe:" : "") + "*D",
                        attributes: {
                            name: s.name ? s.name : "HTML",
                            publicId: s.publicId,
                            systemId: s.systemId
                        }
                    };
                t[o](e, u, l, n);
                break;
            case Node.DOCUMENT_NODE:
                e === document && Fa(document), yn(e, a), ya(e);
                break;
            case Node.DOCUMENT_FRAGMENT_NODE:
                var d = e;
                if (d.host) {
                    if (Fa(d), "function" === typeof d.constructor && d.constructor.toString().indexOf("[native code]") >= 0) {
                        ya(d);
                        var f = {
                            tag: "*S",
                            attributes: {
                                style: ""
                            }
                        };
                        t[o](e, d.host, f, n)
                    } else t[o](e, d.host, {
                        tag: "*P",
                        attributes: {}
                    }, n);
                    yn(e, a)
                }
                break;
            case Node.TEXT_NODE:
                if (u = u || e.parentNode, "update" === o || u && or(u) && "STYLE" !== u.tagName && "NOSCRIPT" !== u.tagName) {
                    var p = {
                        tag: "*T",
                        value: e.nodeValue
                    };
                    t[o](e, u, p, n)
                }
                break;
            case Node.ELEMENT_NODE:
                var h = e,
                    v = h.tagName,
                    g = function(t) {
                        var e = {},
                            n = t.attributes;
                        if (n && n.length > 0)
                            for (var a = 0; a < n.length; a++) {
                                var r = n[a].name;
                                va.indexOf(r) < 0 && (e[r] = n[a].value)
                            }
                        "INPUT" === t.tagName && !("value" in e) && t.value && (e.value = t.value);
                        return e
                    }(h);
                switch (u = e.parentElement ? e.parentElement : e.parentNode ? e.parentNode : null, "http://www.w3.org/2000/svg" === h.namespaceURI && (v = "svg:" + v), v) {
                    case "HTML":
                        u = c && u ? Ga(u) : u;
                        var m = {
                            tag: (c ? "iframe:" : "") + v,
                            attributes: g
                        };
                        t[o](e, u, m, n);
                        break;
                    case "SCRIPT":
                        if ("type" in g && "application/ld+json" === g.type) try {
                            pa(JSON.parse(h.text.replace(ga, "")))
                        } catch (t) {}
                        break;
                    case "NOSCRIPT":
                        var y = {
                            tag: v,
                            attributes: {},
                            value: ""
                        };
                        t[o](e, u, y, n);
                        break;
                    case "META":
                        var b = "property" in g ? "property" : "name" in g ? "name" : null;
                        if (b && "content" in g) {
                            var w = g.content;
                            switch (g[b]) {
                                case "og:title":
                                    Ji(20, w);
                                    break;
                                case "og:type":
                                    Ji(19, w);
                                    break;
                                case "generator":
                                    Ji(21, w)
                            }
                        }
                        break;
                    case "HEAD":
                        var S = {
                                tag: v,
                                attributes: g
                            },
                            k = c && (null === (r = e.ownerDocument) || void 0 === r ? void 0 : r.location) ? e.ownerDocument.location : location;
                        S.attributes["*B"] = k.protocol + "//" + k.host + k.pathname, t[o](e, u, S, n);
                        break;
                    case "BASE":
                        var O = rr(e.parentElement);
                        if (O) {
                            var E = document.createElement("a");
                            E.href = g.href, O.data.attributes["*B"] = E.protocol + "//" + E.host + E.pathname
                        }
                        break;
                    case "STYLE":
                        var T = {
                            tag: v,
                            attributes: g,
                            value: wa(h)
                        };
                        t[o](e, u, T, n);
                        break;
                    case "IFRAME":
                        var _ = e,
                            N = {
                                tag: v,
                                attributes: g
                            };
                        Ka(_) && (! function(t) {
                            !1 === or(t) && Yo(t, "load", la.bind(this, t, "childList"), !0)
                        }(_), N.attributes["*O"] = "true", _.contentDocument && _.contentWindow && "loading" !== _.contentDocument.readyState && (i = _.contentDocument)), 2 === n && ba(_), t[o](e, u, N, n);
                        break;
                    case "LINK":
                        if (so && "stylesheet" === g.rel) {
                            for (var M in Object.keys(document.styleSheets)) {
                                var x = document.styleSheets[M];
                                if (x.ownerNode == h) {
                                    var I = {
                                        tag: "STYLE",
                                        attributes: g,
                                        value: Sa(x)
                                    };
                                    t[o](e, u, I, n);
                                    break
                                }
                            }
                            break
                        }
                        var C = {
                            tag: v,
                            attributes: g
                        };
                        t[o](e, u, C, n);
                        break;
                    case "VIDEO":
                    case "AUDIO":
                    case "SOURCE":
                        "src" in g && g.src.startsWith("data:") && (g.src = "");
                        var D = {
                            tag: v,
                            attributes: g
                        };
                        t[o](e, u, D, n);
                        break;
                    default:
                        ! function(t) {
                            var e;
                            (null === (e = window.customElements) || void 0 === e ? void 0 : e.get) && window.customElements.get(t) && Xn(t)
                        }(h.localName);
                        var P = {
                            tag: v,
                            attributes: g
                        };
                        h.shadowRoot && (i = h.shadowRoot), t[o](e, u, P, n)
                }
        }
        return i
    }

    function ya(t) {
        or(t) || zo(t) || (! function(t) {
            try {
                var e = s("MutationObserver"),
                    n = e in window ? new window[e](Ao(ra)) : null;
                n && (n.observe(t, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                }), ea.set(t, n), Bn.add(n)), t.defaultView && da(t.defaultView)
            } catch (t) {
                pi(2, 0, t ? t.name : null)
            }
        }(t), on(t))
    }

    function ba(t) {
        Lo(t);
        var e, n, a = Za(t) || {},
            r = a.doc,
            i = void 0 === r ? null : r,
            o = a.win,
            u = void 0 === o ? null : o;
        u && Lo(u), i && (Lo(i), e = i, (n = ea.get(e)) && (n.disconnect(), Bn.delete(n), ea.delete(e)), Qa(t, i))
    }

    function wa(t) {
        var e = t.textContent ? t.textContent.trim() : "",
            n = t.dataset ? Object.keys(t.dataset).length : 0;
        return (0 === e.length || n > 0 || t.id.length > 0) && (e = Sa(t.sheet)), e
    }

    function Sa(t) {
        var e = "",
            n = null;
        try {
            n = t ? t.cssRules : []
        } catch (t) {
            if (pi(1, 1, t ? t.name : null), t && "SecurityError" !== t.name) throw t
        }
        if (null !== n)
            for (var a = 0; a < n.length; a++) e += n[a].cssText;
        return e
    }
    var ka = "load,active,fixed,visible,focus,show,collaps,animat".split(","),
        Oa = {};

    function Ea(t, e) {
        var n = t.attributes,
            a = t.prefix ? t.prefix[e] : null,
            r = 0 === e ? "".concat("~").concat(t.position - 1) : ":nth-of-type(".concat(t.position, ")");
        switch (t.tag) {
            case "STYLE":
            case "TITLE":
            case "LINK":
            case "META":
            case "*T":
            case "*D":
                return "";
            case "HTML":
                return "HTML";
            default:
                if (null === a) return "";
                a = "".concat(a).concat(">"), t.tag = 0 === t.tag.indexOf("svg:") ? t.tag.substr("svg:".length) : t.tag;
                var i = "".concat(a).concat(t.tag).concat(r),
                    o = "id" in n && n.id.length > 0 ? n.id : null,
                    u = "BODY" !== t.tag && "class" in n && n.class.length > 0 ? n.class.trim().split(/\s+/).filter((function(t) {
                        return Ta(t)
                    })).join(".") : null;
                if (u && u.length > 0)
                    if (0 === e) {
                        var c = "".concat(function(t) {
                            for (var e = t.split(">"), n = 0; n < e.length; n++) {
                                var a = e[n].indexOf("~"),
                                    r = e[n].indexOf(".");
                                e[n] = e[n].substring(0, r > 0 ? r : a > 0 ? a : e[n].length)
                            }
                            return e.join(">")
                        }(a)).concat(t.tag).concat(".").concat(u);
                        c in Oa || (Oa[c] = []), Oa[c].indexOf(t.id) < 0 && Oa[c].push(t.id), i = "".concat(c).concat("~").concat(Oa[c].indexOf(t.id))
                    } else i = "".concat(a).concat(t.tag, ".").concat(u).concat(r);
                return i = o && Ta(o) ? "".concat(function(t) {
                    var e = t.lastIndexOf("*S"),
                        n = t.lastIndexOf("".concat("iframe:").concat("HTML")),
                        a = Math.max(e, n);
                    if (a < 0) return "";
                    return t.substring(0, t.indexOf(">", a) + 1)
                }(a)).concat("#").concat(o) : i, i
        }
    }

    function Ta(t) {
        if (!t) return !1;
        if (ka.some((function(e) {
                return t.toLowerCase().indexOf(e) >= 0
            }))) return !1;
        for (var e = 0; e < t.length; e++) {
            var n = t.charCodeAt(e);
            if (n >= 48 && n <= 57) return !1
        }
        return !0
    }
    var _a = 1,
        Na = null,
        Ma = [],
        xa = [],
        Ia = {},
        Ca = [],
        Da = [],
        Pa = [],
        Ra = [],
        Aa = [],
        ja = [],
        Ya = null,
        Xa = null,
        La = null,
        za = null,
        Wa = null;

    function Ha() {
        Ua(), Fa(document, !0)
    }

    function qa() {
        Ua()
    }

    function Ua() {
        _a = 1, Ma = [], xa = [], Ia = {}, Ca = [], Da = [], Pa = "address,password,contact".split(","), Ra = "password,secret,pass,social,ssn,code,hidden".split(","), Aa = "radio,checkbox,range,button,reset,submit".split(","), ja = "INPUT,SELECT,TEXTAREA".split(","), Na = new Map, Ya = new WeakMap, Xa = new WeakMap, La = new WeakMap, za = new WeakMap, Wa = new WeakMap, Oa = {}
    }

    function Fa(t, e) {
        void 0 === e && (e = !1);
        try {
            e && c.unmask.forEach((function(t) {
                return t.indexOf("!") < 0 ? Da.push(t) : Ca.push(t.substr(1))
            })), "querySelectorAll" in t && (c.regions.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return mr(t, "".concat(e[0]))
                }))
            })), c.mask.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return za.set(t, 3)
                }))
            })), c.checksum.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return Wa.set(t, e[0])
                }))
            })), Da.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return za.set(t, 0)
                }))
            })))
        } catch (t) {
            pi(5, 1, t ? t.name : null)
        }
    }

    function Va(t, e) {
        if (void 0 === e && (e = !1), null === t) return null;
        var n = Ya.get(t);
        return !n && e && (n = _a++, Ya.set(t, n)), n || null
    }

    function Ba(t, e, n, a) {
        var r = e ? Va(e) : null;
        if (e && r || null != t.host || t.nodeType === Node.DOCUMENT_TYPE_NODE) {
            var i = Va(t, !0),
                o = sr(t),
                u = null,
                s = yr(t) ? i : null,
                l = Wa.has(t) ? Wa.get(t) : null,
                d = c.content ? 1 : 3;
            r >= 0 && Ma[r] && ((u = Ma[r]).children.push(i), s = null === s ? u.region : s, l = null === l ? u.metadata.fraud : l, d = u.metadata.privacy), n.attributes && "data-clarity-region" in n.attributes && (mr(t, n.attributes["data-clarity-region"]), s = i), Na.set(i, t), Ma[i] = {
                    id: i,
                    parent: r,
                    previous: o,
                    children: [],
                    data: n,
                    selector: null,
                    hash: null,
                    region: s,
                    metadata: {
                        active: !0,
                        suspend: !1,
                        privacy: d,
                        position: null,
                        fraud: l,
                        size: null
                    }
                },
                function(t, e, n) {
                    var a, r = e.data,
                        i = e.metadata,
                        o = i.privacy,
                        u = r.attributes || {},
                        c = r.tag.toUpperCase();
                    switch (!0) {
                        case ja.indexOf(c) >= 0:
                            var s = u.type,
                                l = "",
                                d = ["class", "style"];
                            Object.keys(u).filter((function(t) {
                                return !d.includes(t)
                            })).forEach((function(t) {
                                return l += u[t].toLowerCase()
                            }));
                            var f = Ra.some((function(t) {
                                return l.indexOf(t) >= 0
                            }));
                            i.privacy = "INPUT" === c && Aa.indexOf(s) >= 0 ? o : f ? 4 : 2;
                            break;
                        case "data-clarity-mask" in u:
                            i.privacy = 3;
                            break;
                        case "data-clarity-unmask" in u:
                            i.privacy = 0;
                            break;
                        case za.has(t):
                            i.privacy = za.get(t);
                            break;
                        case Wa.has(t):
                            i.privacy = 2;
                            break;
                        case "*T" === c:
                            var p = n && n.data ? n.data.tag : "",
                                h = n && n.selector ? n.selector[1] : "",
                                v = ["STYLE", "TITLE", "svg:style"];
                            i.privacy = v.includes(p) || Ca.some((function(t) {
                                return h.indexOf(t) >= 0
                            })) ? 0 : o;
                            break;
                        case 1 === o:
                            i.privacy = function(t, e, n) {
                                if (t && e.some((function(e) {
                                        return t.indexOf(e) >= 0
                                    }))) return 2;
                                return n.privacy
                            }(u.class, Pa, i);
                            break;
                        case "IMG" === c:
                            (null === (a = u.src) || void 0 === a ? void 0 : a.startsWith("blob:")) && (i.privacy = 3)
                    }
                }(t, Ma[i], u), tr(Ma[i]),
                function(t) {
                    if ("IMG" === t.data.tag && 3 === t.metadata.privacy) {
                        var e = nr(t.id);
                        !e || e.complete && 0 !== e.naturalWidth || Yo(e, "load", (function() {
                            e.setAttribute("data-clarity-loaded", "".concat(To()))
                        })), t.metadata.size = []
                    }
                }(Ma[i]), lr(i, a)
        }
    }

    function Ja(t, e, n, a) {
        var r = Va(t),
            i = e ? Va(e) : null,
            o = sr(t),
            u = !1,
            c = !1;
        if (r in Ma) {
            var s = Ma[r];
            if (s.metadata.active = !0, s.previous !== o && (u = !0, s.previous = o), s.parent !== i) {
                u = !0;
                var l = s.parent;
                if (s.parent = i, null !== i && i >= 0) {
                    var d = null === o ? 0 : Ma[i].children.indexOf(o) + 1;
                    Ma[i].children.splice(d, 0, r), s.region = yr(t) ? r : Ma[i].region
                } else ! function(t, e) {
                    if (t in Ma) {
                        var n = Ma[t];
                        n.metadata.active = !1, n.parent = null, lr(t, e), cr(t)
                    }
                }(r, a);
                if (null !== l && l >= 0) {
                    var f = Ma[l].children.indexOf(r);
                    f >= 0 && Ma[l].children.splice(f, 1)
                }
                c = !0
            }
            for (var p in n) $a(s.data, n, p) && (u = !0, s.data[p] = n[p]);
            tr(s), lr(r, a, u, c)
        }
    }

    function Ka(t) {
        var e = !1;
        if (t.nodeType === Node.ELEMENT_NODE && "IFRAME" === t.tagName) {
            var n = t;
            try {
                n.contentDocument && (Xa.set(n.contentDocument, n), La.set(n, {
                    doc: n.contentDocument,
                    win: n.contentWindow
                }), e = !0)
            } catch (t) {}
        }
        return e
    }

    function Ga(t) {
        var e = t.nodeType === Node.DOCUMENT_NODE ? t : null;
        return e && Xa.has(e) ? Xa.get(e) : null
    }

    function Za(t) {
        return La.has(t) ? La.get(t) : null
    }

    function Qa(t, e) {
        La.delete(t), Xa.delete(e)
    }

    function $a(t, e, n) {
        if ("object" == typeof t[n] && "object" == typeof e[n]) {
            for (var a in t[n])
                if (t[n][a] !== e[n][a]) return !0;
            for (var a in e[n])
                if (e[n][a] !== t[n][a]) return !0;
            return !1
        }
        return t[n] !== e[n]
    }

    function tr(t) {
        var e = t.parent && t.parent in Ma ? Ma[t.parent] : null,
            n = e ? e.selector : null,
            a = t.data,
            r = function(t, e) {
                e.metadata.position = 1;
                for (var n = t ? t.children.indexOf(e.id) : -1; n-- > 0;) {
                    var a = Ma[t.children[n]];
                    if (e.data.tag === a.data.tag) {
                        e.metadata.position = a.metadata.position + 1;
                        break
                    }
                }
                return e.metadata.position
            }(e, t),
            i = {
                id: t.id,
                tag: a.tag,
                prefix: n,
                position: r,
                attributes: a.attributes
            };
        t.selector = [Ea(i, 0), Ea(i, 1)], t.hash = t.selector.map((function(t) {
            return t ? h(t) : null
        })), t.hash.forEach((function(e) {
            return Ia[e] = t.id
        }))
    }

    function er(t) {
        var e = nr(ir(t));
        return null !== e && null !== e.textContent ? e.textContent.substr(0, 25) : ""
    }

    function nr(t) {
        return Na.has(t) ? Na.get(t) : null
    }

    function ar(t) {
        return t in Ma ? Ma[t] : null
    }

    function rr(t) {
        var e = Va(t);
        return e in Ma ? Ma[e] : null
    }

    function ir(t) {
        return t in Ia ? Ia[t] : null
    }

    function or(t) {
        return Na.has(Va(t))
    }

    function ur() {
        for (var t = [], e = 0, n = xa; e < n.length; e++) {
            var a = n[e];
            a in Ma && t.push(Ma[a])
        }
        return xa = [], t
    }

    function cr(t) {
        var e = Na.get(t);
        if ((null == e ? void 0 : e.nodeType) !== Node.DOCUMENT_FRAGMENT_NODE) {
            if (e && (null == e ? void 0 : e.nodeType) === Node.ELEMENT_NODE && "IFRAME" === e.tagName) ba(e);
            Na.delete(t);
            var n = t in Ma ? Ma[t] : null;
            if (n && n.children)
                for (var a = 0, r = n.children; a < r.length; a++) {
                    cr(r[a])
                }
        }
    }

    function sr(t) {
        for (var e = null; null === e && t.previousSibling;) e = Va(t.previousSibling), t = t.previousSibling;
        return e
    }

    function lr(t, e, n, a) {
        if (void 0 === n && (n = !0), void 0 === a && (a = !1), !c.lean || !c.lite) {
            var r = xa.indexOf(t);
            r >= 0 && 1 === e && a ? (xa.splice(r, 1), xa.push(t)) : -1 === r && n && xa.push(t)
        }
    }
    var dr = [],
        fr = null,
        pr = {},
        hr = [],
        vr = !1,
        gr = null;

    function mr(t, e) {
        !1 === fr.has(t) && (fr.set(t, e), (gr = null === gr && vr ? new IntersectionObserver(wr, {
            threshold: [0, .05, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1]
        }) : gr) && t && t.nodeType === Node.ELEMENT_NODE && gr.observe(t))
    }

    function yr(t) {
        return fr && fr.has(t)
    }

    function br() {
        for (var t = [], e = 0, n = hr; e < n.length; e++) {
            var a = n[e],
                r = Va(a.node);
            r ? (a.state.data.id = r, pr[r] = a.state.data, dr.push(a.state)) : t.push(a)
        }
        hr = t, dr.length > 0 && zn(7)
    }

    function wr(t) {
        for (var e = 0, n = t; e < n.length; e++) {
            var a = n[e],
                r = a.target,
                i = a.boundingClientRect,
                o = a.intersectionRect,
                u = a.rootBounds;
            if (fr.has(r) && i.width + i.height > 0 && u && u.width > 0 && u.height > 0) {
                var c = r ? Va(r) : null,
                    s = c in pr ? pr[c] : {
                        id: c,
                        name: fr.get(r),
                        interaction: 16,
                        visibility: 0
                    },
                    l = (o ? o.width * o.height * 1 / (u.width * u.height) : 0) > .05 || a.intersectionRatio > .8,
                    d = (l || 10 == s.visibility) && Math.abs(i.top) + u.height > i.height;
                Sr(r, s, s.interaction, d ? 13 : l ? 10 : 0), s.visibility >= 13 && gr && gr.unobserve(r)
            }
        }
        dr.length > 0 && zn(7)
    }

    function Sr(t, e, n, a) {
        var r = n > e.interaction || a > e.visibility;
        e.interaction = n > e.interaction ? n : e.interaction, e.visibility = a > e.visibility ? a : e.visibility, e.id ? (e.id in pr && r || !(e.id in pr)) && (pr[e.id] = e, dr.push(kr(e))) : hr.push({
            node: t,
            state: kr(e)
        })
    }

    function kr(t) {
        return {
            time: f(),
            data: {
                id: t.id,
                interaction: t.interaction,
                visibility: t.visibility,
                name: t.name
            }
        }
    }

    function Or() {
        dr = []
    }

    function Er(t) {
        var e = t.composed && t.composedPath ? t.composedPath() : null,
            n = e && e.length > 0 ? e[0] : t.target;
        return $n = f() + 3e3, n && n.nodeType === Node.DOCUMENT_NODE ? n.documentElement : n
    }

    function Tr(t, e, n) {
        void 0 === n && (n = null);
        var a = {
            id: 0,
            hash: null,
            privacy: 2
        };
        if (t) {
            var r = rr(t);
            if (null !== r) {
                var i = r.metadata;
                a.id = r.id, a.hash = r.hash, a.privacy = i.privacy, r.region && function(t, e) {
                    var n = nr(t),
                        a = t in pr ? pr[t] : {
                            id: t,
                            visibility: 0,
                            interaction: 16,
                            name: fr.get(n)
                        },
                        r = 16;
                    switch (e) {
                        case 9:
                            r = 20;
                            break;
                        case 27:
                            r = 30
                    }
                    Sr(n, a, r, a.visibility)
                }(r.region, e), i.fraud && Jt(i.fraud, r.id, n || r.data.value)
            }
        }
        return a
    }

    function _r(t, e) {
        return void 0 === e && (e = null), it(this, void 0, void 0, (function() {
            var n, a, r, i, o, u, c, s, l, d, p, h, v, g, m, y, b, w, O, E, T, _, N, M, x, I, C, P, A, j, Y, X, L, z, W, H;
            return ot(this, (function(q) {
                switch (n = e || f(), a = [n, t], t) {
                    case 13:
                    case 14:
                    case 12:
                    case 15:
                    case 16:
                    case 17:
                    case 18:
                    case 19:
                    case 20:
                        for (r = 0, i = ve; r < i.length; r++) z = i[r], (o = Tr(z.data.target, z.event)).id > 0 && ((a = [z.time, z.event]).push(o.id), a.push(z.data.x), a.push(z.data.y), void 0 !== z.data.id && (a.push(z.data.id), void 0 !== z.data.isPrimary && a.push(z.data.isPrimary.toString())), ei(a), (void 0 === z.data.isPrimary || z.data.isPrimary) && D(z.event, z.data.x, z.data.y, z.time));
                        Ee();
                        break;
                    case 9:
                    case 48:
                        for (u = 0, c = te; u < c.length; u++) z = c[u], s = Tr(z.data.target, z.event, z.data.text), a = [z.time, z.event], l = s.hash ? s.hash.join(".") : "", a.push(s.id), a.push(z.data.x), a.push(z.data.y), a.push(z.data.eX), a.push(z.data.eY), a.push(z.data.button), a.push(z.data.reaction), a.push(z.data.context), a.push(S(z.data.text, "click", s.privacy)), a.push(k(z.data.link)), a.push(l), a.push(z.data.trust), a.push(z.data.isFullText), a.push(z.data.w), a.push(z.data.h), a.push(z.data.tag), a.push(z.data.class), a.push(z.data.id), ei(a), Ir(z.time, z.event, l, z.data.x, z.data.y, z.data.reaction, z.data.context);
                        ie();
                        break;
                    case 38:
                        for (d = 0, p = oe; d < p.length; d++) z = p[d], a = [z.time, z.event], (Y = Tr(z.data.target, z.event)).id > 0 && (a.push(Y.id), a.push(z.data.action), ei(a));
                        ce();
                        break;
                    case 11:
                        h = he, a.push(h.width), a.push(h.height), D(t, h.width, h.height), Ce(), ei(a);
                        break;
                    case 26:
                        v = Be, a.push(v.name), a.push(v.persisted), tn(), ei(a);
                        break;
                    case 27:
                        for (g = 0, m = le; g < m.length; g++) z = m[g], y = Tr(z.data.target, z.event, z.data.value), (a = [z.time, z.event]).push(y.id), a.push(S(z.data.value, "input", y.privacy, !1, z.data.type)), a.push(z.data.trust), ei(a);
                        pe();
                        break;
                    case 21:
                        (b = We) && (w = Tr(b.start, t), O = Tr(b.end, t), a.push(w.id), a.push(b.startOffset), a.push(O.id), a.push(b.endOffset), Ve(), ei(a));
                        break;
                    case 10:
                        for (E = 0, T = De; E < T.length; E++) z = T[E], _ = Tr(z.data.target, z.event), N = Tr(z.data.top, z.event), M = Tr(z.data.bottom, z.event), x = (null == N ? void 0 : N.hash) ? N.hash.join(".") : "", I = (null == M ? void 0 : M.hash) ? M.hash.join(".") : "", _.id > 0 && ((a = [z.time, z.event]).push(_.id), a.push(z.data.x), a.push(z.data.y), a.push(x), a.push(I), ei(a), D(z.event, z.data.x, z.data.y, z.time));
                        De = [], Pe = null, Re = null;
                        break;
                    case 42:
                        for (C = 0, P = Kt; C < P.length; C++) z = P[C], a = [z.time, z.event], (Y = Tr(z.data.target, z.event)).id > 0 && ((a = [z.time, z.event]).push(Y.id), a.push(z.data.type), a.push(S(z.data.value, "change", Y.privacy)), a.push(S(z.data.checksum, "checksum", Y.privacy)), ei(a));
                        Zt();
                        break;
                    case 39:
                        for (A = 0, j = Ge; A < j.length; A++) z = j[A], a = [z.time, z.event], (Y = Tr(z.data.target, z.event)).id > 0 && (a.push(Y.id), ei(a));
                        Qe();
                        break;
                    case 22:
                        for (X = 0, L = Mr; X < L.length; X++) z = L[X], (a = [z.time, z.event]).push(z.data.type), a.push(z.data.hash), a.push(z.data.x), a.push(z.data.y), a.push(z.data.reaction), a.push(z.data.context), ei(a, !1);
                        xr();
                        break;
                    case 28:
                        W = Je, a.push(W.visible), ei(a), R(n, W.visible), nn();
                        break;
                    case 50:
                        H = Ke, a.push(H.focused), ei(a, !1), an()
                }
                return [2]
            }))
        }))
    }
    var Nr = [],
        Mr = [];

    function xr() {
        Mr = []
    }

    function Ir(t, e, n, a, r, i, o) {
        void 0 === i && (i = 1), void 0 === o && (o = 0), Nr.push({
            time: t,
            event: 22,
            data: {
                type: e,
                hash: n,
                x: a,
                y: r,
                reaction: i,
                context: o
            }
        }), D(e, a, r, t)
    }

    function Cr(t, e, n) {
        return "".concat(t, "=").concat(S(e, 0 === t.indexOf("data-") ? "data-" : t, n))
    }
    var Dr = [],
        Pr = 1,
        Rr = null;

    function Ar() {
        Dr = [],
            function(t) {
                var e = [t];
                for (; e.length > 0;) {
                    for (var n = null, a = null, r = null, i = e.shift(), o = i.firstChild, u = i.parentElement ? i.parentElement : i.parentNode ? i.parentNode : null; o;) e.push(o), o = o.nextSibling;
                    switch (i.nodeType) {
                        case Node.DOCUMENT_TYPE_NODE:
                            var c = i;
                            a = "*D", n = {
                                name: c.name,
                                publicId: c.publicId,
                                systemId: c.systemId
                            };
                            break;
                        case Node.TEXT_NODE:
                            r = i.nodeValue, a = Rr.get(u) ? "*T" : a;
                            break;
                        case Node.ELEMENT_NODE:
                            var s = i;
                            n = jr(s), a = ["NOSCRIPT", "SCRIPT", "STYLE"].indexOf(s.tagName) < 0 ? s.tagName : a
                    }
                    Yr(i, u, {
                        tag: a,
                        attributes: n,
                        value: r
                    })
                }
            }(document),
            function(t) {
                it(this, void 0, void 0, (function() {
                    var e, n, a, r, i, o, u, c, s, l, d, p, h;
                    return ot(this, (function(v) {
                        switch (e = f(), n = [e, t], t) {
                            case 8:
                                a = An, n.push(a.width), n.push(a.height), D(t, a.width, a.height), ei(n);
                                break;
                            case 43:
                                if ((r = Dr).length > 0) {
                                    for (i = 0, o = r; i < o.length; i++)
                                        for (u = o[i], c = u.metadata.privacy, s = u.data, l = 0, d = ["tag", "attributes", "value"]; l < d.length; l++)
                                            if (s[p = d[l]]) switch (p) {
                                                case "tag":
                                                    n.push(u.id), u.parent && n.push(u.parent), u.previous && n.push(u.previous), n.push(s[p]);
                                                    break;
                                                case "attributes":
                                                    for (h in s[p]) void 0 !== s[p][h] && n.push(Cr(h, s[p][h], c));
                                                    break;
                                                case "value":
                                                    n.push(S(s[p], s.tag, c))
                                            }
                                    ei(cn(n), !0)
                                }
                        }
                        return [2]
                    }))
                }))
            }(43)
    }

    function jr(t) {
        var e = {},
            n = t.attributes;
        if (n && n.length > 0)
            for (var a = 0; a < n.length; a++) e[n[a].name] = n[a].value;
        return e
    }

    function Yr(t, e, n) {
        if (t && n && n.tag) {
            var a = function(t) {
                    return null === t ? null : Rr.has(t) ? Rr.get(t) : (Rr.set(t, Pr), Pr++)
                }(t),
                r = e ? Rr.get(e) : null,
                i = t.previousSibling ? Rr.get(t.previousSibling) : null;
            Dr.push({
                id: a,
                parent: r,
                previous: i,
                children: [],
                data: n,
                selector: null,
                hash: null,
                region: null,
                metadata: {
                    active: !0,
                    suspend: !1,
                    privacy: 5,
                    position: null,
                    fraud: null,
                    size: null
                }
            })
        }
    }
    var Xr = [],
        Lr = !1,
        zr = null;

    function Wr(t) {
        Lr && "function" == typeof t && Xr.push(t)
    }

    function Hr(t) {
        if (Lr) {
            var e = t ? t.split(" ") : [""],
                n = e.length > 1 ? parseInt(e[1], 10) : null;
            n && zr.has(n) || function(t, e) {
                try {
                    var n = document.createElement("script");
                    n.src = t, n.async = !0, n.onload = function() {
                        e && (zr.add(e), A(zr))
                    }, n.onerror = function() {
                        Ro(new Error("".concat("MODULE", ": ").concat(t)))
                    }, document.head.appendChild(n)
                } catch (t) {}
            }(e[0], n)
        }
    }
    var qr, Ur, Fr, Vr, Br, Jr = Object.freeze({
            __proto__: null,
            event: Hr,
            register: Wr,
            start: function() {
                Lr = !0, zr = new Set
            },
            stop: function() {
                Xr.reverse().forEach((function(t) {
                    try {
                        t()
                    } catch (t) {}
                })), Xr = [], Lr = !1
            }
        }),
        Kr = 0,
        Gr = 0,
        Zr = null,
        Qr = 0,
        $r = !1;

    function ti() {
        Vr = !0, Kr = 0, Gr = 0, $r = !1, Qr = 0, qr = [], Ur = [], Fr = {}, Br = null
    }

    function ei(t, e) {
        if (void 0 === e && (e = !0), Vr) {
            var n = f(),
                a = t.length > 1 ? t[1] : null,
                r = JSON.stringify(t);
            switch (c.lean ? !$r && Gr + r.length > 10485760 && (pi(10, 0), $r = !0) : $r = !1, a) {
                case 5:
                    if ($r) break;
                    Kr += r.length;
                case 37:
                case 6:
                case 43:
                case 45:
                case 46:
                case 44:
                case 51:
                    if ($r) break;
                    Gr += r.length, qr.push(r);
                    break;
                default:
                    Ur.push(r)
            }
            q(25);
            var i = function() {
                var t = !1 === c.lean && Kr > 0 ? 100 : xo.sequence * c.delay;
                return "string" == typeof c.upload ? Math.max(Math.min(t, 3e4), 100) : c.delay
            }();
            n - Qr > 2 * i && (B(Zr), Zr = null), e && null === Zr && (25 !== a && Z(), Zr = V(ai, i), Qr = n, Li(Gr))
        }
    }

    function ni() {
        B(Zr), ai(!0), Kr = 0, Gr = 0, $r = !1, Qr = 0, qr = [], Ur = [], Fr = {}, Br = null, Vr = !1
    }

    function ai(t) {
        return void 0 === t && (t = !1), it(this, void 0, void 0, (function() {
            var e, n, a, r, i, o, u, s;
            return ot(this, (function(l) {
                switch (l.label) {
                    case 0:
                        return Vr ? (Zr = null, (e = !1 === c.lean && Gr > 0 && (Gr < 1048576 || xo.sequence > 0)) && F(1, 1), br(), function() {
                            if (xo) {
                                var t = [];
                                Mr = [];
                                for (var e = (xo.start || 0) + (xo.duration || 0), n = Math.max(e - 2e3, 0), a = 0, r = Nr; a < r.length; a++) {
                                    var i = r[a];
                                    i.time >= n && (i.time <= e && Mr.push(i), t.push(i))
                                }
                                Nr = t, _r(22)
                            }
                        }(), Ft(), function() {
                            for (var t = 0, e = hn; t < e.length; t++) {
                                var n = e[t],
                                    a = n == document ? -1 : Va(n);
                                yn(n, a in pn ? pn[a] : null)
                            }
                        }(), n = !0 === t, xo ? (a = JSON.stringify(Do(n)), r = "[".concat(Ur.join(), "]"), i = e ? "[".concat(qr.join(), "]") : "", n && i.length > 0 && a.length + r.length + i.length > 65536 && (i = ""), o = function(t) {
                            return t.p.length > 0 ? '{"e":'.concat(t.e, ',"a":').concat(t.a, ',"p":').concat(t.p, "}") : '{"e":'.concat(t.e, ',"a":').concat(t.a, "}")
                        }({
                            e: a,
                            a: r,
                            p: i
                        }), n ? (s = null, [3, 3]) : [3, 1]) : [2]) : [2];
                    case 1:
                        return [4, ct(o)];
                    case 2:
                        s = l.sent(), l.label = 3;
                    case 3:
                        return U(2, (u = s) ? u.length : o.length), ri(o, u, xo.sequence, n), Ur = [], e && (qr = [], Gr = 0, Kr = 0, $r = !1), [2]
                }
            }))
        }))
    }

    function ri(t, e, n, a) {
        if (void 0 === a && (a = !1), "string" == typeof c.upload) {
            var r = c.upload,
                i = !1;
            if (a && navigator && navigator.sendBeacon) try {
                (i = navigator.sendBeacon.bind(navigator)(r, t)) && oi(n)
            } catch (t) {}
            if (!1 === i) {
                n in Fr ? Fr[n].attempts++ : Fr[n] = {
                    data: t,
                    attempts: 1
                };
                var o = new XMLHttpRequest;
                o.open("POST", r, !0), o.timeout = 15e3, o.ontimeout = function() {
                    Ro(new Error("".concat("Timeout", " : ").concat(r)))
                }, null !== n && (o.onreadystatechange = function() {
                    Ao(ii)(o, n)
                }), o.withCredentials = !0, e ? (o.setRequestHeader("Accept", "application/x-clarity-gzip"), o.send(e)) : o.send(t)
            }
        } else if (c.upload) {
            (0, c.upload)(t), oi(n)
        }
    }

    function ii(t, e) {
        var n = Fr[e];
        t && 4 === t.readyState && n && ((t.status < 200 || t.status > 208) && n.attempts <= 1 ? t.status >= 400 && t.status < 500 ? zi(6) : (0 === t.status && (c.upload = c.fallback ? c.fallback : c.upload), Br = {
            sequence: e,
            attempts: n.attempts,
            status: t.status
        }, Yi(2), ri(n.data, null, e)) : (Br = {
            sequence: e,
            attempts: n.attempts,
            status: t.status
        }, n.attempts > 1 && Yi(2), 200 === t.status && t.responseText && function(t) {
            for (var e = t && t.length > 0 ? t.split("\n") : [], n = 0, a = e; n < a.length; n++) {
                var r = a[n],
                    i = r && r.length > 0 ? r.split(/ (.*)/) : [""];
                switch (i[0]) {
                    case "END":
                        zi(6);
                        break;
                    case "UPGRADE":
                        Ai("Auto");
                        break;
                    case "ACTION":
                        c.action && i.length > 1 && c.action(i[1]);
                        break;
                    case "EXTRACT":
                        i.length > 1 && Tt(i[1]);
                        break;
                    case "SIGNAL":
                        i.length > 1 && Wt(i[1]);
                        break;
                    case "MODULE":
                        i.length > 1 && Hr(i[1]);
                        break;
                    case "SNAPSHOT":
                        c.lean = !1, Ar()
                }
            }
        }(t.responseText), 0 === t.status && (ri(n.data, null, e, !0), zi(3)), t.status >= 200 && t.status <= 208 && oi(e), delete Fr[e]))
    }

    function oi(t) {
        1 === t && (Oo(), ko())
    }
    var ui, ci = {};

    function si(t) {
        var e = t.error || t;
        return e.message in ci || (ci[e.message] = 0), ci[e.message]++ >= 5 || e && e.message && (ui = {
            message: e.message,
            line: t.lineno,
            column: t.colno,
            stack: e.stack,
            source: t.filename
        }, li(31)), !0
    }

    function li(t) {
        return it(this, void 0, void 0, (function() {
            var e;
            return ot(this, (function(n) {
                switch (e = [f(), t], t) {
                    case 31:
                        e.push(ui.message), e.push(ui.line), e.push(ui.column), e.push(ui.stack), e.push(k(ui.source)), ei(e);
                        break;
                    case 33:
                        di && (e.push(di.code), e.push(di.name), e.push(di.message), e.push(di.stack), e.push(di.severity), ei(e, !1));
                        break;
                    case 41:
                        Vt && (e.push(Vt.id), e.push(Vt.target), e.push(Vt.checksum), ei(e, !1))
                }
                return [2]
            }))
        }))
    }
    var di, fi = {};

    function pi(t, e, n, a, r) {
        void 0 === n && (n = null), void 0 === a && (a = null), void 0 === r && (r = null);
        var i = n ? "".concat(n, "|").concat(a) : "";
        t in fi && fi[t].indexOf(i) >= 0 || (di = {
            code: t,
            name: n,
            message: a,
            stack: r,
            severity: e
        }, t in fi ? fi[t].push(i) : fi[t] = [i], li(33))
    }
    var hi = 5e3,
        vi = {},
        gi = [],
        mi = null,
        yi = null,
        bi = null;

    function wi() {
        vi = {}, gi = [], mi = null, yi = null
    }

    function Si(t, e) {
        return void 0 === e && (e = 0), it(this, void 0, void 0, (function() {
            var n, a, r;
            return ot(this, (function(i) {
                for (n = 0, a = gi; n < a.length; n++)
                    if (a[n].task === t) return [2];
                return r = new Promise((function(n) {
                    gi[1 === e ? "unshift" : "push"]({
                        task: t,
                        resolve: n,
                        id: go()
                    })
                })), null === mi && null === yi && ki(), [2, r]
            }))
        }))
    }

    function ki() {
        var t = gi.shift();
        t && (mi = t, t.task().then((function() {
            t.id === go() && (t.resolve(), mi = null, ki())
        })).catch((function(e) {
            t.id === go() && (e && pi(0, 1, e.name, e.message, e.stack), mi = null, ki())
        })))
    }

    function Oi(t) {
        var e = Ni(t);
        return e in vi ? performance.now() - vi[e].start > vi[e].yield ? 0 : 1 : 2
    }

    function Ei(t) {
        vi[Ni(t)] = {
            start: performance.now(),
            calls: 0,
            yield: 30
        }
    }

    function Ti(t) {
        var e = performance.now(),
            n = Ni(t),
            a = e - vi[n].start;
        U(t.cost, a), q(5), vi[n].calls > 0 && U(4, a)
    }

    function _i(t) {
        var e;
        return it(this, void 0, void 0, (function() {
            var n, a;
            return ot(this, (function(r) {
                switch (r.label) {
                    case 0:
                        return (n = Ni(t)) in vi ? (Ti(t), a = vi[n], [4, Mi()]) : [3, 2];
                    case 1:
                        a.yield = (null === (e = r.sent()) || void 0 === e ? void 0 : e.timeRemaining()) || 30,
                            function(t) {
                                var e = Ni(t);
                                if (vi && vi[e]) {
                                    var n = vi[e].calls,
                                        a = vi[e].yield;
                                    Ei(t), vi[e].calls = n + 1, vi[e].yield = a
                                }
                            }(t), r.label = 2;
                    case 2:
                        return [2, n in vi ? 1 : 2]
                }
            }))
        }))
    }

    function Ni(t) {
        return "".concat(t.id, ".").concat(t.cost)
    }

    function Mi() {
        return it(this, void 0, void 0, (function() {
            return ot(this, (function(t) {
                switch (t.label) {
                    case 0:
                        return yi ? [4, yi] : [3, 2];
                    case 1:
                        t.sent(), t.label = 2;
                    case 2:
                        return [2, new Promise((function(t) {
                            xi(t, {
                                timeout: hi
                            })
                        }))]
                }
            }))
        }))
    }
    var xi = window.requestIdleCallback || function(t, e) {
        var n = performance.now(),
            a = new MessageChannel,
            r = a.port1,
            i = a.port2;
        r.onmessage = function(a) {
            var r = performance.now(),
                o = r - n,
                u = r - a.data;
            if (u > 30 && o < e.timeout) requestAnimationFrame((function() {
                i.postMessage(r)
            }));
            else {
                var c = o > e.timeout;
                t({
                    didTimeout: c,
                    timeRemaining: function() {
                        return c ? 30 : Math.max(0, 30 - u)
                    }
                })
            }
        }, requestAnimationFrame((function() {
            i.postMessage(performance.now())
        }))
    };

    function Ii() {
        Si(Ci, 1).then((function() {
            Ao(Fn)(), Ao(br)(), Ao(ze)()
        }))
    }

    function Ci() {
        return it(this, void 0, void 0, (function() {
            var t, e;
            return ot(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return t = f(), Ei(e = {
                            id: go(),
                            cost: 3
                        }), [4, Vn(document, e, 0, t)];
                    case 1:
                        return n.sent(), yn(document, t), [4, zn(5, e, t)];
                    case 2:
                        return n.sent(), Ti(e), [2]
                }
            }))
        }))
    }
    var Di, Pi = null;

    function Ri() {
        !c.lean && c.upgrade && c.upgrade("Config"), Pi = null
    }

    function Ai(t) {
        $o() && c.lean && (c.lean = !1, Pi = {
            key: t
        }, ko(), Oo(), c.upgrade && c.upgrade(t), Yi(3), c.lite && (Ii(), mn()))
    }

    function ji() {
        Pi = null
    }

    function Yi(t) {
        var e = [f(), t];
        switch (t) {
            case 4:
                var n = M;
                n && n.data && ((e = [n.time, n.event]).push(n.data.visible), e.push(n.data.docWidth), e.push(n.data.docHeight), e.push(n.data.screenWidth), e.push(n.data.screenHeight), e.push(n.data.scrollX), e.push(n.data.scrollY), e.push(n.data.pointerX), e.push(n.data.pointerY), e.push(n.data.activityTime), e.push(n.data.scrollTime), e.push(n.data.pointerTime), e.push(n.data.moveX), e.push(n.data.moveY), e.push(n.data.moveTime), e.push(n.data.downX), e.push(n.data.downY), e.push(n.data.downTime), e.push(n.data.upX), e.push(n.data.upY), e.push(n.data.upTime), e.push(n.data.pointerPrevX), e.push(n.data.pointerPrevY), e.push(n.data.pointerPrevTime), e.push(n.data.modules), ei(e, !1)), C();
                break;
            case 25:
                e.push(z.gap), ei(e);
                break;
            case 35:
                e.push(Di.check), ei(e, !1);
                break;
            case 3:
                e.push(Pi.key), ei(e);
                break;
            case 2:
                e.push(Br.sequence), e.push(Br.attempts), e.push(Br.status), ei(e, !1);
                break;
            case 24:
                X.key && e.push(X.key), e.push(X.value), ei(e);
                break;
            case 34:
                var a = Object.keys(lt);
                if (a.length > 0) {
                    for (var r = 0, i = a; r < i.length; r++) {
                        var o = i[r];
                        e.push(o), e.push(lt[o])
                    }
                    vt(), ei(e, !1)
                }
                break;
            case 0:
                var u = Object.keys(H);
                if (u.length > 0) {
                    for (var c = 0, s = u; c < s.length; c++) {
                        var l = s[c],
                            d = parseInt(l, 10);
                        e.push(d), e.push(Math.round(H[l]))
                    }
                    H = {}, ei(e, !1)
                }
                break;
            case 1:
                var p = Object.keys(Ui);
                if (p.length > 0) {
                    for (var h = 0, v = p; h < v.length; h++) {
                        var g = v[h];
                        d = parseInt(g, 10);
                        e.push(d), e.push(Ui[g])
                    }
                    Gi(), ei(e, !1)
                }
                break;
            case 36:
                var m = Object.keys(tt);
                if (m.length > 0) {
                    for (var y = 0, b = m; y < b.length; y++) {
                        var w = b[y];
                        d = parseInt(w, 10);
                        e.push(d), e.push([].concat.apply([], tt[w]))
                    }
                    at(), ei(e, !1)
                }
                break;
            case 40:
                wt.forEach((function(t) {
                    e.push(t);
                    var n = [];
                    for (var a in bt[t]) {
                        var r = parseInt(a, 10);
                        n.push(r), n.push(bt[t][a])
                    }
                    e.push(n)
                })), Mt(), ei(e, !1);
                break;
            case 47:
                e.push(Zi.source), e.push(Zi.ad_Storage), e.push(Zi.analytics_Storage), ei(e, !1)
        }
    }

    function Xi() {
        Di = {
            check: 0
        }
    }

    function Li(t) {
        if (0 === Di.check) {
            var e = Di.check;
            e = xo.sequence >= 128 ? 1 : e, e = xo.pageNum >= 128 ? 7 : e, e = f() > 72e5 ? 2 : e, (e = t > 10485760 ? 2 : e) !== Di.check && zi(e)
        }
    }

    function zi(t) {
        Di.check = t, 5 !== t && (So(), Eu())
    }

    function Wi() {
        0 !== Di.check && Yi(35)
    }

    function Hi() {
        Di = null
    }
    var qi = null,
        Ui = null,
        Fi = !1;

    function Vi() {
        qi = {}, Ui = {}, Fi = !1
    }

    function Bi() {
        qi = {}, Ui = {}, Fi = !1
    }

    function Ji(t, e) {
        if (e && (e = "".concat(e), t in qi || (qi[t] = []), qi[t].indexOf(e) < 0)) {
            if (qi[t].length > 128) return void(Fi || (Fi = !0, zi(5)));
            qi[t].push(e), t in Ui || (Ui[t] = []), Ui[t].push(e)
        }
    }

    function Ki() {
        Yi(1)
    }

    function Gi() {
        Ui = {}, Fi = !1
    }
    var Zi = null,
        Qi = !0;

    function $i() {
        var t, e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
        Qi = !0, (null == e ? void 0 : e.addListener) && e.addListener(["ad_storage", "analytics_storage"], eo)
    }

    function to() {
        Qi = !0
    }

    function eo() {
        var t, e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
        if (null == e ? void 0 : e.getConsentState) {
            var n = e.getConsentState("analytics_storage");
            yo(function(t) {
                var e = {
                    source: 2,
                    ad_Storage: 1 === t.ad_Storage ? "granted" : "denied",
                    analytics_Storage: 1 === t.analytics_Storage ? "granted" : "denied"
                };
                return e
            }({
                ad_Storage: e.getConsentState("ad_storage"),
                analytics_Storage: n
            }))
        }
    }

    function no(t) {
        ro(t.analytics_Storage ? 1 : 0), Zi = t
    }

    function ao() {
        ro(2)
    }

    function ro(t) {
        Ji(36, t.toString())
    }

    function io(t) {
        Zi = t, Yi(47)
    }

    function oo() {
        var t;
        if (Qi && (Yi(47), Qi = !1, !c.track)) {
            var e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
            (null == e ? void 0 : e.usedUpdate) && eo()
        }
    }
    var uo = null,
        co = [],
        so = 0,
        lo = null,
        fo = {
            source: 7,
            ad_Storage: "denied",
            analytics_Storage: "denied"
        };

    function po() {
        var t, e, n, a = navigator && "userAgent" in navigator ? navigator.userAgent : "",
            r = null !== (n = "undefined" != typeof Intl && (null === (e = null === (t = null === Intl || void 0 === Intl ? void 0 : Intl.DateTimeFormat()) || void 0 === t ? void 0 : t.resolvedOptions()) || void 0 === e ? void 0 : e.timeZone)) && void 0 !== n ? n : "",
            i = (new Date).getTimezoneOffset().toString(),
            o = window.location.ancestorOrigins ? Array.from(window.location.ancestorOrigins).toString() : "",
            u = document && document.title ? document.title : "";
        so = a.indexOf("Electron") > 0 ? 1 : 0;
        var s = function() {
                var t = {
                        session: To(),
                        ts: Math.round(Date.now()),
                        count: 1,
                        upgrade: null,
                        upload: ""
                    },
                    e = Xt("_clsk", !c.includeSubdomains);
                if (e) {
                    var n = e.includes("^") ? e.split("^") : e.split("|");
                    n.length >= 5 && t.ts - _o(n[1]) < 18e5 && (t.session = n[0], t.count = _o(n[2]) + 1, t.upgrade = _o(n[3]), t.upload = n.length >= 6 ? "".concat("https://").concat(n[5], "/").concat(n[4]) : "".concat("https://").concat(n[4]))
                }
                return t
            }(),
            l = No(),
            d = c.projectId || h(location.host);
        uo = {
            projectId: d,
            userId: l.id,
            sessionId: s.session,
            pageNum: s.count
        }, c.lean = c.track && null !== s.upgrade ? 0 === s.upgrade : c.lean, c.upload = c.track && "string" == typeof c.upload && s.upload && s.upload.length > "https://".length ? s.upload : c.upload, Ji(0, a), Ji(3, u), Ji(1, k(location.href, !!so)), Ji(2, document.referrer), Ji(15, function() {
            var t = To();
            if (c.track && Rt(window, "sessionStorage")) {
                var e = sessionStorage.getItem("_cltk");
                t = e || t, sessionStorage.setItem("_cltk", t)
            }
            return t
        }()), Ji(16, document.documentElement.lang), Ji(17, document.dir), Ji(26, "".concat(window.devicePixelRatio)), Ji(28, l.dob.toString()), Ji(29, l.version.toString()), Ji(33, o), Ji(34, r), Ji(35, i), F(0, s.ts), F(1, 0), F(35, so);
        var f, p = null === window || void 0 === window ? void 0 : window.Zone;
        p && "__symbol__" in p && F(39, 1), navigator && (Ji(9, navigator.language), F(33, navigator.hardwareConcurrency), F(32, navigator.maxTouchPoints), F(34, Math.round(navigator.deviceMemory)), (f = navigator.userAgentData) && f.getHighEntropyValues ? f.getHighEntropyValues(["model", "platform", "platformVersion", "uaFullVersion"]).then((function(t) {
            var e;
            Ji(22, t.platform), Ji(23, t.platformVersion), null === (e = t.brands) || void 0 === e || e.forEach((function(t) {
                Ji(24, t.name + "~" + t.version)
            })), Ji(25, t.model), F(27, t.mobile ? 1 : 0)
        })) : Ji(22, navigator.platform)), screen && (F(14, Math.round(screen.width)), F(15, Math.round(screen.height)), F(16, Math.round(screen.colorDepth)));
        for (var v = 0, g = c.cookies; v < g.length; v++) {
            var m = g[v],
                y = Xt(m);
            y && dt(m, y)
        }
        null === lo && (lo = {
            source: l.consent ? 6 : 0,
            ad_Storage: c.track ? "granted" : "denied",
            analytics_Storage: c.track ? "granted" : "denied"
        }), no(bo(lo)), Eo(l)
    }

    function ho() {
        uo = null, co.forEach((function(t) {
            t.called = !1
        }))
    }

    function vo(t, e, n, a) {
        void 0 === e && (e = !0), void 0 === n && (n = !1), void 0 === a && (a = !1);
        var r = c.lean ? 0 : 1,
            i = !1;
        uo && (r || !1 === e) && (t(uo, !c.lean, a ? lo : void 0), i = !0), !n && i || co.push({
            callback: t,
            wait: e,
            recall: n,
            called: i,
            consentInfo: a
        })
    }

    function go() {
        return uo ? [uo.userId, uo.sessionId, uo.pageNum].join(".") : ""
    }

    function mo(t) {
        void 0 === t && (t = !0), t ? (yo({
            source: 4,
            ad_Storage: "granted",
            analytics_Storage: "granted"
        }), ao()) : yo({
            source: 4,
            ad_Storage: "denied",
            analytics_Storage: "denied"
        })
    }

    function yo(t, e) {
        var n;
        void 0 === t && (t = fo), void 0 === e && (e = 5);
        var a = {
            source: null !== (n = t.source) && void 0 !== n ? n : e,
            ad_Storage: wo(t.ad_Storage, null == lo ? void 0 : lo.ad_Storage),
            analytics_Storage: wo(t.analytics_Storage, null == lo ? void 0 : lo.analytics_Storage)
        };
        if (lo && a.ad_Storage === lo.ad_Storage && a.analytics_Storage === lo.analytics_Storage) return lo.source = a.source, io(bo(lo)), void ao();
        lo = a, ko(!0);
        var r = bo(lo);
        if (!r.analytics_Storage && c.track) return c.track = !1, So(!0), Eu(), void window.setTimeout(Ou, 250);
        $o() && r.analytics_Storage && (c.track = !0, Eo(No(), 1), Oo()), io(r), ao()
    }

    function bo(t) {
        var e;
        return {
            source: null !== (e = t.source) && void 0 !== e ? e : 0,
            ad_Storage: "granted" === t.ad_Storage ? 1 : 0,
            analytics_Storage: "granted" === t.analytics_Storage ? 1 : 0
        }
    }

    function wo(t, e) {
        return void 0 === e && (e = "denied"), "string" == typeof t ? t.toLowerCase() : e
    }

    function So(t) {
        void 0 === t && (t = !1), Lt("_clsk", "", -Number.MAX_VALUE), t && Lt("_clck", "", -Number.MAX_VALUE)
    }

    function ko(t) {
        void 0 === t && (t = !1),
            function(t, e) {
                void 0 === e && (e = !1);
                if (co.length > 0)
                    for (var n = 0; n < co.length; n++) {
                        var a = co[n];
                        a.callback && (!a.called && !e || a.consentInfo && e) && (!a.wait || t) && (a.callback(uo, !c.lean, a.consentInfo ? lo : void 0), a.called = !0, a.recall || (co.splice(n, 1), n--))
                    }
            }(c.lean ? 0 : 1, t)
    }

    function Oo() {
        if (uo && c.track) {
            var t = Math.round(Date.now()),
                e = c.upload && "string" == typeof c.upload ? c.upload.replace("https://", "") : "",
                n = c.lean ? 0 : 1;
            Lt("_clsk", [uo.sessionId, t, uo.pageNum, n, e].join(Yt), 1)
        }
    }

    function Eo(t, e) {
        void 0 === e && (e = null), e = null === e ? t.consent : e;
        var n = Math.ceil((Date.now() + 31536e6) / 864e5),
            a = 0 === t.dob ? null === c.dob ? 0 : c.dob : t.dob;
        (null === t.expiry || Math.abs(n - t.expiry) >= 1 || t.consent !== e || t.dob !== a) && Lt("_clck", [uo.userId, 2, n.toString(36), e, a].join(Yt), 365)
    }

    function To() {
        var t = Math.floor(Math.random() * Math.pow(2, 32));
        return window && window.crypto && window.crypto.getRandomValues && Uint32Array && (t = window.crypto.getRandomValues(new Uint32Array(1))[0]), t.toString(36)
    }

    function _o(t, e) {
        return void 0 === e && (e = 10), parseInt(t, e)
    }

    function No() {
        var t = {
                id: To(),
                version: 0,
                expiry: null,
                consent: 0,
                dob: 0
            },
            e = Xt("_clck", !c.includeSubdomains);
        if (e && e.length > 0) {
            var n = e.includes("^") ? e.split("^") : e.split("|");
            n.length > 1 && (t.version = _o(n[1])), n.length > 2 && (t.expiry = _o(n[2], 36)), n.length > 3 && 1 === _o(n[3]) && (t.consent = 1), n.length > 4 && _o(n[1]) > 1 && (t.dob = _o(n[4])), c.track = c.track || 1 === t.consent, t.id = c.track ? n[0] : t.id
        }
        return t
    }
    var Mo, xo = null;

    function Io() {
        var t = uo;
        xo = {
            version: p,
            sequence: 0,
            start: 0,
            duration: 0,
            projectId: t.projectId,
            userId: t.userId,
            sessionId: t.sessionId,
            pageNum: t.pageNum,
            upload: 0,
            end: 0,
            applicationPlatform: 0,
            url: ""
        }
    }

    function Co() {
        xo = null
    }

    function Do(t) {
        return xo.start = xo.start + xo.duration, xo.duration = f() - xo.start, xo.sequence++, xo.upload = t && "sendBeacon" in navigator ? 1 : 0, xo.end = t ? 1 : 0, xo.applicationPlatform = 0, xo.url = k(location.href, !1, !0), [xo.version, xo.sequence, xo.start, xo.duration, xo.projectId, xo.userId, xo.sessionId, xo.pageNum, xo.upload, xo.end, xo.applicationPlatform, xo.url]
    }

    function Po() {
        Mo = []
    }

    function Ro(t) {
        if (Mo && -1 === Mo.indexOf(t.message)) {
            var e = c.report;
            if (e && e.length > 0 && xo) {
                var n = {
                    v: xo.version,
                    p: xo.projectId,
                    u: xo.userId,
                    s: xo.sessionId,
                    n: xo.pageNum
                };
                t.message && (n.m = t.message), t.stack && (n.e = t.stack);
                var a = new XMLHttpRequest;
                a.open("POST", e, !0), a.send(JSON.stringify(n)), Mo.push(t.message)
            }
        }
        return t
    }

    function Ao(t) {
        return function() {
            var e = performance.now();
            try {
                t.apply(this, arguments)
            } catch (t) {
                throw Ro(t)
            }
            var n = performance.now() - e;
            U(4, n), n > 30 && (q(7), F(6, n), t.dn && pi(9, 0, "".concat(t.dn, "-").concat(n)))
        }
    }
    var jo = new Map;

    function Yo(t, e, n, a, r) {
        void 0 === a && (a = !1), void 0 === r && (r = !0), n = Ao(n);
        try {
            t[s("addEventListener")](e, n, {
                capture: a,
                passive: r
            }), zo(t) || jo.set(t, []), jo.get(t).push({
                event: e,
                listener: n,
                options: {
                    capture: a,
                    passive: r
                }
            })
        } catch (t) {}
    }

    function Xo() {
        jo.forEach((function(t, e) {
            Wo(t, e)
        })), jo = new Map
    }

    function Lo(t) {
        zo(t) && Wo(jo.get(t), t)
    }

    function zo(t) {
        return jo.has(t)
    }

    function Wo(t, e) {
        t.forEach((function(t) {
            try {
                e[s("removeEventListener")](t.event, t.listener, {
                    capture: t.options.capture,
                    passive: t.options.passive
                })
            } catch (t) {}
        })), jo.delete(e)
    }
    var Ho = null,
        qo = null,
        Uo = null,
        Fo = 0;

    function Vo() {
        return !(Fo++ > 20) || (pi(4, 0), !1)
    }

    function Bo() {
        Fo = 0, Uo !== Ko() && (Eu(), window.setTimeout(Jo, 250))
    }

    function Jo() {
        Ou(), F(29, 1)
    }

    function Ko() {
        return location.href ? location.href.replace(location.hash, "") : location.href
    }
    var Go = !1;

    function Zo() {
        Go = !0, l = d(), wi(), Xo(), Po(), Uo = Ko(), Fo = 0, Yo(window, "popstate", Bo), null === Ho && (Ho = history.pushState, history.pushState = function() {
            Ho.apply(this, arguments), $o() && Vo() && Bo()
        }), null === qo && (qo = history.replaceState, history.replaceState = function() {
            qo.apply(this, arguments), $o() && Vo() && Bo()
        })
    }

    function Qo() {
        Uo = null, Fo = 0, Po(), Xo(), wi(), l = 0, Go = !1
    }

    function $o() {
        return Go
    }

    function tu() {
        Ou(), L("clarity", "restart")
    }
    var eu = Object.freeze({
        __proto__: null,
        start: function() {
            ! function() {
                Bt = [], F(26, navigator.webdriver ? 1 : 0);
                try {
                    F(31, window.top == window.self || window.top == window ? 1 : 2)
                } catch (t) {
                    F(31, 0)
                }
            }(), Yo(window, "error", si), ci = {}, fi = {}
        },
        stop: function() {
            fi = {}
        }
    });
    var nu = Object.freeze({
        __proto__: null,
        hashText: er,
        start: function() {
            var t;
            Un(), Fn(), Or(), gr = null, fr = new WeakMap, pr = {}, hr = [], vr = !!window.IntersectionObserver, Ha(), c.delayDom ? Yo(window, "load", (function() {
                    aa()
                })) : aa(), Ii(), mn(),
                function() {
                    if (window.Animation && window.Animation.prototype && window.KeyframeEffect && window.KeyframeEffect.prototype && window.KeyframeEffect.prototype.getKeyframes && window.KeyframeEffect.prototype.getTiming && (Cn(), Pn(On, "play"), Pn(En, "pause"), Pn(Tn, "commitStyles"), Pn(_n, "cancel"), Pn(Nn, "finish"), null === kn && (kn = Element.prototype.animate, Element.prototype.animate = function() {
                            var t = kn.apply(this, arguments);
                            return Rn(t, "play"), t
                        }), document.getAnimations))
                        for (var t = 0, e = document.getAnimations(); t < e.length; t++) {
                            var n = e[t];
                            "finished" === n.playState ? Rn(n, "finish") : "paused" === n.playState || "idle" === n.playState ? Rn(n, "pause") : "running" === n.playState && Rn(n, "play")
                        }
                }(), window.clarityOverrides = window.clarityOverrides || {}, (null === (t = window.customElements) || void 0 === t ? void 0 : t.define) && !window.clarityOverrides.define && (window.clarityOverrides.define = window.customElements.define, window.customElements.define = function() {
                    return $o() && Xn(arguments[0]), window.clarityOverrides.define.apply(this, arguments)
                })
        },
        stop: function() {
            Or(), fr = null, pr = {}, hr = [], gr && (gr.disconnect(), gr = null), vr = !1, qa(),
                function() {
                    for (var t = 0, e = Array.from(Bn); t < e.length; t++) {
                        var n = e[t];
                        n && n.disconnect()
                    }
                    Bn = new Set, ta = {}, Jn = [], Kn = {}, Gn = [], $n = 0, Zn = null, ea = new WeakMap
                }(), Un(), fn = {}, pn = {}, hn = [], vn = [], bn(), Cn(), Ln(), Yn.clear()
        }
    });
    var au = null;

    function ru() {
        au = null
    }

    function iu(t) {
        au = {
                fetchStart: Math.round(t.fetchStart),
                connectStart: Math.round(t.connectStart),
                connectEnd: Math.round(t.connectEnd),
                requestStart: Math.round(t.requestStart),
                responseStart: Math.round(t.responseStart),
                responseEnd: Math.round(t.responseEnd),
                domInteractive: Math.round(t.domInteractive),
                domComplete: Math.round(t.domComplete),
                loadEventStart: Math.round(t.loadEventStart),
                loadEventEnd: Math.round(t.loadEventEnd),
                redirectCount: Math.round(t.redirectCount),
                size: t.transferSize ? t.transferSize : 0,
                type: t.type,
                protocol: t.nextHopProtocol,
                encodedSize: t.encodedBodySize ? t.encodedBodySize : 0,
                decodedSize: t.decodedBodySize ? t.decodedBodySize : 0
            },
            function(t) {
                it(this, void 0, void 0, (function() {
                    var e, n;
                    return ot(this, (function(a) {
                        return e = f(), n = [e, t], 29 === t && (n.push(au.fetchStart), n.push(au.connectStart), n.push(au.connectEnd), n.push(au.requestStart), n.push(au.responseStart), n.push(au.responseEnd), n.push(au.domInteractive), n.push(au.domComplete), n.push(au.loadEventStart), n.push(au.loadEventEnd), n.push(au.redirectCount), n.push(au.size), n.push(au.type), n.push(au.protocol), n.push(au.encodedSize), n.push(au.decodedSize), ru(), ei(n)), [2]
                    }))
                }))
            }(29)
    }
    var ou, uu = 0,
        cu = 1 / 0,
        su = 0,
        lu = 0,
        du = [],
        fu = new Map,
        pu = function() {
            return uu || 0
        },
        hu = function() {
            if (!du.length) return -1;
            var t = Math.min(du.length - 1, Math.floor((pu() - lu) / 50));
            return du[t].latency
        },
        vu = function() {
            lu = pu(), du.length = 0, fu.clear()
        },
        gu = function(t) {
            if (t.interactionId && !(t.duration < 40)) {
                ! function(t) {
                    "interactionCount" in performance ? uu = performance.interactionCount : t.interactionId && (cu = Math.min(cu, t.interactionId), su = Math.max(su, t.interactionId), uu = su ? (su - cu) / 7 + 1 : 0)
                }(t);
                var e = du[du.length - 1],
                    n = fu.get(t.interactionId);
                if (n || du.length < 10 || t.duration > (null == e ? void 0 : e.latency)) {
                    if (n) t.duration > n.latency && (n.latency = t.duration);
                    else {
                        var a = {
                            id: t.interactionId,
                            latency: t.duration
                        };
                        fu.set(a.id, a), du.push(a)
                    }
                    du.sort((function(t, e) {
                        return e.latency - t.latency
                    })), du.length > 10 && du.splice(10).forEach((function(t) {
                        return fu.delete(t.id)
                    }))
                }
            }
        },
        mu = ["navigation", "resource", "longtask", "first-input", "layout-shift", "largest-contentful-paint", "event"];

    function yu() {
        try {
            ou && ou.disconnect(), ou = new PerformanceObserver(Ao(bu));
            for (var t = 0, e = mu; t < e.length; t++) {
                var n = e[t];
                PerformanceObserver.supportedEntryTypes.indexOf(n) >= 0 && ("layout-shift" === n && U(9, 0), ou.observe({
                    type: n,
                    buffered: !0
                }))
            }
        } catch (t) {
            pi(3, 1)
        }
    }

    function bu(t) {
        ! function(t) {
            for (var e = (!("visibilityState" in document) || "visible" === document.visibilityState), n = 0; n < t.length; n++) {
                var a = t[n];
                switch (a.entryType) {
                    case "navigation":
                        iu(a);
                        break;
                    case "resource":
                        var r = a.name;
                        Ji(4, Su(r)), r !== c.upload && r !== c.fallback || F(28, a.duration);
                        break;
                    case "longtask":
                        q(7);
                        break;
                    case "first-input":
                        e && F(10, a.processingStart - a.startTime);
                        break;
                    case "event":
                        e && "PerformanceEventTiming" in window && "interactionId" in PerformanceEventTiming.prototype && (gu(a), Ji(37, hu().toString()));
                        break;
                    case "layout-shift":
                        e && !a.hadRecentInput && U(9, 1e3 * a.value);
                        break;
                    case "largest-contentful-paint":
                        e && F(8, a.startTime)
                }
            }
        }(t.getEntries())
    }
    var wu = null;

    function Su(t) {
        return wu || (wu = document.createElement("a")), wu.href = t, wu.host
    }
    var ku = [eu, nu, un, Object.freeze({
        __proto__: null,
        start: function() {
            ru(),
                function() {
                    navigator && navigator.connection && Ji(27, navigator.connection.effectiveType), window.PerformanceObserver && PerformanceObserver.supportedEntryTypes ? "complete" !== document.readyState ? Yo(window, "load", V.bind(this, yu, 0)) : yu() : pi(3, 0)
                }()
        },
        stop: function() {
            ou && ou.disconnect(), ou = null, vu(), wu = null, ru()
        }
    }), Jr];

    function Ou(t) {
        void 0 === t && (t = null),
            function() {
                try {
                    var t = navigator && "globalPrivacyControl" in navigator && 1 == navigator.globalPrivacyControl;
                    return !1 === Go && "undefined" != typeof Promise && window.MutationObserver && document.createTreeWalker && "now" in Date && "now" in performance && "undefined" != typeof WeakMap && !t
                } catch (t) {
                    return !1
                }
            }() && (! function(t) {
                if (null === t || Go) return !1;
                for (var e in t) e in c && (c[e] = t[e])
            }(t), Zo(), qt(), ku.forEach((function(t) {
                return Ao(t.start)()
            })), null === t && Mu())
    }

    function Eu() {
        $o() && (ku.slice().reverse().forEach((function(t) {
            return Ao(t.stop)()
        })), Ut(), Qo(), void 0 !== _u && (_u[Nu] = function() {
            (_u[Nu].q = _u[Nu].q || []).push(arguments), "start" === arguments[0] && _u[Nu].q.unshift(_u[Nu].q.pop()) && Mu()
        }))
    }
    var Tu = Object.freeze({
            __proto__: null,
            consent: mo,
            consentv2: yo,
            dlog: Ji,
            event: L,
            hashText: er,
            identify: ft,
            maxMetric: F,
            measure: Ao,
            metadata: vo,
            pause: function() {
                $o() && (L("clarity", "pause"), null === yi && (yi = new Promise((function(t) {
                    bi = t
                }))))
            },
            queue: ei,
            register: Wr,
            resume: function() {
                $o() && (yi && (bi(), yi = null, null === mi && ki()), L("clarity", "resume"))
            },
            schedule: Si,
            set: dt,
            signal: function(t) {
                zt = t
            },
            start: Ou,
            stop: Eu,
            time: f,
            upgrade: Ai,
            version: p
        }),
        _u = window,
        Nu = "clarity";

    function Mu() {
        if (void 0 !== _u) {
            if (_u[Nu] && _u[Nu].v) return console.warn("Error CL001: Multiple Clarity tags detected.");
            var t = _u[Nu] && _u[Nu].q || [];
            for (_u[Nu] = function(t) {
                    for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
                    return Tu[t].apply(Tu, e)
                }, _u[Nu].v = p; t.length > 0;) _u[Nu].apply(_u, t.shift())
        }
    }
    Mu()
}();