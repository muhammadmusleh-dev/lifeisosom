"use strict";
(globalThis.zipifyCartJsonp = globalThis.zipifyCartJsonp || []).push([
    ["516"], {
        8341(t, e, n) {
            function r() {
                return "undefined" != typeof __SENTRY_NO_DEBUG__ && !__SENTRY_BROWSER_BUNDLE__
            }

            function o() {
                return "undefined" != typeof __SENTRY_BROWSER_BUNDLE__ && !!__SENTRY_BROWSER_BUNDLE__
            }
            n.d(e, {
                Z: () => o,
                a: () => r
            })
        },
        6475(t, e, n) {
            n.d(e, {
                V: () => i
            });
            var r = n(6284),
                o = {};

            function i() {
                return (0, r.wD)() ? n.g : "undefined" != typeof window ? window : "undefined" != typeof self ? self : o
            }
        },
        6284(t, e, n) {
            n.d(e, {
                fj: () => i,
                wD: () => o
            });
            var r = n(8341);

            function o() {
                return !(0, r.Z)() && "[object process]" === Object.prototype.toString.call("undefined" != typeof process ? process : 0)
            }

            function i(t, e) {
                return t.require(e)
            }
            t = n.hmd(t)
        },
        9297(t, e, n) {
            n.d(e, {
                lu: () => u,
                zf: () => c
            });
            var r = n(6475),
                o = n(6284);
            t = n.hmd(t);
            var i = {
                    nowSeconds: function() {
                        return Date.now() / 1e3
                    }
                },
                s = (0, o.wD)() ? function() {
                    try {
                        return (0, o.fj)(t, "perf_hooks").performance
                    } catch (t) {
                        return
                    }
                }() : function() {
                    var t = (0, r.V)().performance;
                    if (t && t.now) return {
                        now: function() {
                            return t.now()
                        },
                        timeOrigin: Date.now() - t.now()
                    }
                }(),
                a = void 0 === s ? i : {
                    nowSeconds: function() {
                        return (s.timeOrigin + s.now()) / 1e3
                    }
                },
                u = i.nowSeconds.bind(i),
                c = a.nowSeconds.bind(a);
            ! function() {
                var t = (0, r.V)().performance;
                if (t && t.now) {
                    var e = t.now(),
                        n = Date.now(),
                        o = t.timeOrigin ? Math.abs(t.timeOrigin + e - n) : 36e5,
                        i = t.timing && t.timing.navigationStart,
                        s = "number" == typeof i ? Math.abs(i + e - n) : 36e5;
                    (o < 36e5 || s < 36e5) && o <= s && t.timeOrigin
                }
            }()
        },
        8359(t, e, n) {
            n.d(e, {
                BrowserClient: () => eD,
                Hub: () => t_
            });
            var r, o, i, s, a, u, c, p = {};
            n.r(p), n.d(p, {
                FunctionToString: () => eL,
                InboundFilters: () => eP
            });
            var f = {};
            n.r(f), n.d(f, {
                Breadcrumbs: () => eO,
                Dedupe: () => e$,
                GlobalHandlers: () => eU,
                LinkedErrors: () => eW,
                TryCatch: () => eV,
                UserAgent: () => eX
            });
            var l = function(t, e) {
                return (l = Object.setPrototypeOf || ({
                    __proto__: []
                }) instanceof Array && function(t, e) {
                    t.__proto__ = e
                } || function(t, e) {
                    for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
                })(t, e)
            };

            function h(t, e) {
                function n() {
                    this.constructor = t
                }
                l(t, e), t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, new n)
            }
            var d = function() {
                return (d = Object.assign || function(t) {
                    for (var e, n = 1, r = arguments.length; n < r; n++)
                        for (var o in e = arguments[n]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };

            function v(t) {
                var e = "function" == typeof Symbol && Symbol.iterator,
                    n = e && t[e],
                    r = 0;
                if (n) return n.call(t);
                if (t && "number" == typeof t.length) return {
                    next: function() {
                        return t && r >= t.length && (t = void 0), {
                            value: t && t[r++],
                            done: !t
                        }
                    }
                };
                throw TypeError(e ? "Object is not iterable." : "Symbol.iterator is not defined.")
            }

            function _(t, e) {
                var n = "function" == typeof Symbol && t[Symbol.iterator];
                if (!n) return t;
                var r, o, i = n.call(t),
                    s = [];
                try {
                    for (;
                        (void 0 === e || e-- > 0) && !(r = i.next()).done;) s.push(r.value)
                } catch (t) {
                    o = {
                        error: t
                    }
                } finally {
                    try {
                        r && !r.done && (n = i.return) && n.call(i)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return s
            }

            function y() {
                for (var t = [], e = 0; e < arguments.length; e++) t = t.concat(_(arguments[e]));
                return t
            }
            var g = function() {
                return (g = Object.assign || function(t) {
                    for (var e, n = 1, r = arguments.length; n < r; n++)
                        for (var o in e = arguments[n]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                    return t
                }).apply(this, arguments)
            };

            function m() {
                for (var t = [], e = 0; e < arguments.length; e++) t = t.concat(function(t, e) {
                    var n = "function" == typeof Symbol && t[Symbol.iterator];
                    if (!n) return t;
                    var r, o, i = n.call(t),
                        s = [];
                    try {
                        for (;
                            (void 0 === e || e-- > 0) && !(r = i.next()).done;) s.push(r.value)
                    } catch (t) {
                        o = {
                            error: t
                        }
                    } finally {
                        try {
                            r && !r.done && (n = i.return) && n.call(i)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return s
                }(arguments[e]));
                return t
            }
            var b = function(t, e) {
                    return (b = Object.setPrototypeOf || ({
                        __proto__: []
                    }) instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
                    })(t, e)
                },
                S = function() {
                    return (S = Object.assign || function(t) {
                        for (var e, n = 1, r = arguments.length; n < r; n++)
                            for (var o in e = arguments[n]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                        return t
                    }).apply(this, arguments)
                };

            function E(t) {
                var e = "function" == typeof Symbol && Symbol.iterator,
                    n = e && t[e],
                    r = 0;
                if (n) return n.call(t);
                if (t && "number" == typeof t.length) return {
                    next: function() {
                        return t && r >= t.length && (t = void 0), {
                            value: t && t[r++],
                            done: !t
                        }
                    }
                };
                throw TypeError(e ? "Object is not iterable." : "Symbol.iterator is not defined.")
            }
            var x = n(6475),
                w = Object.prototype.toString;

            function k(t) {
                switch (w.call(t)) {
                    case "[object Error]":
                    case "[object Exception]":
                    case "[object DOMException]":
                        return !0;
                    default:
                        return U(t, Error)
                }
            }

            function O(t, e) {
                return w.call(t) === "[object " + e + "]"
            }

            function T(t) {
                return O(t, "ErrorEvent")
            }

            function j(t) {
                return O(t, "DOMError")
            }

            function R(t) {
                return O(t, "String")
            }

            function N(t) {
                return null === t || "object" != typeof t && "function" != typeof t
            }

            function D(t) {
                return O(t, "Object")
            }

            function L(t) {
                return "undefined" != typeof Event && U(t, Event)
            }

            function I(t) {
                return "undefined" != typeof Element && U(t, Element)
            }

            function P(t) {
                return !!(t && t.then && "function" == typeof t.then)
            }

            function U(t, e) {
                try {
                    return t instanceof e
                } catch (t) {
                    return !1
                }
            }

            function C(t, e) {
                try {
                    for (var n = t, r = [], o = 0, i = 0, s = void 0; n && o++ < 5 && (s = function(t, e) {
                            var n, r, o, i, s, a = [];
                            if (!t || !t.tagName) return "";
                            a.push(t.tagName.toLowerCase());
                            var u = e && e.length ? e.filter(function(e) {
                                return t.getAttribute(e)
                            }).map(function(e) {
                                return [e, t.getAttribute(e)]
                            }) : null;
                            if (u && u.length) u.forEach(function(t) {
                                a.push("[" + t[0] + '="' + t[1] + '"]')
                            });
                            else if (t.id && a.push("#" + t.id), (n = t.className) && R(n))
                                for (s = 0, r = n.split(/\s+/); s < r.length; s++) a.push("." + r[s]);
                            var c = ["type", "name", "title", "alt"];
                            for (s = 0; s < c.length; s++) o = c[s], (i = t.getAttribute(o)) && a.push("[" + o + '="' + i + '"]');
                            return a.join("")
                        }(n, e), "html" !== s && (!(o > 1) || !(i + 3 * r.length + s.length >= 80)));) r.push(s), i += s.length, n = n.parentNode;
                    return r.reverse().join(" > ")
                } catch (t) {
                    return "<unknown>"
                }
            }
            var q = "<anonymous>";

            function A(t) {
                try {
                    if (!t || "function" != typeof t) return q;
                    return t.name || q
                } catch (t) {
                    return q
                }
            }

            function M(t, e) {
                return (void 0 === e && (e = 0), "string" != typeof t || 0 === e || t.length <= e) ? t : t.substr(0, e) + "..."
            }

            function B(t, e) {
                if (!Array.isArray(t)) return "";
                for (var n = [], r = 0; r < t.length; r++) {
                    var o = t[r];
                    try {
                        n.push(String(o))
                    } catch (t) {
                        n.push("[value cannot be serialized]")
                    }
                }
                return n.join(e)
            }

            function F(t, e) {
                return !!R(t) && (O(e, "RegExp") ? e.test(t) : "string" == typeof e && -1 !== t.indexOf(e))
            }

            function V(t, e, n) {
                if (e in t) {
                    var r = t[e],
                        o = n(r);
                    if ("function" == typeof o) try {
                        H(o, r)
                    } catch (t) {}
                    t[e] = o
                }
            }

            function Y(t, e, n) {
                Object.defineProperty(t, e, {
                    value: n,
                    writable: !0,
                    configurable: !0
                })
            }

            function H(t, e) {
                var n = e.prototype || {};
                t.prototype = e.prototype = n, Y(t, "__sentry_original__", e)
            }

            function J(t) {
                return t.__sentry_original__
            }

            function z(t) {
                if (k(t)) {
                    var e = {
                        message: t.message,
                        name: t.name,
                        stack: t.stack
                    };
                    for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                    return e
                }
                if (L(t)) {
                    var r = {};
                    r.type = t.type;
                    try {
                        r.target = I(t.target) ? C(t.target) : Object.prototype.toString.call(t.target)
                    } catch (t) {
                        r.target = "<unknown>"
                    }
                    try {
                        r.currentTarget = I(t.currentTarget) ? C(t.currentTarget) : Object.prototype.toString.call(t.currentTarget)
                    } catch (t) {
                        r.currentTarget = "<unknown>"
                    }
                    for (var o in "undefined" != typeof CustomEvent && U(t, CustomEvent) && (r.detail = t.detail), t) Object.prototype.hasOwnProperty.call(t, o) && (r[o] = t[o]);
                    return r
                }
                return t
            }

            function W(t, e) {
                return "domain" === e && t && "object" == typeof t && t._events ? "[Domain]" : "domainEmitter" === e ? "[DomainEmitter]" : void 0 !== n.g && t === n.g ? "[Global]" : "undefined" != typeof window && t === window ? "[Window]" : "undefined" != typeof document && t === document ? "[Document]" : D(t) && "nativeEvent" in t && "preventDefault" in t && "stopPropagation" in t ? "[SyntheticEvent]" : "number" == typeof t && t != t ? "[NaN]" : void 0 === t ? "[undefined]" : "function" == typeof t ? "[Function: " + A(t) + "]" : "symbol" == typeof t ? "[" + String(t) + "]" : "bigint" == typeof t ? "[BigInt: " + String(t) + "]" : t
            }

            function K(t, e) {
                try {
                    return JSON.parse(JSON.stringify(t, function(t, n) {
                        return function t(e, n, r, o) {
                            if (void 0 === r && (r = Infinity), void 0 === o && (s = (i = "function" == typeof WeakSet) ? new WeakSet : [], o = [function(t) {
                                    if (i) return !!s.has(t) || (s.add(t), !1);
                                    for (var e = 0; e < s.length; e++)
                                        if (s[e] === t) return !0;
                                    return s.push(t), !1
                                }, function(t) {
                                    if (i) s.delete(t);
                                    else
                                        for (var e = 0; e < s.length; e++)
                                            if (s[e] === t) {
                                                s.splice(e, 1);
                                                break
                                            }
                                }]), 0 === r) {
                                if ("string" == typeof n) return n;
                                var i, s, a = Object.prototype.toString.call(n);
                                if ("[object Object]" === a) return "[Object]";
                                if ("[object Array]" === a) return "[Array]";
                                var u = W(n);
                                return N(u) ? u : a
                            }
                            if (null != n && "function" == typeof n.toJSON) return n.toJSON();
                            var c = W(n, e);
                            if (N(c)) return c;
                            var p = z(n),
                                f = Array.isArray(n) ? [] : {};
                            if (o[0](n)) return "[Circular ~]";
                            for (var l in p) Object.prototype.hasOwnProperty.call(p, l) && (f[l] = t(l, p[l], r - 1, o));
                            return o[1](n), f
                        }(t, n, e)
                    }))
                } catch (t) {
                    return "**non-serializable**"
                }
            }

            function X() {
                var t = (0, x.V)(),
                    e = t.crypto || t.msCrypto;
                if (void 0 !== e && e.getRandomValues) {
                    var n = new Uint16Array(8);
                    e.getRandomValues(n), n[3] = 4095 & n[3] | 16384, n[4] = 16383 & n[4] | 32768;
                    var r = function(t) {
                        for (var e = t.toString(16); e.length < 4;) e = "0" + e;
                        return e
                    };
                    return r(n[0]) + r(n[1]) + r(n[2]) + r(n[3]) + r(n[4]) + r(n[5]) + r(n[6]) + r(n[7])
                }
                return "xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, function(t) {
                    var e = 16 * Math.random() | 0;
                    return ("x" === t ? e : 3 & e | 8).toString(16)
                })
            }

            function $(t) {
                if (!t) return {};
                var e = t.match(/^(([^:/?#]+):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/);
                if (!e) return {};
                var n = e[6] || "",
                    r = e[8] || "";
                return {
                    host: e[4],
                    path: e[5],
                    protocol: e[2],
                    relative: e[5] + n + r
                }
            }

            function G(t) {
                return t.exception && t.exception.values ? t.exception.values[0] : void 0
            }

            function Z(t) {
                var e = t.message,
                    n = t.event_id;
                if (e) return e;
                var r = G(t);
                return r ? r.type && r.value ? r.type + ": " + r.value : r.type || r.value || n || "<unknown>" : n || "<unknown>"
            }

            function Q(t, e, n) {
                var r = t.exception = t.exception || {},
                    o = r.values = r.values || [],
                    i = o[0] = o[0] || {};
                i.value || (i.value = e || ""), i.type || (i.type = n || "Error")
            }

            function tt(t, e) {
                var n = G(t);
                if (n) {
                    var r = n.mechanism;
                    if (n.mechanism = S(S(S({}, {
                            type: "generic",
                            handled: !0
                        }), r), e), e && "data" in e) {
                        var o = S(S({}, r && r.data), e.data);
                        n.mechanism.data = o
                    }
                }
            }

            function te(t) {
                if (t && t.__sentry_captured__) return !0;
                try {
                    Y(t, "__sentry_captured__", !0)
                } catch (t) {}
                return !1
            }
            var tn = n(9297),
                tr = (0, x.V)(),
                to = "Sentry Logger ";

            function ti(t) {
                var e = (0, x.V)();
                if (!("console" in e)) return t();
                var n = e.console,
                    r = {};
                ["debug", "info", "warn", "error", "log", "assert"].forEach(function(t) {
                    t in e.console && n[t].__sentry_original__ && (r[t] = n[t], n[t] = n[t].__sentry_original__)
                });
                var o = t();
                return Object.keys(r).forEach(function(t) {
                    n[t] = r[t]
                }), o
            }
            var ts = function() {
                function t() {
                    this._enabled = !1
                }
                return t.prototype.disable = function() {
                    this._enabled = !1
                }, t.prototype.enable = function() {
                    this._enabled = !0
                }, t.prototype.log = function() {
                    for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
                    this._enabled && ti(function() {
                        tr.console.log(to + "[Log]: " + t.join(" "))
                    })
                }, t.prototype.warn = function() {
                    for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
                    this._enabled && ti(function() {
                        tr.console.warn(to + "[Warn]: " + t.join(" "))
                    })
                }, t.prototype.error = function() {
                    for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
                    this._enabled && ti(function() {
                        tr.console.error(to + "[Error]: " + t.join(" "))
                    })
                }, t
            }();
            tr.__SENTRY__ = tr.__SENTRY__ || {};
            var ta = tr.__SENTRY__.logger || (tr.__SENTRY__.logger = new ts),
                tu = n(6284);

            function tc(t) {
                return new tf(function(e) {
                    e(t)
                })
            }

            function tp(t) {
                return new tf(function(e, n) {
                    n(t)
                })
            }
            var tf = function() {
                    function t(t) {
                        var e = this;
                        this._state = 0, this._handlers = [], this._resolve = function(t) {
                            e._setResult(1, t)
                        }, this._reject = function(t) {
                            e._setResult(2, t)
                        }, this._setResult = function(t, n) {
                            if (0 === e._state) {
                                if (P(n)) return void n.then(e._resolve, e._reject);
                                e._state = t, e._value = n, e._executeHandlers()
                            }
                        }, this._executeHandlers = function() {
                            if (0 !== e._state) {
                                var t = e._handlers.slice();
                                e._handlers = [], t.forEach(function(t) {
                                    t[0] || (1 === e._state && t[1](e._value), 2 === e._state && t[2](e._value), t[0] = !0)
                                })
                            }
                        };
                        try {
                            t(this._resolve, this._reject)
                        } catch (t) {
                            this._reject(t)
                        }
                    }
                    return t.prototype.then = function(e, n) {
                        var r = this;
                        return new t(function(t, o) {
                            r._handlers.push([!1, function(n) {
                                if (e) try {
                                    t(e(n))
                                } catch (t) {
                                    o(t)
                                } else t(n)
                            }, function(e) {
                                if (n) try {
                                    t(n(e))
                                } catch (t) {
                                    o(t)
                                } else o(e)
                            }]), r._executeHandlers()
                        })
                    }, t.prototype.catch = function(t) {
                        return this.then(function(t) {
                            return t
                        }, t)
                    }, t.prototype.finally = function(e) {
                        var n = this;
                        return new t(function(t, r) {
                            var o, i;
                            return n.then(function(t) {
                                i = !1, o = t, e && e()
                            }, function(t) {
                                i = !0, o = t, e && e()
                            }).then(function() {
                                i ? r(o) : t(o)
                            })
                        })
                    }, t
                }(),
                tl = function() {
                    function t() {
                        this._notifyingListeners = !1, this._scopeListeners = [], this._eventProcessors = [], this._breadcrumbs = [], this._user = {}, this._tags = {}, this._extra = {}, this._contexts = {}, this._sdkProcessingMetadata = {}
                    }
                    return t.clone = function(e) {
                        var n = new t;
                        return e && (n._breadcrumbs = m(e._breadcrumbs), n._tags = g({}, e._tags), n._extra = g({}, e._extra), n._contexts = g({}, e._contexts), n._user = e._user, n._level = e._level, n._span = e._span, n._session = e._session, n._transactionName = e._transactionName, n._fingerprint = e._fingerprint, n._eventProcessors = m(e._eventProcessors), n._requestSession = e._requestSession), n
                    }, t.prototype.addScopeListener = function(t) {
                        this._scopeListeners.push(t)
                    }, t.prototype.addEventProcessor = function(t) {
                        return this._eventProcessors.push(t), this
                    }, t.prototype.setUser = function(t) {
                        return this._user = t || {}, this._session && this._session.update({
                            user: t
                        }), this._notifyScopeListeners(), this
                    }, t.prototype.getUser = function() {
                        return this._user
                    }, t.prototype.getRequestSession = function() {
                        return this._requestSession
                    }, t.prototype.setRequestSession = function(t) {
                        return this._requestSession = t, this
                    }, t.prototype.setTags = function(t) {
                        return this._tags = g(g({}, this._tags), t), this._notifyScopeListeners(), this
                    }, t.prototype.setTag = function(t, e) {
                        var n;
                        return this._tags = g(g({}, this._tags), ((n = {})[t] = e, n)), this._notifyScopeListeners(), this
                    }, t.prototype.setExtras = function(t) {
                        return this._extra = g(g({}, this._extra), t), this._notifyScopeListeners(), this
                    }, t.prototype.setExtra = function(t, e) {
                        var n;
                        return this._extra = g(g({}, this._extra), ((n = {})[t] = e, n)), this._notifyScopeListeners(), this
                    }, t.prototype.setFingerprint = function(t) {
                        return this._fingerprint = t, this._notifyScopeListeners(), this
                    }, t.prototype.setLevel = function(t) {
                        return this._level = t, this._notifyScopeListeners(), this
                    }, t.prototype.setTransactionName = function(t) {
                        return this._transactionName = t, this._notifyScopeListeners(), this
                    }, t.prototype.setTransaction = function(t) {
                        return this.setTransactionName(t)
                    }, t.prototype.setContext = function(t, e) {
                        var n;
                        return null === e ? delete this._contexts[t] : this._contexts = g(g({}, this._contexts), ((n = {})[t] = e, n)), this._notifyScopeListeners(), this
                    }, t.prototype.setSpan = function(t) {
                        return this._span = t, this._notifyScopeListeners(), this
                    }, t.prototype.getSpan = function() {
                        return this._span
                    }, t.prototype.getTransaction = function() {
                        var t = this.getSpan();
                        return t && t.transaction
                    }, t.prototype.setSession = function(t) {
                        return t ? this._session = t : delete this._session, this._notifyScopeListeners(), this
                    }, t.prototype.getSession = function() {
                        return this._session
                    }, t.prototype.update = function(e) {
                        if (!e) return this;
                        if ("function" == typeof e) {
                            var n = e(this);
                            return n instanceof t ? n : this
                        }
                        return e instanceof t ? (this._tags = g(g({}, this._tags), e._tags), this._extra = g(g({}, this._extra), e._extra), this._contexts = g(g({}, this._contexts), e._contexts), e._user && Object.keys(e._user).length && (this._user = e._user), e._level && (this._level = e._level), e._fingerprint && (this._fingerprint = e._fingerprint), e._requestSession && (this._requestSession = e._requestSession)) : D(e) && (this._tags = g(g({}, this._tags), e.tags), this._extra = g(g({}, this._extra), e.extra), this._contexts = g(g({}, this._contexts), e.contexts), e.user && (this._user = e.user), e.level && (this._level = e.level), e.fingerprint && (this._fingerprint = e.fingerprint), e.requestSession && (this._requestSession = e.requestSession)), this
                    }, t.prototype.clear = function() {
                        return this._breadcrumbs = [], this._tags = {}, this._extra = {}, this._user = {}, this._contexts = {}, this._level = void 0, this._transactionName = void 0, this._fingerprint = void 0, this._requestSession = void 0, this._span = void 0, this._session = void 0, this._notifyScopeListeners(), this
                    }, t.prototype.addBreadcrumb = function(t, e) {
                        var n = "number" == typeof e ? Math.min(e, 100) : 100;
                        if (n <= 0) return this;
                        var r = g({
                            timestamp: (0, tn.lu)()
                        }, t);
                        return this._breadcrumbs = m(this._breadcrumbs, [r]).slice(-n), this._notifyScopeListeners(), this
                    }, t.prototype.clearBreadcrumbs = function() {
                        return this._breadcrumbs = [], this._notifyScopeListeners(), this
                    }, t.prototype.applyToEvent = function(t, e) {
                        if (this._extra && Object.keys(this._extra).length && (t.extra = g(g({}, this._extra), t.extra)), this._tags && Object.keys(this._tags).length && (t.tags = g(g({}, this._tags), t.tags)), this._user && Object.keys(this._user).length && (t.user = g(g({}, this._user), t.user)), this._contexts && Object.keys(this._contexts).length && (t.contexts = g(g({}, this._contexts), t.contexts)), this._level && (t.level = this._level), this._transactionName && (t.transaction = this._transactionName), this._span) {
                            t.contexts = g({
                                trace: this._span.getTraceContext()
                            }, t.contexts);
                            var n = this._span.transaction && this._span.transaction.name;
                            n && (t.tags = g({
                                transaction: n
                            }, t.tags))
                        }
                        return this._applyFingerprint(t), t.breadcrumbs = m(t.breadcrumbs || [], this._breadcrumbs), t.breadcrumbs = t.breadcrumbs.length > 0 ? t.breadcrumbs : void 0, t.sdkProcessingMetadata = this._sdkProcessingMetadata, this._notifyEventProcessors(m(th(), this._eventProcessors), t, e)
                    }, t.prototype.setSDKProcessingMetadata = function(t) {
                        return this._sdkProcessingMetadata = g(g({}, this._sdkProcessingMetadata), t), this
                    }, t.prototype._notifyEventProcessors = function(t, e, n, r) {
                        var o = this;
                        return void 0 === r && (r = 0), new tf(function(i, s) {
                            var a = t[r];
                            if (null === e || "function" != typeof a) i(e);
                            else {
                                var u = a(g({}, e), n);
                                P(u) ? u.then(function(e) {
                                    return o._notifyEventProcessors(t, e, n, r + 1).then(i)
                                }).then(null, s) : o._notifyEventProcessors(t, u, n, r + 1).then(i).then(null, s)
                            }
                        })
                    }, t.prototype._notifyScopeListeners = function() {
                        var t = this;
                        this._notifyingListeners || (this._notifyingListeners = !0, this._scopeListeners.forEach(function(e) {
                            e(t)
                        }), this._notifyingListeners = !1)
                    }, t.prototype._applyFingerprint = function(t) {
                        t.fingerprint = t.fingerprint ? Array.isArray(t.fingerprint) ? t.fingerprint : [t.fingerprint] : [], this._fingerprint && (t.fingerprint = t.fingerprint.concat(this._fingerprint)), t.fingerprint && !t.fingerprint.length && delete t.fingerprint
                    }, t
                }();

            function th() {
                var t = (0, x.V)();
                return t.__SENTRY__ = t.__SENTRY__ || {}, t.__SENTRY__.globalEventProcessors = t.__SENTRY__.globalEventProcessors || [], t.__SENTRY__.globalEventProcessors
            }

            function td(t) {
                th().push(t)
            }
            var tv = function() {
                    function t(t) {
                        this.errors = 0, this.sid = X(), this.duration = 0, this.status = "ok", this.init = !0, this.ignoreDuration = !1;
                        var e = (0, tn.zf)();
                        this.timestamp = e, this.started = e, t && this.update(t)
                    }
                    return t.prototype.update = function(t) {
                        if (void 0 === t && (t = {}), t.user && (!this.ipAddress && t.user.ip_address && (this.ipAddress = t.user.ip_address), this.did || t.did || (this.did = t.user.id || t.user.email || t.user.username)), this.timestamp = t.timestamp || (0, tn.zf)(), t.ignoreDuration && (this.ignoreDuration = t.ignoreDuration), t.sid && (this.sid = 32 === t.sid.length ? t.sid : X()), void 0 !== t.init && (this.init = t.init), !this.did && t.did && (this.did = "" + t.did), "number" == typeof t.started && (this.started = t.started), this.ignoreDuration) this.duration = void 0;
                        else if ("number" == typeof t.duration) this.duration = t.duration;
                        else {
                            var e = this.timestamp - this.started;
                            this.duration = e >= 0 ? e : 0
                        }
                        t.release && (this.release = t.release), t.environment && (this.environment = t.environment), !this.ipAddress && t.ipAddress && (this.ipAddress = t.ipAddress), !this.userAgent && t.userAgent && (this.userAgent = t.userAgent), "number" == typeof t.errors && (this.errors = t.errors), t.status && (this.status = t.status)
                    }, t.prototype.close = function(t) {
                        t ? this.update({
                            status: t
                        }) : "ok" === this.status ? this.update({
                            status: "exited"
                        }) : this.update()
                    }, t.prototype.toJSON = function() {
                        return function t(e) {
                            var n, r;
                            if (D(e)) {
                                var o = {};
                                try {
                                    for (var i = E(Object.keys(e)), s = i.next(); !s.done; s = i.next()) {
                                        var a = s.value;
                                        void 0 !== e[a] && (o[a] = t(e[a]))
                                    }
                                } catch (t) {
                                    n = {
                                        error: t
                                    }
                                } finally {
                                    try {
                                        s && !s.done && (r = i.return) && r.call(i)
                                    } finally {
                                        if (n) throw n.error
                                    }
                                }
                                return o
                            }
                            return Array.isArray(e) ? e.map(t) : e
                        }({
                            sid: "" + this.sid,
                            init: this.init,
                            started: new Date(1e3 * this.started).toISOString(),
                            timestamp: new Date(1e3 * this.timestamp).toISOString(),
                            status: this.status,
                            errors: this.errors,
                            did: "number" == typeof this.did || "string" == typeof this.did ? "" + this.did : void 0,
                            duration: this.duration,
                            attrs: {
                                release: this.release,
                                environment: this.environment,
                                ip_address: this.ipAddress,
                                user_agent: this.userAgent
                            }
                        })
                    }, t
                }(),
                t_ = function() {
                    function t(t, e, n) {
                        void 0 === e && (e = new tl), void 0 === n && (n = 4), this._version = n, this._stack = [{}], this.getStackTop().scope = e, t && this.bindClient(t)
                    }
                    return t.prototype.isOlderThan = function(t) {
                        return this._version < t
                    }, t.prototype.bindClient = function(t) {
                        this.getStackTop().client = t, t && t.setupIntegrations && t.setupIntegrations()
                    }, t.prototype.pushScope = function() {
                        var t = tl.clone(this.getScope());
                        return this.getStack().push({
                            client: this.getClient(),
                            scope: t
                        }), t
                    }, t.prototype.popScope = function() {
                        return !(this.getStack().length <= 1) && !!this.getStack().pop()
                    }, t.prototype.withScope = function(t) {
                        var e = this.pushScope();
                        try {
                            t(e)
                        } finally {
                            this.popScope()
                        }
                    }, t.prototype.getClient = function() {
                        return this.getStackTop().client
                    }, t.prototype.getScope = function() {
                        return this.getStackTop().scope
                    }, t.prototype.getStack = function() {
                        return this._stack
                    }, t.prototype.getStackTop = function() {
                        return this._stack[this._stack.length - 1]
                    }, t.prototype.captureException = function(t, e) {
                        var n = this._lastEventId = X(),
                            r = e;
                        if (!e) {
                            var o = void 0;
                            try {
                                throw Error("Sentry syntheticException")
                            } catch (t) {
                                o = t
                            }
                            r = {
                                originalException: t,
                                syntheticException: o
                            }
                        }
                        return this._invokeClient("captureException", t, g(g({}, r), {
                            event_id: n
                        })), n
                    }, t.prototype.captureMessage = function(t, e, n) {
                        var r = this._lastEventId = X(),
                            o = n;
                        if (!n) {
                            var i = void 0;
                            try {
                                throw Error(t)
                            } catch (t) {
                                i = t
                            }
                            o = {
                                originalException: t,
                                syntheticException: i
                            }
                        }
                        return this._invokeClient("captureMessage", t, e, g(g({}, o), {
                            event_id: r
                        })), r
                    }, t.prototype.captureEvent = function(t, e) {
                        var n = X();
                        return "transaction" !== t.type && (this._lastEventId = n), this._invokeClient("captureEvent", t, g(g({}, e), {
                            event_id: n
                        })), n
                    }, t.prototype.lastEventId = function() {
                        return this._lastEventId
                    }, t.prototype.addBreadcrumb = function(t, e) {
                        var n = this.getStackTop(),
                            r = n.scope,
                            o = n.client;
                        if (r && o) {
                            var i = o.getOptions && o.getOptions() || {},
                                s = i.beforeBreadcrumb,
                                a = void 0 === s ? null : s,
                                u = i.maxBreadcrumbs,
                                c = void 0 === u ? 100 : u;
                            if (!(c <= 0)) {
                                var p = (0, tn.lu)(),
                                    f = g({
                                        timestamp: p
                                    }, t),
                                    l = a ? ti(function() {
                                        return a(f, e)
                                    }) : f;
                                null !== l && r.addBreadcrumb(l, c)
                            }
                        }
                    }, t.prototype.setUser = function(t) {
                        var e = this.getScope();
                        e && e.setUser(t)
                    }, t.prototype.setTags = function(t) {
                        var e = this.getScope();
                        e && e.setTags(t)
                    }, t.prototype.setExtras = function(t) {
                        var e = this.getScope();
                        e && e.setExtras(t)
                    }, t.prototype.setTag = function(t, e) {
                        var n = this.getScope();
                        n && n.setTag(t, e)
                    }, t.prototype.setExtra = function(t, e) {
                        var n = this.getScope();
                        n && n.setExtra(t, e)
                    }, t.prototype.setContext = function(t, e) {
                        var n = this.getScope();
                        n && n.setContext(t, e)
                    }, t.prototype.configureScope = function(t) {
                        var e = this.getStackTop(),
                            n = e.scope,
                            r = e.client;
                        n && r && t(n)
                    }, t.prototype.run = function(t) {
                        var e = tg(this);
                        try {
                            t(this)
                        } finally {
                            tg(e)
                        }
                    }, t.prototype.getIntegration = function(t) {
                        var e = this.getClient();
                        if (!e) return null;
                        try {
                            return e.getIntegration(t)
                        } catch (e) {
                            return ta.warn("Cannot retrieve integration " + t.id + " from the current Hub"), null
                        }
                    }, t.prototype.startSpan = function(t) {
                        return this._callExtensionMethod("startSpan", t)
                    }, t.prototype.startTransaction = function(t, e) {
                        return this._callExtensionMethod("startTransaction", t, e)
                    }, t.prototype.traceHeaders = function() {
                        return this._callExtensionMethod("traceHeaders")
                    }, t.prototype.captureSession = function(t) {
                        if (void 0 === t && (t = !1), t) return this.endSession();
                        this._sendSessionUpdate()
                    }, t.prototype.endSession = function() {
                        var t = this.getStackTop(),
                            e = t && t.scope,
                            n = e && e.getSession();
                        n && n.close(), this._sendSessionUpdate(), e && e.setSession()
                    }, t.prototype.startSession = function(t) {
                        var e = this.getStackTop(),
                            n = e.scope,
                            r = e.client,
                            o = r && r.getOptions() || {},
                            i = o.release,
                            s = o.environment,
                            a = ((0, x.V)().navigator || {}).userAgent,
                            u = new tv(g(g(g({
                                release: i,
                                environment: s
                            }, n && {
                                user: n.getUser()
                            }), a && {
                                userAgent: a
                            }), t));
                        if (n) {
                            var c = n.getSession && n.getSession();
                            c && "ok" === c.status && c.update({
                                status: "exited"
                            }), this.endSession(), n.setSession(u)
                        }
                        return u
                    }, t.prototype._sendSessionUpdate = function() {
                        var t = this.getStackTop(),
                            e = t.scope,
                            n = t.client;
                        if (e) {
                            var r = e.getSession && e.getSession();
                            r && n && n.captureSession && n.captureSession(r)
                        }
                    }, t.prototype._invokeClient = function(t) {
                        for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
                        var r = this.getStackTop(),
                            o = r.scope,
                            i = r.client;
                        i && i[t] && i[t].apply(i, m(e, [o]))
                    }, t.prototype._callExtensionMethod = function(t) {
                        for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
                        var r = ty().__SENTRY__;
                        if (r && r.extensions && "function" == typeof r.extensions[t]) return r.extensions[t].apply(this, e);
                        ta.warn("Extension method " + t + " couldn't be found, doing nothing.")
                    }, t
                }();

            function ty() {
                var t = (0, x.V)();
                return t.__SENTRY__ = t.__SENTRY__ || {
                    extensions: {},
                    hub: void 0
                }, t
            }

            function tg(t) {
                var e = ty(),
                    n = tS(e);
                return tE(e, t), n
            }

            function tm() {
                var t = ty();
                return ((!tb(t) || tS(t).isOlderThan(4)) && tE(t, new t_), (0, tu.wD)()) ? function(t) {
                    try {
                        var e = ty().__SENTRY__,
                            n = e && e.extensions && e.extensions.domain && e.extensions.domain.active;
                        if (!n) return tS(t);
                        if (!tb(n) || tS(n).isOlderThan(4)) {
                            var r = tS(t).getStackTop();
                            tE(n, new t_(r.client, tl.clone(r.scope)))
                        }
                        return tS(n)
                    } catch (e) {
                        return tS(t)
                    }
                }(t) : tS(t)
            }

            function tb(t) {
                return !!(t && t.__SENTRY__ && t.__SENTRY__.hub)
            }

            function tS(t) {
                return t && t.__SENTRY__ && t.__SENTRY__.hub || (t.__SENTRY__ = t.__SENTRY__ || {}, t.__SENTRY__.hub = new t_), t.__SENTRY__.hub
            }

            function tE(t, e) {
                return !!t && (t.__SENTRY__ = t.__SENTRY__ || {}, t.__SENTRY__.hub = e, !0)
            }
            var tx = "6.17.9",
                tw = function() {
                    return (tw = Object.assign || function(t) {
                        for (var e, n = 1, r = arguments.length; n < r; n++)
                            for (var o in e = arguments[n]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                        return t
                    }).apply(this, arguments)
                };

            function tk() {
                for (var t = [], e = 0; e < arguments.length; e++) t = t.concat(function(t, e) {
                    var n = "function" == typeof Symbol && t[Symbol.iterator];
                    if (!n) return t;
                    var r, o, i = n.call(t),
                        s = [];
                    try {
                        for (;
                            (void 0 === e || e-- > 0) && !(r = i.next()).done;) s.push(r.value)
                    } catch (t) {
                        o = {
                            error: t
                        }
                    } finally {
                        try {
                            r && !r.done && (n = i.return) && n.call(i)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return s
                }(arguments[e]));
                return t
            }
            var tO = n(8341),
                tT = Object.setPrototypeOf || (({
                    __proto__: []
                }) instanceof Array ? function(t, e) {
                    return t.__proto__ = e, t
                } : function(t, e) {
                    for (var n in e) Object.prototype.hasOwnProperty.call(t, n) || (t[n] = e[n]);
                    return t
                }),
                tj = function(t) {
                    function e() {
                        this.constructor = n
                    }

                    function n(e) {
                        var n = this.constructor,
                            r = t.call(this, e) || this;
                        return r.message = e, r.name = n.prototype.constructor.name, tT(r, n.prototype), r
                    }
                    return b(n, t), n.prototype = null === t ? Object.create(t) : (e.prototype = t.prototype, new e), n
                }(Error),
                tR = /^(?:(\w+):)\/\/(?:(\w+)(?::(\w+))?@)([\w.-]+)(?::(\d+))?\/(.+)/;

            function tN(t, e) {
                void 0 === e && (e = !1);
                var n = t.host,
                    r = t.path,
                    o = t.pass,
                    i = t.port,
                    s = t.projectId;
                return t.protocol + "://" + t.publicKey + (e && o ? ":" + o : "") + ("@" + n + (i ? ":" + i : "") + "/") + (r ? r + "/" : r) + s
            }

            function tD(t) {
                return "user" in t && !("publicKey" in t) && (t.publicKey = t.user), {
                    user: t.publicKey || "",
                    protocol: t.protocol,
                    publicKey: t.publicKey || "",
                    pass: t.pass || "",
                    host: t.host,
                    port: t.port || "",
                    path: t.path || "",
                    projectId: t.projectId
                }
            }

            function tL(t) {
                var e = "string" == typeof t ? function(t) {
                    var e = tR.exec(t);
                    if (!e) throw new tj("Invalid Sentry Dsn: " + t);
                    var n = function(t, e) {
                            var n = "function" == typeof Symbol && t[Symbol.iterator];
                            if (!n) return t;
                            var r, o, i = n.call(t),
                                s = [];
                            try {
                                for (;
                                    (void 0 === e || e-- > 0) && !(r = i.next()).done;) s.push(r.value)
                            } catch (t) {
                                o = {
                                    error: t
                                }
                            } finally {
                                try {
                                    r && !r.done && (n = i.return) && n.call(i)
                                } finally {
                                    if (o) throw o.error
                                }
                            }
                            return s
                        }(e.slice(1), 6),
                        r = n[0],
                        o = n[1],
                        i = n[2],
                        s = n[3],
                        a = n[4],
                        u = n[5],
                        c = "",
                        p = u,
                        f = p.split("/");
                    if (f.length > 1 && (c = f.slice(0, -1).join("/"), p = f.pop()), p) {
                        var l = p.match(/^\d+/);
                        l && (p = l[0])
                    }
                    return tD({
                        host: s,
                        pass: void 0 === i ? "" : i,
                        path: c,
                        projectId: p,
                        port: void 0 === a ? "" : a,
                        protocol: r,
                        publicKey: o
                    })
                }(t) : tD(t);
                return ! function(t) {
                    if ((0, tO.a)()) {
                        var e = t.port,
                            n = t.projectId,
                            r = t.protocol;
                        if (["protocol", "publicKey", "host", "projectId"].forEach(function(e) {
                                if (!t[e]) throw new tj("Invalid Sentry Dsn: " + e + " missing")
                            }), !n.match(/^\d+$/)) throw new tj("Invalid Sentry Dsn: Invalid projectId " + n);
                        if ("http" !== r && "https" !== r) throw new tj("Invalid Sentry Dsn: Invalid protocol " + r);
                        if (e && isNaN(parseInt(e, 10))) throw new tj("Invalid Sentry Dsn: Invalid port " + e)
                    }
                }(e), e
            }
            var tI = [];

            function tP(t) {
                return t.reduce(function(t, e) {
                    return t.every(function(t) {
                        return e.name !== t.name
                    }) && t.push(e), t
                }, [])
            }
            var tU = "Not capturing exception because it's already been captured.",
                tC = function() {
                    function t(t, e) {
                        this._integrations = {}, this._numProcessing = 0, this._backend = new t(e), this._options = e, e.dsn && (this._dsn = tL(e.dsn))
                    }
                    return t.prototype.captureException = function(t, e, n) {
                        var r = this;
                        if (te(t)) return void ta.log(tU);
                        var o = e && e.event_id;
                        return this._process(this._getBackend().eventFromException(t, e).then(function(t) {
                            return r._captureEvent(t, e, n)
                        }).then(function(t) {
                            o = t
                        })), o
                    }, t.prototype.captureMessage = function(t, e, n, r) {
                        var o = this,
                            i = n && n.event_id,
                            s = N(t) ? this._getBackend().eventFromMessage(String(t), e, n) : this._getBackend().eventFromException(t, n);
                        return this._process(s.then(function(t) {
                            return o._captureEvent(t, n, r)
                        }).then(function(t) {
                            i = t
                        })), i
                    }, t.prototype.captureEvent = function(t, e, n) {
                        if (e && e.originalException && te(e.originalException)) return void ta.log(tU);
                        var r = e && e.event_id;
                        return this._process(this._captureEvent(t, e, n).then(function(t) {
                            r = t
                        })), r
                    }, t.prototype.captureSession = function(t) {
                        if (!this._isEnabled()) {
                            (0, tO.a)() && ta.warn("SDK not enabled, will not capture session.");
                            return
                        }
                        "string" != typeof t.release ? (0, tO.a)() && ta.warn("Discarded session because of missing or non-string release") : (this._sendSession(t), t.update({
                            init: !1
                        }))
                    }, t.prototype.getDsn = function() {
                        return this._dsn
                    }, t.prototype.getOptions = function() {
                        return this._options
                    }, t.prototype.getTransport = function() {
                        return this._getBackend().getTransport()
                    }, t.prototype.flush = function(t) {
                        var e = this;
                        return this._isClientDoneProcessing(t).then(function(n) {
                            return e.getTransport().close(t).then(function(t) {
                                return n && t
                            })
                        })
                    }, t.prototype.close = function(t) {
                        var e = this;
                        return this.flush(t).then(function(t) {
                            return e.getOptions().enabled = !1, t
                        })
                    }, t.prototype.setupIntegrations = function() {
                        var t, e, n, r, o, i, s;
                        this._isEnabled() && !this._integrations.initialized && (this._integrations = (t = this._options, e = {}, (n = t.defaultIntegrations && tk(t.defaultIntegrations) || [], r = t.integrations, o = tk(tP(n)), Array.isArray(r) ? o = tk(o.filter(function(t) {
                            return r.every(function(e) {
                                return e.name !== t.name
                            })
                        }), tP(r)) : "function" == typeof r && (o = Array.isArray(o = r(o)) ? o : [o]), i = o.map(function(t) {
                            return t.name
                        }), s = "Debug", -1 !== i.indexOf(s) && o.push.apply(o, tk(o.splice(i.indexOf(s), 1))), o).forEach(function(t) {
                            e[t.name] = t, -1 === tI.indexOf(t.name) && (t.setupOnce(td, tm), tI.push(t.name), ta.log("Integration installed: " + t.name))
                        }), Y(e, "initialized", !0), e))
                    }, t.prototype.getIntegration = function(t) {
                        try {
                            return this._integrations[t.id] || null
                        } catch (e) {
                            return ta.warn("Cannot retrieve integration " + t.id + " from the current Client"), null
                        }
                    }, t.prototype._updateSessionFromEvent = function(t, e) {
                        var n, r, o = !1,
                            i = !1,
                            s = e.exception && e.exception.values;
                        if (s) {
                            i = !0;
                            try {
                                for (var a = function(t) {
                                        var e = "function" == typeof Symbol && Symbol.iterator,
                                            n = e && t[e],
                                            r = 0;
                                        if (n) return n.call(t);
                                        if (t && "number" == typeof t.length) return {
                                            next: function() {
                                                return t && r >= t.length && (t = void 0), {
                                                    value: t && t[r++],
                                                    done: !t
                                                }
                                            }
                                        };
                                        throw TypeError(e ? "Object is not iterable." : "Symbol.iterator is not defined.")
                                    }(s), u = a.next(); !u.done; u = a.next()) {
                                    var c = u.value.mechanism;
                                    if (c && !1 === c.handled) {
                                        o = !0;
                                        break
                                    }
                                }
                            } catch (t) {
                                n = {
                                    error: t
                                }
                            } finally {
                                try {
                                    u && !u.done && (r = a.return) && r.call(a)
                                } finally {
                                    if (n) throw n.error
                                }
                            }
                        }
                        var p = "ok" === t.status;
                        (p && 0 === t.errors || p && o) && (t.update(tw(tw({}, o && {
                            status: "crashed"
                        }), {
                            errors: t.errors || Number(i || o)
                        })), this.captureSession(t))
                    }, t.prototype._sendSession = function(t) {
                        this._getBackend().sendSession(t)
                    }, t.prototype._isClientDoneProcessing = function(t) {
                        var e = this;
                        return new tf(function(n) {
                            var r = 0,
                                o = setInterval(function() {
                                    0 == e._numProcessing ? (clearInterval(o), n(!0)) : (r += 1, t && r >= t && (clearInterval(o), n(!1)))
                                }, 1)
                        })
                    }, t.prototype._getBackend = function() {
                        return this._backend
                    }, t.prototype._isEnabled = function() {
                        return !1 !== this.getOptions().enabled && void 0 !== this._dsn
                    }, t.prototype._prepareEvent = function(t, e, n) {
                        var r = this,
                            o = this.getOptions().normalizeDepth,
                            i = void 0 === o ? 3 : o,
                            s = tw(tw({}, t), {
                                event_id: t.event_id || (n && n.event_id ? n.event_id : X()),
                                timestamp: t.timestamp || (0, tn.lu)()
                            });
                        this._applyClientOptions(s), this._applyIntegrationsMetadata(s);
                        var a = e;
                        n && n.captureContext && (a = tl.clone(a).update(n.captureContext));
                        var u = tc(s);
                        return a && (u = a.applyToEvent(s, n)), u.then(function(t) {
                            return (t && (t.sdkProcessingMetadata = tw(tw({}, t.sdkProcessingMetadata), {
                                normalizeDepth: K(i)
                            })), "number" == typeof i && i > 0) ? r._normalizeEvent(t, i) : t
                        })
                    }, t.prototype._normalizeEvent = function(t, e) {
                        if (!t) return null;
                        var n = tw(tw(tw(tw(tw({}, t), t.breadcrumbs && {
                            breadcrumbs: t.breadcrumbs.map(function(t) {
                                return tw(tw({}, t), t.data && {
                                    data: K(t.data, e)
                                })
                            })
                        }), t.user && {
                            user: K(t.user, e)
                        }), t.contexts && {
                            contexts: K(t.contexts, e)
                        }), t.extra && {
                            extra: K(t.extra, e)
                        });
                        return t.contexts && t.contexts.trace && (n.contexts.trace = t.contexts.trace), t.sdkProcessingMetadata = tw(tw({}, t.sdkProcessingMetadata), {
                            baseClientNormalized: !0
                        }), n
                    }, t.prototype._applyClientOptions = function(t) {
                        var e = this.getOptions(),
                            n = e.environment,
                            r = e.release,
                            o = e.dist,
                            i = e.maxValueLength,
                            s = void 0 === i ? 250 : i;
                        "environment" in t || (t.environment = "environment" in e ? n : "production"), void 0 === t.release && void 0 !== r && (t.release = r), void 0 === t.dist && void 0 !== o && (t.dist = o), t.message && (t.message = M(t.message, s));
                        var a = t.exception && t.exception.values && t.exception.values[0];
                        a && a.value && (a.value = M(a.value, s));
                        var u = t.request;
                        u && u.url && (u.url = M(u.url, s))
                    }, t.prototype._applyIntegrationsMetadata = function(t) {
                        var e = Object.keys(this._integrations);
                        e.length > 0 && (t.sdk = t.sdk || {}, t.sdk.integrations = tk(t.sdk.integrations || [], e))
                    }, t.prototype._sendEvent = function(t) {
                        this._getBackend().sendEvent(t)
                    }, t.prototype._captureEvent = function(t, e, n) {
                        return this._processEvent(t, e, n).then(function(t) {
                            return t.event_id
                        }, function(t) {
                            ta.error(t)
                        })
                    }, t.prototype._processEvent = function(t, e, n) {
                        var r = this,
                            o = this.getOptions(),
                            i = o.beforeSend,
                            s = o.sampleRate,
                            a = this.getTransport();

                        function u(t, e) {
                            a.recordLostEvent && a.recordLostEvent(t, e)
                        }
                        if (!this._isEnabled()) return tp(new tj("SDK not enabled, will not capture event."));
                        var c = "transaction" === t.type;
                        return !c && "number" == typeof s && Math.random() > s ? (u("sample_rate", "event"), tp(new tj("Discarding event because it's not included in the random sample (sampling rate = " + s + ")"))) : this._prepareEvent(t, n, e).then(function(n) {
                            if (null === n) throw u("event_processor", t.type || "event"), new tj("An event processor returned null, will not send event.");
                            return e && e.data && !0 === e.data.__sentry__ || c || !i ? n : function(t) {
                                var e = "`beforeSend` method has to return `null` or a valid event.";
                                if (P(t)) return t.then(function(t) {
                                    if (!(D(t) || null === t)) throw new tj(e);
                                    return t
                                }, function(t) {
                                    throw new tj("beforeSend rejected with " + t)
                                });
                                if (!(D(t) || null === t)) throw new tj(e);
                                return t
                            }(i(n, e))
                        }).then(function(e) {
                            if (null === e) throw u("before_send", t.type || "event"), new tj("`beforeSend` returned `null`, will not send event.");
                            var o = n && n.getSession && n.getSession();
                            return !c && o && r._updateSessionFromEvent(o, e), r._sendEvent(e), e
                        }).then(null, function(t) {
                            if (t instanceof tj) throw t;
                            throw r.captureException(t, {
                                data: {
                                    __sentry__: !0
                                },
                                originalException: t
                            }), new tj("Event processing pipeline threw an error, original event will not be sent. Details have been sent as a new event.\nReason: " + t)
                        })
                    }, t.prototype._process = function(t) {
                        var e = this;
                        this._numProcessing += 1, t.then(function(t) {
                            return e._numProcessing -= 1, t
                        }, function(t) {
                            return e._numProcessing -= 1, t
                        })
                    }, t
                }(),
                tq = function() {
                    function t() {}
                    return t.prototype.sendEvent = function(t) {
                        return tc({
                            reason: "NoopTransport: Event has been skipped because no Dsn is configured.",
                            status: "skipped"
                        })
                    }, t.prototype.close = function(t) {
                        return tc(!0)
                    }, t
                }(),
                tA = function() {
                    function t(t) {
                        this._options = t, this._options.dsn || ta.warn("No DSN provided, backend will not do anything."), this._transport = this._setupTransport()
                    }
                    return t.prototype.eventFromException = function(t, e) {
                        throw new tj("Backend has to implement `eventFromException` method")
                    }, t.prototype.eventFromMessage = function(t, e, n) {
                        throw new tj("Backend has to implement `eventFromMessage` method")
                    }, t.prototype.sendEvent = function(t) {
                        this._transport.sendEvent(t).then(null, function(t) {
                            (0, tO.a)() && ta.error("Error while sending event: " + t)
                        })
                    }, t.prototype.sendSession = function(t) {
                        if (!this._transport.sendSession) {
                            (0, tO.a)() && ta.warn("Dropping session because custom transport doesn't implement sendSession");
                            return
                        }
                        this._transport.sendSession(t).then(null, function(t) {
                            (0, tO.a)() && ta.error("Error while sending session: " + t)
                        })
                    }, t.prototype.getTransport = function() {
                        return this._transport
                    }, t.prototype._setupTransport = function() {
                        return new tq
                    }, t
                }();

            function tM() {
                if (!("fetch" in (0, x.V)())) return !1;
                try {
                    return new Headers, new Request(""), new Response, !0
                } catch (t) {
                    return !1
                }
            }

            function tB(t) {
                return t && /^function fetch\(\)\s+\{\s+\[native code\]\s+\}$/.test(t.toString())
            }

            function tF(t, e, n, r) {
                var o = {
                    filename: t,
                    function: e,
                    in_app: !0
                };
                return void 0 !== n && (o.lineno = n), void 0 !== r && (o.colno = r), o
            }(r = o || (o = {})).Fatal = "fatal", r.Error = "error", r.Warning = "warning", r.Log = "log", r.Info = "info", r.Debug = "debug", r.Critical = "critical";
            var tV = /^\s*at (?:(.*?) ?\((?:address at )?)?((?:file|https?|blob|chrome-extension|address|native|eval|webpack|<anonymous>|[-a-z]+:|.*bundle|\/).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,
                tY = /\((\S*)(?::(\d+))(?::(\d+))\)/,
                tH = function(t) {
                    var e = tV.exec(t);
                    if (e) {
                        if (e[2] && 0 === e[2].indexOf("eval")) {
                            var n = tY.exec(e[2]);
                            n && (e[2] = n[1], e[3] = n[2], e[4] = n[3])
                        }
                        var r = _(t0(e[1] || "?", e[2]), 2),
                            o = r[0];
                        return tF(r[1], o, e[3] ? +e[3] : void 0, e[4] ? +e[4] : void 0)
                    }
                },
                tJ = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:file|https?|blob|chrome|webpack|resource|moz-extension|capacitor).*?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i,
                tz = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i,
                tW = function(t) {
                    var e, n = tJ.exec(t);
                    if (n) {
                        if (n[3] && n[3].indexOf(" > eval") > -1) {
                            var r = tz.exec(n[3]);
                            r && (n[1] = n[1] || "eval", n[3] = r[1], n[4] = r[2], n[5] = "")
                        }
                        var o = n[3],
                            i = n[1] || "?";
                        return i = (e = _(t0(i, o), 2))[0], tF(o = e[1], i, n[4] ? +n[4] : void 0, n[5] ? +n[5] : void 0)
                    }
                },
                tK = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i,
                tX = function(t) {
                    var e = tK.exec(t);
                    return e ? tF(e[2], e[1] || "?", +e[3], e[4] ? +e[4] : void 0) : void 0
                },
                t$ = / line (\d+).*script (?:in )?(\S+)(?:: in function (\S+))?$/i,
                tG = function(t) {
                    var e = t$.exec(t);
                    return e ? tF(e[2], e[3] || "?", +e[1]) : void 0
                },
                tZ = / line (\d+), column (\d+)\s*(?:in (?:<anonymous function: ([^>]+)>|([^)]+))\(.*\))? in (.*):\s*$/i,
                tQ = function(t) {
                    var e = tZ.exec(t);
                    return e ? tF(e[5], e[3] || e[4] || "?", +e[1], +e[2]) : void 0
                },
                t0 = function(t, e) {
                    var n = -1 !== t.indexOf("safari-extension"),
                        r = -1 !== t.indexOf("safari-web-extension");
                    return n || r ? [-1 !== t.indexOf("@") ? t.split("@")[0] : "?", n ? "safari-extension:" + e : "safari-web-extension:" + e] : [t, e]
                };

            function t1(t) {
                var e, n, r = t3(t),
                    o = {
                        type: t && t.name,
                        value: (n = (e = t) && e.message) ? n.error && "string" == typeof n.error.message ? n.error.message : n : "No error message"
                    };
                return r && r.length && (o.stacktrace = {
                    frames: r
                }), void 0 === o.type && "" === o.value && (o.value = "Unrecoverable error caught"), o
            }

            function t2(t) {
                return {
                    exception: {
                        values: [t1(t)]
                    }
                }
            }

            function t3(t) {
                var e = t.stacktrace || t.stack || "",
                    n = function(t) {
                        if (t) {
                            if ("number" == typeof t.framesToPop) return t.framesToPop;
                            if (t4.test(t.message)) return 1
                        }
                        return 0
                    }(t);
                try {
                    return (function() {
                        for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
                        return function(e, n) {
                            void 0 === n && (n = 0);
                            var r, o, i, s, a = [];
                            try {
                                for (var u = E(e.split("\n").slice(n)), c = u.next(); !c.done; c = u.next()) {
                                    var p = c.value;
                                    try {
                                        for (var f = (i = void 0, E(t)), l = f.next(); !l.done; l = f.next()) {
                                            var h = (0, l.value)(p);
                                            if (h) {
                                                a.push(h);
                                                break
                                            }
                                        }
                                    } catch (t) {
                                        i = {
                                            error: t
                                        }
                                    } finally {
                                        try {
                                            l && !l.done && (s = f.return) && s.call(f)
                                        } finally {
                                            if (i) throw i.error
                                        }
                                    }
                                }
                            } catch (t) {
                                r = {
                                    error: t
                                }
                            } finally {
                                try {
                                    c && !c.done && (o = u.return) && o.call(u)
                                } finally {
                                    if (r) throw r.error
                                }
                            }
                            var d = a;
                            if (!d.length) return [];
                            var v = d,
                                _ = v[0].function || "",
                                y = v[v.length - 1].function || "";
                            return (-1 !== _.indexOf("captureMessage") || -1 !== _.indexOf("captureException")) && (v = v.slice(1)), -1 !== y.indexOf("sentryWrapped") && (v = v.slice(0, -1)), v.slice(0, 50).map(function(t) {
                                return S(S({}, t), {
                                    filename: t.filename || v[0].filename,
                                    function: t.function || "?"
                                })
                            }).reverse()
                        }
                    })(tG, tQ, tH, tX, tW)(e, n)
                } catch (t) {}
                return []
            }
            var t4 = /Minified React error #\d+;/i;

            function t6(t, e, n) {
                if (void 0 === n && (n = {}), T(t) && t.error) return t2(t.error);
                if (j(t) || O(t, "DOMException")) {
                    if ("stack" in t) r = t2(t);
                    else {
                        var r, o, i, s = t.name || (j(t) ? "DOMError" : "DOMException"),
                            a = t.message ? s + ": " + t.message : s;
                        Q(r = t5(a, e, n), a)
                    }
                    return "code" in t && (r.tags = d(d({}, r.tags), {
                        "DOMException.code": "" + t.code
                    })), r
                }
                return k(t) ? t2(t) : D(t) || L(t) ? (o = n.isRejection, i = {
                    exception: {
                        values: [{
                            type: L(t) ? t.constructor.name : o ? "UnhandledRejection" : "Error",
                            value: "Non-Error " + (o ? "promise rejection" : "exception") + " captured with keys: " + function(t, e) {
                                void 0 === e && (e = 40);
                                var n = Object.keys(z(t));
                                if (n.sort(), !n.length) return "[object has no keys]";
                                if (n[0].length >= e) return M(n[0], e);
                                for (var r = n.length; r > 0; r--) {
                                    var o = n.slice(0, r).join(", ");
                                    if (!(o.length > e)) {
                                        if (r === n.length) return o;
                                        return M(o, e)
                                    }
                                }
                                return ""
                            }(t)
                        }]
                    },
                    extra: {
                        __serialized__: function t(e, n, r) {
                            void 0 === n && (n = 3), void 0 === r && (r = 102400);
                            var o = K(e, n);
                            return ~-encodeURI(JSON.stringify(o)).split(/%..|./).length > r ? t(e, n - 1, r) : o
                        }(t)
                    }
                }, e && (i.stacktrace = {
                    frames: t3(e)
                }), tt(r = i, {
                    synthetic: !0
                }), r) : (Q(r = t5(t, e, n), "" + t, void 0), tt(r, {
                    synthetic: !0
                }), r)
            }

            function t5(t, e, n) {
                void 0 === n && (n = {});
                var r = {
                    message: t
                };
                return n.attachStacktrace && e && (r.stacktrace = {
                    frames: t3(e)
                }), r
            }

            function t8(t, e, n) {
                void 0 === e && (e = {}), this.dsn = t, this._dsnObject = tL(t), this.metadata = e, this._tunnel = n
            }

            function t9(t) {
                var e = t.protocol ? t.protocol + ":" : "",
                    n = t.port ? ":" + t.port : "";
                return e + "//" + t.host + n + (t.path ? "/" + t.path : "") + "/api/"
            }

            function t7(t, e) {
                return "" + t9(t) + t.projectId + "/" + e + "/"
            }

            function et(t) {
                var e;
                return Object.keys(e = {
                    sentry_key: t.publicKey,
                    sentry_version: "7"
                }).map(function(t) {
                    return encodeURIComponent(t) + "=" + encodeURIComponent(e[t])
                }).join("&")
            }

            function ee(t) {
                return t7(t, "store")
            }

            function en(t) {
                return ee(t) + "?" + et(t)
            }

            function er(t, e) {
                return e || t7(t, "envelope") + "?" + et(t)
            }

            function eo(t) {
                if (t.metadata && t.metadata.sdk) {
                    var e = t.metadata.sdk;
                    return {
                        name: e.name,
                        version: e.version
                    }
                }
            }
            t8.prototype.getDsn = function() {
                return this._dsnObject
            }, t8.prototype.forceEnvelope = function() {
                return !!this._tunnel
            }, t8.prototype.getBaseApiEndpoint = function() {
                return t9(this._dsnObject)
            }, t8.prototype.getStoreEndpoint = function() {
                return ee(this._dsnObject)
            }, t8.prototype.getStoreEndpointWithUrlEncodedAuth = function() {
                return en(this._dsnObject)
            }, t8.prototype.getEnvelopeEndpointWithUrlEncodedAuth = function() {
                return er(this._dsnObject, this._tunnel)
            };
            var ei = (0, x.V)();

            function es() {
                if (i) return i;
                if (tB(ei.fetch)) return i = ei.fetch.bind(ei);
                var t = ei.document,
                    e = ei.fetch;
                if (t && "function" == typeof t.createElement) try {
                    var n = t.createElement("iframe");
                    n.hidden = !0, t.head.appendChild(n);
                    var r = n.contentWindow;
                    r && r.fetch && (e = r.fetch), t.head.removeChild(n)
                } catch (t) {
                    (0, tO.a)() && ta.warn("Could not create sandbox iframe for pure fetch check, bailing to window.fetch: ", t)
                }
                return i = e.bind(ei)
            }

            function ea(t) {
                return "event" === t ? "error" : t
            }
            var eu = (0, x.V)(),
                ec = function() {
                    function t(t) {
                        var e, n, r, o = this;
                        this.options = t, this._buffer = function(t) {
                            var e = [];

                            function n(t) {
                                return e.splice(e.indexOf(t), 1)[0]
                            }
                            return {
                                $: e,
                                add: function(t) {
                                    if (!(e.length < 30)) return tp(new tj("Not adding Promise due to buffer limit reached."));
                                    var r = t();
                                    return -1 === e.indexOf(r) && e.push(r), r.then(function() {
                                        return n(r)
                                    }).then(null, function() {
                                        return n(r).then(null, function() {})
                                    }), r
                                },
                                drain: function(t) {
                                    return new tf(function(n, r) {
                                        var o = e.length;
                                        if (!o) return n(!0);
                                        var i = setTimeout(function() {
                                            t && t > 0 && n(!1)
                                        }, t);
                                        e.forEach(function(t) {
                                            tc(t).then(function() {
                                                --o || (clearTimeout(i), n(!0))
                                            }, r)
                                        })
                                    })
                                }
                            }
                        }(0), this._rateLimits = {}, this._outcomes = {}, this._api = (e = t.dsn, n = t._metadata, r = t.tunnel, {
                            initDsn: e,
                            metadata: n || {},
                            dsn: tL(e),
                            tunnel: r
                        }), this.url = en(this._api.dsn), this.options.sendClientReports && eu.document && eu.document.addEventListener("visibilitychange", function() {
                            "hidden" === eu.document.visibilityState && o._flushOutcomes()
                        })
                    }
                    return t.prototype.sendEvent = function(t) {
                        return this._sendRequest(function(t, e) {
                            var n, r, o = eo(e),
                                i = t.type || "event",
                                s = "transaction" === i || !!e.tunnel,
                                a = (t.sdkProcessingMetadata || {}).transactionSampling || {},
                                u = a.method,
                                c = a.rate;
                            (n = e.metadata.sdk) && (t.sdk = t.sdk || {}, t.sdk.name = t.sdk.name || n.name, t.sdk.version = t.sdk.version || n.version, t.sdk.integrations = tk(t.sdk.integrations || [], n.integrations || []), t.sdk.packages = tk(t.sdk.packages || [], n.packages || [])), t.tags = t.tags || {}, t.extra = t.extra || {}, t.sdkProcessingMetadata && t.sdkProcessingMetadata.baseClientNormalized || (t.tags.skippedNormalization = !0, t.extra.normalizeDepth = t.sdkProcessingMetadata ? t.sdkProcessingMetadata.normalizeDepth : "unset"), delete t.sdkProcessingMetadata;
                            try {
                                r = JSON.stringify(t)
                            } catch (e) {
                                t.tags.JSONStringifyError = !0, t.extra.JSONStringifyError = e;
                                try {
                                    r = JSON.stringify(K(t))
                                } catch (t) {
                                    r = JSON.stringify({
                                        message: "JSON.stringify error after renormalization",
                                        extra: {
                                            message: t.message,
                                            stack: t.stack
                                        }
                                    })
                                }
                            }
                            var p = {
                                body: r,
                                type: i,
                                url: s ? er(e.dsn, e.tunnel) : en(e.dsn)
                            };
                            if (s) {
                                var f = JSON.stringify(tw(tw({
                                    event_id: t.event_id,
                                    sent_at: new Date().toISOString()
                                }, o && {
                                    sdk: o
                                }), !!e.tunnel && {
                                    dsn: tN(e.dsn)
                                })) + "\n" + JSON.stringify({
                                    type: i,
                                    sample_rates: [{
                                        id: u,
                                        rate: c
                                    }]
                                }) + "\n" + p.body;
                                p.body = f
                            }
                            return p
                        }(t, this._api), t)
                    }, t.prototype.sendSession = function(t) {
                        var e, n, r;
                        return this._sendRequest((n = eo(e = this._api), {
                            body: JSON.stringify(tw(tw({
                                sent_at: new Date().toISOString()
                            }, n && {
                                sdk: n
                            }), !!e.tunnel && {
                                dsn: tN(e.dsn)
                            })) + "\n" + JSON.stringify({
                                type: r = "aggregates" in t ? "sessions" : "session"
                            }) + "\n" + JSON.stringify(t),
                            type: r,
                            url: er(e.dsn, e.tunnel)
                        }), t)
                    }, t.prototype.close = function(t) {
                        return this._buffer.drain(t)
                    }, t.prototype.recordLostEvent = function(t, e) {
                        if (this.options.sendClientReports) {
                            var n, r = ea(e) + ":" + t;
                            ta.log("Adding outcome: " + r), this._outcomes[r] = (null != (n = this._outcomes[r]) ? n : 0) + 1
                        }
                    }, t.prototype._flushOutcomes = function() {
                        if (this.options.sendClientReports) {
                            var t = this._outcomes;
                            if (this._outcomes = {}, !Object.keys(t).length) return void ta.log("No outcomes to flush");
                            ta.log("Flushing outcomes:\n" + JSON.stringify(t, null, 2));
                            var e = er(this._api.dsn, this._api.tunnel),
                                n = JSON.stringify(d({}, this._api.tunnel && {
                                    dsn: tN(this._api.dsn)
                                })),
                                r = JSON.stringify({
                                    type: "client_report"
                                }),
                                o = JSON.stringify({
                                    timestamp: (0, tn.lu)(),
                                    discarded_events: Object.keys(t).map(function(e) {
                                        var n = _(e.split(":"), 2),
                                            r = n[0];
                                        return {
                                            reason: n[1],
                                            category: r,
                                            quantity: t[e]
                                        }
                                    })
                                });
                            try {
                                ! function(t, e) {
                                    if ("[object Navigator]" === Object.prototype.toString.call(ei && ei.navigator) && "function" == typeof ei.navigator.sendBeacon) return ei.navigator.sendBeacon.bind(ei.navigator)(t, e);
                                    tM() && es()(t, {
                                        body: e,
                                        method: "POST",
                                        credentials: "omit",
                                        keepalive: !0
                                    }).then(null, function(t) {
                                        console.error(t)
                                    })
                                }(e, n + "\n" + r + "\n" + o)
                            } catch (t) {
                                ta.error(t)
                            }
                        }
                    }, t.prototype._handleResponse = function(t) {
                        var e, n = t.requestType,
                            r = t.response,
                            o = t.headers,
                            i = t.resolve,
                            s = t.reject,
                            a = (e = r.status) >= 200 && e < 300 ? "success" : 429 === e ? "rate_limit" : e >= 400 && e < 500 ? "invalid" : e >= 500 ? "failed" : "unknown";
                        (this._handleRateLimit(o) && (0, tO.a)() && ta.warn("Too many " + n + " requests, backing off until: " + this._disabledUntil(n)), "success" === a) ? i({
                            status: a
                        }): s(r)
                    }, t.prototype._disabledUntil = function(t) {
                        var e = ea(t);
                        return this._rateLimits[e] || this._rateLimits.all
                    }, t.prototype._isRateLimited = function(t) {
                        return this._disabledUntil(t) > new Date(Date.now())
                    }, t.prototype._handleRateLimit = function(t) {
                        var e, n, r, o, i = Date.now(),
                            s = t["x-sentry-rate-limits"],
                            a = t["retry-after"];
                        if (s) {
                            try {
                                for (var u = v(s.trim().split(",")), c = u.next(); !c.done; c = u.next()) {
                                    var p = c.value.split(":", 2),
                                        f = parseInt(p[0], 10),
                                        l = (isNaN(f) ? 60 : f) * 1e3;
                                    try {
                                        for (var h = (r = void 0, v(p[1].split(";"))), d = h.next(); !d.done; d = h.next()) {
                                            var _ = d.value;
                                            this._rateLimits[_ || "all"] = new Date(i + l)
                                        }
                                    } catch (t) {
                                        r = {
                                            error: t
                                        }
                                    } finally {
                                        try {
                                            d && !d.done && (o = h.return) && o.call(h)
                                        } finally {
                                            if (r) throw r.error
                                        }
                                    }
                                }
                            } catch (t) {
                                e = {
                                    error: t
                                }
                            } finally {
                                try {
                                    c && !c.done && (n = u.return) && n.call(u)
                                } finally {
                                    if (e) throw e.error
                                }
                            }
                            return !0
                        }
                        return !!a && (this._rateLimits.all = new Date(i + function(t, e) {
                            if (!e) return 6e4;
                            var n = parseInt("" + e, 10);
                            if (!isNaN(n)) return 1e3 * n;
                            var r = Date.parse("" + e);
                            return isNaN(r) ? 6e4 : r - t
                        }(i, a)), !0)
                    }, t
                }(),
                ep = function(t) {
                    function e(e, n) {
                        void 0 === n && (n = es());
                        var r = t.call(this, e) || this;
                        return r._fetch = n, r
                    }
                    return h(e, t), e.prototype._sendRequest = function(t, e) {
                        var n = this;
                        if (this._isRateLimited(t.type)) return this.recordLostEvent("ratelimit_backoff", t.type), Promise.reject({
                            event: e,
                            type: t.type,
                            reason: "Transport for " + t.type + " requests locked till " + this._disabledUntil(t.type) + " due to too many requests.",
                            status: 429
                        });
                        var r = {
                            body: t.body,
                            method: "POST",
                            referrerPolicy: ! function() {
                                if (!tM()) return !1;
                                try {
                                    return new Request("_", {
                                        referrerPolicy: "origin"
                                    }), !0
                                } catch (t) {
                                    return !1
                                }
                            }() ? "" : "origin"
                        };
                        return void 0 !== this.options.fetchParameters && Object.assign(r, this.options.fetchParameters), void 0 !== this.options.headers && (r.headers = this.options.headers), this._buffer.add(function() {
                            return new tf(function(e, o) {
                                n._fetch(t.url, r).then(function(r) {
                                    var i = {
                                        "x-sentry-rate-limits": r.headers.get("X-Sentry-Rate-Limits"),
                                        "retry-after": r.headers.get("Retry-After")
                                    };
                                    n._handleResponse({
                                        requestType: t.type,
                                        response: r,
                                        headers: i,
                                        resolve: e,
                                        reject: o
                                    })
                                }).catch(o)
                            })
                        }).then(void 0, function(e) {
                            throw e instanceof tj ? n.recordLostEvent("queue_overflow", t.type) : n.recordLostEvent("network_error", t.type), e
                        })
                    }, e
                }(ec),
                ef = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return h(e, t), e.prototype._sendRequest = function(t, e) {
                        var n = this;
                        return this._isRateLimited(t.type) ? (this.recordLostEvent("ratelimit_backoff", t.type), Promise.reject({
                            event: e,
                            type: t.type,
                            reason: "Transport for " + t.type + " requests locked till " + this._disabledUntil(t.type) + " due to too many requests.",
                            status: 429
                        })) : this._buffer.add(function() {
                            return new tf(function(e, r) {
                                var o = new XMLHttpRequest;
                                for (var i in o.onreadystatechange = function() {
                                        if (4 === o.readyState) {
                                            var i = {
                                                "x-sentry-rate-limits": o.getResponseHeader("X-Sentry-Rate-Limits"),
                                                "retry-after": o.getResponseHeader("Retry-After")
                                            };
                                            n._handleResponse({
                                                requestType: t.type,
                                                response: o,
                                                headers: i,
                                                resolve: e,
                                                reject: r
                                            })
                                        }
                                    }, o.open("POST", t.url), n.options.headers) Object.prototype.hasOwnProperty.call(n.options.headers, i) && o.setRequestHeader(i, n.options.headers[i]);
                                o.send(t.body)
                            })
                        }).then(void 0, function(e) {
                            throw e instanceof tj ? n.recordLostEvent("queue_overflow", t.type) : n.recordLostEvent("network_error", t.type), e
                        })
                    }, e
                }(ec),
                el = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return h(e, t), e.prototype.eventFromException = function(t, e) {
                        var n, r;
                        return n = this._options, tt(r = t6(t, e && e.syntheticException || void 0, {
                            attachStacktrace: n.attachStacktrace
                        })), r.level = o.Error, e && e.event_id && (r.event_id = e.event_id), tc(r)
                    }, e.prototype.eventFromMessage = function(t, e, n) {
                        var r, i, s;
                        return void 0 === e && (e = o.Info), r = this._options, void 0 === (i = e) && (i = o.Info), (s = t5(t, n && n.syntheticException || void 0, {
                            attachStacktrace: r.attachStacktrace
                        })).level = i, n && n.event_id && (s.event_id = n.event_id), tc(s)
                    }, e.prototype._setupTransport = function() {
                        if (!this._options.dsn) return t.prototype._setupTransport.call(this);
                        var e = d(d({}, this._options.transportOptions), {
                            dsn: this._options.dsn,
                            tunnel: this._options.tunnel,
                            sendClientReports: this._options.sendClientReports,
                            _metadata: this._options._metadata
                        });
                        return this._options.transport ? new this._options.transport(e) : tM() ? new ep(e) : new ef(e)
                    }, e
                }(tA);

            function eh(t) {
                for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
                var r = tm();
                if (r && r[t]) return r[t].apply(r, function() {
                    for (var t = [], e = 0; e < arguments.length; e++) t = t.concat(function(t, e) {
                        var n = "function" == typeof Symbol && t[Symbol.iterator];
                        if (!n) return t;
                        var r, o, i = n.call(t),
                            s = [];
                        try {
                            for (;
                                (void 0 === e || e-- > 0) && !(r = i.next()).done;) s.push(r.value)
                        } catch (t) {
                            o = {
                                error: t
                            }
                        } finally {
                            try {
                                r && !r.done && (n = i.return) && n.call(i)
                            } finally {
                                if (o) throw o.error
                            }
                        }
                        return s
                    }(arguments[e]));
                    return t
                }(e));
                throw Error("No hub defined or " + t + " was not found on the hub, please open a bug report.")
            }
            var ed = (0, x.V)(),
                ev = 0;

            function e_(t, e, n) {
                if (void 0 === e && (e = {}), "function" != typeof t) return t;
                try {
                    var r = t.__sentry_wrapped__;
                    if (r) return r;
                    if (J(t)) return t
                } catch (e) {
                    return t
                }
                var o = function() {
                    var r, o = Array.prototype.slice.call(arguments);
                    try {
                        n && "function" == typeof n && n.apply(this, arguments);
                        var i = o.map(function(t) {
                            return e_(t, e)
                        });
                        return t.apply(this, i)
                    } catch (t) {
                        throw ev += 1, setTimeout(function() {
                            ev -= 1
                        }), r = function(n) {
                            n.addEventProcessor(function(t) {
                                    return e.mechanism && (Q(t, void 0, void 0), tt(t, e.mechanism)), t.extra = d(d({}, t.extra), {
                                        arguments: o
                                    }), t
                                }),
                                function(t, e) {
                                    var n;
                                    try {
                                        throw Error("Sentry syntheticException")
                                    } catch (t) {
                                        n = t
                                    }
                                    eh("captureException", t, {
                                        captureContext: void 0,
                                        originalException: t,
                                        syntheticException: n
                                    })
                                }(t)
                        }, eh("withScope", r), t
                    }
                };
                try {
                    for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (o[i] = t[i])
                } catch (t) {}
                H(o, t), Y(t, "__sentry_wrapped__", o);
                try {
                    Object.getOwnPropertyDescriptor(o, "name").configurable && Object.defineProperty(o, "name", {
                        get: function() {
                            return t.name
                        }
                    })
                } catch (t) {}
                return o
            }
            var ey = (0, x.V)(),
                eg = {},
                em = {};

            function eb(t, e) {
                eg[t] = eg[t] || [], eg[t].push(e);
                if (!em[t]) switch (em[t] = !0, t) {
                    case "console":
                        "console" in ey && ["debug", "info", "warn", "error", "log", "assert"].forEach(function(t) {
                            t in ey.console && V(ey.console, t, function(e) {
                                return function() {
                                    for (var n = [], r = 0; r < arguments.length; r++) n[r] = arguments[r];
                                    eS("console", {
                                        args: n,
                                        level: t
                                    }), e && e.apply(ey.console, n)
                                }
                            })
                        });
                        break;
                    case "dom":
                        if ("document" in ey) {
                            var n = eS.bind(null, "dom"),
                                r = eE(n, !0);
                            ey.document.addEventListener("click", r, !1), ey.document.addEventListener("keypress", r, !1), ["EventTarget", "Node"].forEach(function(t) {
                                var e = ey[t] && ey[t].prototype;
                                e && e.hasOwnProperty && e.hasOwnProperty("addEventListener") && (V(e, "addEventListener", function(t) {
                                    return function(e, r, o) {
                                        if ("click" === e || "keypress" == e) try {
                                            var i = this.__sentry_instrumentation_handlers__ = this.__sentry_instrumentation_handlers__ || {},
                                                s = i[e] = i[e] || {
                                                    refCount: 0
                                                };
                                            if (!s.handler) {
                                                var a = eE(n);
                                                s.handler = a, t.call(this, e, a, o)
                                            }
                                            s.refCount += 1
                                        } catch (t) {}
                                        return t.call(this, e, r, o)
                                    }
                                }), V(e, "removeEventListener", function(t) {
                                    return function(e, n, r) {
                                        if ("click" === e || "keypress" == e) try {
                                            var o = this.__sentry_instrumentation_handlers__ || {},
                                                i = o[e];
                                            i && (i.refCount -= 1, i.refCount <= 0 && (t.call(this, e, i.handler, r), i.handler = void 0, delete o[e]), 0 === Object.keys(o).length && delete this.__sentry_instrumentation_handlers__)
                                        } catch (t) {}
                                        return t.call(this, e, n, r)
                                    }
                                }))
                            })
                        }
                        break;
                    case "xhr":
                        if ("XMLHttpRequest" in ey) {
                            var o = XMLHttpRequest.prototype;
                            V(o, "open", function(t) {
                                return function() {
                                    for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                                    var r = this,
                                        o = e[1],
                                        i = r.__sentry_xhr__ = {
                                            method: R(e[0]) ? e[0].toUpperCase() : e[0],
                                            url: e[1]
                                        };
                                    R(o) && "POST" === i.method && o.match(/sentry_key/) && (r.__sentry_own_request__ = !0);
                                    var s = function() {
                                        if (4 === r.readyState) {
                                            try {
                                                i.status_code = r.status
                                            } catch (t) {}
                                            eS("xhr", {
                                                args: e,
                                                endTimestamp: Date.now(),
                                                startTimestamp: Date.now(),
                                                xhr: r
                                            })
                                        }
                                    };
                                    return "onreadystatechange" in r && "function" == typeof r.onreadystatechange ? V(r, "onreadystatechange", function(t) {
                                        return function() {
                                            for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                                            return s(), t.apply(r, e)
                                        }
                                    }) : r.addEventListener("readystatechange", s), t.apply(r, e)
                                }
                            }), V(o, "send", function(t) {
                                return function() {
                                    for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                                    return this.__sentry_xhr__ && void 0 !== e[0] && (this.__sentry_xhr__.body = e[0]), eS("xhr", {
                                        args: e,
                                        startTimestamp: Date.now(),
                                        xhr: this
                                    }), t.apply(this, e)
                                }
                            })
                        }
                        break;
                    case "fetch":
                        (function() {
                            if (!tM()) return !1;
                            var t = (0, x.V)();
                            if (tB(t.fetch)) return !0;
                            var e = !1,
                                n = t.document;
                            if (n && "function" == typeof n.createElement) try {
                                var r = n.createElement("iframe");
                                r.hidden = !0, n.head.appendChild(r), r.contentWindow && r.contentWindow.fetch && (e = tB(r.contentWindow.fetch)), n.head.removeChild(r)
                            } catch (t) {
                                (0, tO.a)() && ta.warn("Could not create sandbox iframe for pure fetch check, bailing to window.fetch: ", t)
                            }
                            return e
                        })() && V(ey, "fetch", function(t) {
                            return function() {
                                for (var e, n, r = [], o = 0; o < arguments.length; o++) r[o] = arguments[o];
                                var i = {
                                    args: r,
                                    fetchData: {
                                        method: (void 0 === (e = r) && (e = []), "Request" in ey && U(e[0], Request) && e[0].method) ? String(e[0].method).toUpperCase() : e[1] && e[1].method ? String(e[1].method).toUpperCase() : "GET",
                                        url: (void 0 === (n = r) && (n = []), "string" == typeof n[0]) ? n[0] : "Request" in ey && U(n[0], Request) ? n[0].url : String(n[0])
                                    },
                                    startTimestamp: Date.now()
                                };
                                return eS("fetch", S({}, i)), t.apply(ey, r).then(function(t) {
                                    return eS("fetch", S(S({}, i), {
                                        endTimestamp: Date.now(),
                                        response: t
                                    })), t
                                }, function(t) {
                                    throw eS("fetch", S(S({}, i), {
                                        endTimestamp: Date.now(),
                                        error: t
                                    })), t
                                })
                            }
                        });
                        break;
                    case "history":
                        ! function() {
                            if (n = (e = (t = (0, x.V)()).chrome) && e.app && e.app.runtime, r = "history" in t && !!t.history.pushState && !!t.history.replaceState, !n && r) {
                                var t, e, n, r, o = ey.onpopstate;
                                ey.onpopstate = function() {
                                    for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
                                    var n = ey.location.href,
                                        r = s;
                                    if (s = n, eS("history", {
                                            from: r,
                                            to: n
                                        }), o) try {
                                        return o.apply(this, t)
                                    } catch (t) {}
                                }, V(ey.history, "pushState", i), V(ey.history, "replaceState", i)
                            }

                            function i(t) {
                                return function() {
                                    for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                                    var r = e.length > 2 ? e[2] : void 0;
                                    if (r) {
                                        var o = s,
                                            i = String(r);
                                        s = i, eS("history", {
                                            from: o,
                                            to: i
                                        })
                                    }
                                    return t.apply(this, e)
                                }
                            }
                        }();
                        break;
                    case "error":
                        ex = ey.onerror, ey.onerror = function(t, e, n, r, o) {
                            return eS("error", {
                                column: r,
                                error: o,
                                line: n,
                                msg: t,
                                url: e
                            }), !!ex && ex.apply(this, arguments)
                        };
                        break;
                    case "unhandledrejection":
                        ew = ey.onunhandledrejection, ey.onunhandledrejection = function(t) {
                            return eS("unhandledrejection", t), !ew || ew.apply(this, arguments)
                        };
                        break;
                    default:
                        ta.warn("unknown instrumentation type:", t)
                }
            }

            function eS(t, e) {
                var n, r;
                if (t && eg[t]) try {
                    for (var o = E(eg[t] || []), i = o.next(); !i.done; i = o.next()) {
                        var s = i.value;
                        try {
                            s(e)
                        } catch (e) {
                            (0, tO.a)() && ta.error("Error while triggering instrumentation handler.\nType: " + t + "\nName: " + A(s) + "\nError: " + e)
                        }
                    }
                } catch (t) {
                    n = {
                        error: t
                    }
                } finally {
                    try {
                        i && !i.done && (r = o.return) && r.call(o)
                    } finally {
                        if (n) throw n.error
                    }
                }
            }

            function eE(t, e) {
                return void 0 === e && (e = !1),
                    function(n) {
                        if (n && u !== n && ! function(t) {
                                if ("keypress" !== t.type) return !1;
                                try {
                                    var e = t.target;
                                    if (!e || !e.tagName) return !0;
                                    if ("INPUT" === e.tagName || "TEXTAREA" === e.tagName || e.isContentEditable) return !1
                                } catch (t) {}
                                return !0
                            }(n)) {
                            var r = "keypress" === n.type ? "input" : n.type;
                            void 0 === a ? (t({
                                event: n,
                                name: r,
                                global: e
                            }), u = n) : function(t, e) {
                                if (!t || t.type !== e.type) return !0;
                                try {
                                    if (t.target !== e.target) return !0
                                } catch (t) {}
                                return !1
                            }(u, n) && (t({
                                event: n,
                                name: r,
                                global: e
                            }), u = n), clearTimeout(a), a = ey.setTimeout(function() {
                                a = void 0
                            }, 1e3)
                        }
                    }
            }
            var ex = null,
                ew = null,
                ek = ["fatal", "error", "warning", "log", "info", "debug", "critical"],
                eO = function() {
                    function t(e) {
                        this.name = t.id, this._options = d({
                            console: !0,
                            dom: !0,
                            fetch: !0,
                            history: !0,
                            sentry: !0,
                            xhr: !0
                        }, e)
                    }
                    return t.prototype.addSentryBreadcrumb = function(t) {
                        this._options.sentry && tm().addBreadcrumb({
                            category: "sentry." + ("transaction" === t.type ? "transaction" : "event"),
                            event_id: t.event_id,
                            level: t.level,
                            message: Z(t)
                        }, {
                            event: t
                        })
                    }, t.prototype.setupOnce = function() {
                        var t;
                        this._options.console && eb("console", eT), this._options.dom && eb("dom", (t = this._options.dom, function(e) {
                            var n, r = "object" == typeof t ? t.serializeAttribute : void 0;
                            "string" == typeof r && (r = [r]);
                            try {
                                n = e.event.target ? C(e.event.target, r) : C(e.event, r)
                            } catch (t) {
                                n = "<unknown>"
                            }
                            0 !== n.length && tm().addBreadcrumb({
                                category: "ui." + e.name,
                                message: n
                            }, {
                                event: e.event,
                                name: e.name,
                                global: e.global
                            })
                        })), this._options.xhr && eb("xhr", ej), this._options.fetch && eb("fetch", eR), this._options.history && eb("history", eN)
                    }, t.id = "Breadcrumbs", t
                }();

            function eT(t) {
                var e = {
                    category: "console",
                    data: {
                        arguments: t.args,
                        logger: "console"
                    },
                    level: function(t) {
                        return "warn" === t ? o.Warning : -1 !== ek.indexOf(t) ? t : o.Log
                    }(t.level),
                    message: B(t.args, " ")
                };
                if ("assert" === t.level)
                    if (!1 !== t.args[0]) return;
                    else e.message = "Assertion failed: " + (B(t.args.slice(1), " ") || "console.assert"), e.data.arguments = t.args.slice(1);
                tm().addBreadcrumb(e, {
                    input: t.args,
                    level: t.level
                })
            }

            function ej(t) {
                if (t.endTimestamp && !t.xhr.__sentry_own_request__) {
                    var e = t.xhr.__sentry_xhr__ || {},
                        n = e.method,
                        r = e.url,
                        o = e.status_code,
                        i = e.body;
                    tm().addBreadcrumb({
                        category: "xhr",
                        data: {
                            method: n,
                            url: r,
                            status_code: o
                        },
                        type: "http"
                    }, {
                        xhr: t.xhr,
                        input: i
                    });
                    return
                }
            }

            function eR(t) {
                !t.endTimestamp || t.fetchData.url.match(/sentry_key/) && "POST" === t.fetchData.method || (t.error ? tm().addBreadcrumb({
                    category: "fetch",
                    data: t.fetchData,
                    level: o.Error,
                    type: "http"
                }, {
                    data: t.error,
                    input: t.args
                }) : tm().addBreadcrumb({
                    category: "fetch",
                    data: d(d({}, t.fetchData), {
                        status_code: t.response.status
                    }),
                    type: "http"
                }, {
                    input: t.args,
                    response: t.response
                }))
            }

            function eN(t) {
                var e = (0, x.V)(),
                    n = t.from,
                    r = t.to,
                    o = $(e.location.href),
                    i = $(n),
                    s = $(r);
                i.path || (i = o), o.protocol === s.protocol && o.host === s.host && (r = s.relative), o.protocol === i.protocol && o.host === i.host && (n = i.relative), tm().addBreadcrumb({
                    category: "navigation",
                    data: {
                        from: n,
                        to: r
                    }
                })
            }
            var eD = function(t) {
                    function e(e) {
                        void 0 === e && (e = {});
                        return e._metadata = e._metadata || {}, e._metadata.sdk = e._metadata.sdk || {
                            name: "sentry.javascript.browser",
                            packages: [{
                                name: "npm:@sentry/browser",
                                version: tx
                            }],
                            version: tx
                        }, t.call(this, el, e) || this
                    }
                    return h(e, t), e.prototype.showReportDialog = function(t) {
                        if (void 0 === t && (t = {}), (0, x.V)().document) {
                            if (!this._isEnabled()) return void ta.error("Trying to call showReportDialog with Sentry Client disabled");
                            ! function(t) {
                                if (void 0 === t && (t = {}), ed.document) {
                                    if (!t.eventId) {
                                        (0, tO.a)() && ta.error("Missing eventId option in showReportDialog call");
                                        return
                                    }
                                    if (!t.dsn) {
                                        (0, tO.a)() && ta.error("Missing dsn option in showReportDialog call");
                                        return
                                    }
                                    var e = ed.document.createElement("script");
                                    e.async = !0, e.src = function(t, e) {
                                        var n = tL(t),
                                            r = t9(n) + "embed/error-page/",
                                            o = "dsn=" + tN(n);
                                        for (var i in e)
                                            if ("dsn" !== i)
                                                if ("user" === i) {
                                                    if (!e.user) continue;
                                                    e.user.name && (o += "&name=" + encodeURIComponent(e.user.name)), e.user.email && (o += "&email=" + encodeURIComponent(e.user.email))
                                                } else o += "&" + encodeURIComponent(i) + "=" + encodeURIComponent(e[i]);
                                        return r + "?" + o
                                    }(t.dsn, t), t.onLoad && (e.onload = t.onLoad);
                                    var n = ed.document.head || ed.document.body;
                                    n && n.appendChild(e)
                                }
                            }(d(d({}, t), {
                                dsn: t.dsn || this.getDsn()
                            }))
                        }
                    }, e.prototype._prepareEvent = function(e, n, r) {
                        return e.platform = e.platform || "javascript", t.prototype._prepareEvent.call(this, e, n, r)
                    }, e.prototype._sendEvent = function(e) {
                        var n = this.getIntegration(eO);
                        n && n.addSentryBreadcrumb(e), t.prototype._sendEvent.call(this, e)
                    }, e
                }(tC),
                eL = function() {
                    function t() {
                        this.name = t.id
                    }
                    return t.prototype.setupOnce = function() {
                        c = Function.prototype.toString, Function.prototype.toString = function() {
                            for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
                            var n = J(this) || this;
                            return c.apply(n, t)
                        }
                    }, t.id = "FunctionToString", t
                }(),
                eI = [/^Script error\.?$/, /^Javascript error: Script error\.? on line 0$/],
                eP = function() {
                    function t(e) {
                        void 0 === e && (e = {}), this._options = e, this.name = t.id
                    }
                    return t.prototype.setupOnce = function() {
                        td(function(e) {
                            var n = tm();
                            if (!n) return e;
                            var r = n.getIntegration(t);
                            if (r) {
                                var o = n.getClient(),
                                    i = o ? o.getOptions() : {},
                                    s = "function" == typeof r._mergeOptions ? r._mergeOptions(i) : {};
                                return "function" != typeof r._shouldDropEvent ? e : r._shouldDropEvent(e, s) ? null : e
                            }
                            return e
                        })
                    }, t.prototype._shouldDropEvent = function(t, e) {
                        return this._isSentryError(t, e) ? ((0, tO.a)() && ta.warn("Event dropped due to being internal Sentry Error.\nEvent: " + Z(t)), !0) : this._isIgnoredError(t, e) ? ((0, tO.a)() && ta.warn("Event dropped due to being matched by `ignoreErrors` option.\nEvent: " + Z(t)), !0) : this._isDeniedUrl(t, e) ? ((0, tO.a)() && ta.warn("Event dropped due to being matched by `denyUrls` option.\nEvent: " + Z(t) + ".\nUrl: " + this._getEventFilterUrl(t)), !0) : !this._isAllowedUrl(t, e) && ((0, tO.a)() && ta.warn("Event dropped due to not being matched by `allowUrls` option.\nEvent: " + Z(t) + ".\nUrl: " + this._getEventFilterUrl(t)), !0)
                    }, t.prototype._isSentryError = function(t, e) {
                        if (!e.ignoreInternal) return !1;
                        try {
                            return "SentryError" === t.exception.values[0].type
                        } catch (t) {}
                        return !1
                    }, t.prototype._isIgnoredError = function(t, e) {
                        return !!e.ignoreErrors && !!e.ignoreErrors.length && this._getPossibleEventMessages(t).some(function(t) {
                            return e.ignoreErrors.some(function(e) {
                                return F(t, e)
                            })
                        })
                    }, t.prototype._isDeniedUrl = function(t, e) {
                        if (!e.denyUrls || !e.denyUrls.length) return !1;
                        var n = this._getEventFilterUrl(t);
                        return !!n && e.denyUrls.some(function(t) {
                            return F(n, t)
                        })
                    }, t.prototype._isAllowedUrl = function(t, e) {
                        if (!e.allowUrls || !e.allowUrls.length) return !0;
                        var n = this._getEventFilterUrl(t);
                        return !n || e.allowUrls.some(function(t) {
                            return F(n, t)
                        })
                    }, t.prototype._mergeOptions = function(t) {
                        return void 0 === t && (t = {}), {
                            allowUrls: tk(this._options.whitelistUrls || [], this._options.allowUrls || [], t.whitelistUrls || [], t.allowUrls || []),
                            denyUrls: tk(this._options.blacklistUrls || [], this._options.denyUrls || [], t.blacklistUrls || [], t.denyUrls || []),
                            ignoreErrors: tk(this._options.ignoreErrors || [], t.ignoreErrors || [], eI),
                            ignoreInternal: void 0 === this._options.ignoreInternal || this._options.ignoreInternal
                        }
                    }, t.prototype._getPossibleEventMessages = function(t) {
                        if (t.message) return [t.message];
                        if (t.exception) try {
                            var e = t.exception.values && t.exception.values[0] || {},
                                n = e.type,
                                r = e.value,
                                o = void 0 === r ? "" : r;
                            return ["" + o, (void 0 === n ? "" : n) + ": " + o]
                        } catch (e) {
                            (0, tO.a)() && ta.error("Cannot extract message for event " + Z(t))
                        }
                        return []
                    }, t.prototype._getLastValidUrl = function(t) {
                        void 0 === t && (t = []);
                        for (var e = t.length - 1; e >= 0; e--) {
                            var n = t[e];
                            if (n && "<anonymous>" !== n.filename && "[native code]" !== n.filename) return n.filename || null
                        }
                        return null
                    }, t.prototype._getEventFilterUrl = function(t) {
                        try {
                            var e;
                            if (t.stacktrace) return this._getLastValidUrl(t.stacktrace.frames);
                            try {
                                e = t.exception.values[0].stacktrace.frames
                            } catch (t) {}
                            return e ? this._getLastValidUrl(e) : null
                        } catch (e) {
                            return (0, tO.a)() && ta.error("Cannot extract url for event " + Z(t)), null
                        }
                    }, t.id = "InboundFilters", t
                }(),
                eU = function() {
                    function t(e) {
                        this.name = t.id, this._installFunc = {
                            onerror: eC,
                            onunhandledrejection: eq
                        }, this._options = d({
                            onerror: !0,
                            onunhandledrejection: !0
                        }, e)
                    }
                    return t.prototype.setupOnce = function() {
                        Error.stackTraceLimit = 50;
                        var t = this._options;
                        for (var e in t) {
                            var n, r = this._installFunc[e];
                            r && t[e] && (n = e, (0, tO.a)() && ta.log("Global Handler attached: " + n), r(), this._installFunc[e] = void 0)
                        }
                    }, t.id = "GlobalHandlers", t
                }();

            function eC() {
                eb("error", function(t) {
                    var e = _(eB(), 2),
                        n = e[0],
                        r = e[1];
                    if (n.getIntegration(eU)) {
                        var i = t.msg,
                            s = t.url,
                            a = t.line,
                            u = t.column,
                            c = t.error;
                        if (!(ev > 0) && (!c || !c.__sentry_own_request__)) {
                            var p, f, l, h, d, v, y, g = void 0 === c && R(i) ? (p = i, f = s, l = a, h = u, d = T(p) ? p.message : p, v = "Error", (y = d.match(/^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/i)) && (v = y[1], d = y[2]), eA({
                                exception: {
                                    values: [{
                                        type: v,
                                        value: d
                                    }]
                                }
                            }, f, l, h)) : eA(t6(c || i, void 0, {
                                attachStacktrace: r,
                                isRejection: !1
                            }), s, a, u);
                            g.level = o.Error, eM(n, c, g, "onerror")
                        }
                    }
                })
            }

            function eq() {
                eb("unhandledrejection", function(t) {
                    var e = _(eB(), 2),
                        n = e[0],
                        r = e[1];
                    if (n.getIntegration(eU)) {
                        var i = t;
                        try {
                            "reason" in t ? i = t.reason : "detail" in t && "reason" in t.detail && (i = t.detail.reason)
                        } catch (t) {}
                        if (ev > 0 || i && i.__sentry_own_request__) return !0;
                        var s = N(i) ? {
                            exception: {
                                values: [{
                                    type: "UnhandledRejection",
                                    value: "Non-Error promise rejection captured with value: " + String(i)
                                }]
                            }
                        } : t6(i, void 0, {
                            attachStacktrace: r,
                            isRejection: !0
                        });
                        s.level = o.Error, eM(n, i, s, "onunhandledrejection")
                    }
                })
            }

            function eA(t, e, n, r) {
                var o = t.exception = t.exception || {},
                    i = o.values = o.values || [],
                    s = i[0] = i[0] || {},
                    a = s.stacktrace = s.stacktrace || {},
                    u = a.frames = a.frames || [],
                    c = isNaN(parseInt(r, 10)) ? void 0 : r,
                    p = isNaN(parseInt(n, 10)) ? void 0 : n,
                    f = R(e) && e.length > 0 ? e : function() {
                        var t = (0, x.V)();
                        try {
                            return t.document.location.href
                        } catch (t) {
                            return ""
                        }
                    }();
                return 0 === u.length && u.push({
                    colno: c,
                    filename: f,
                    function: "?",
                    in_app: !0,
                    lineno: p
                }), t
            }

            function eM(t, e, n, r) {
                tt(n, {
                    handled: !1,
                    type: r
                }), t.captureEvent(n, {
                    originalException: e
                })
            }

            function eB() {
                var t = tm(),
                    e = t.getClient();
                return [t, e && e.getOptions().attachStacktrace]
            }
            var eF = ["EventTarget", "Window", "Node", "ApplicationCache", "AudioTrackList", "ChannelMergerNode", "CryptoOperation", "EventSource", "FileReader", "HTMLUnknownElement", "IDBDatabase", "IDBRequest", "IDBTransaction", "KeyOperation", "MediaController", "MessagePort", "ModalWindow", "Notification", "SVGElementInstance", "Screen", "TextTrack", "TextTrackCue", "TextTrackList", "WebSocket", "WebSocketWorker", "Worker", "XMLHttpRequest", "XMLHttpRequestEventTarget", "XMLHttpRequestUpload"],
                eV = function() {
                    function t(e) {
                        this.name = t.id, this._options = d({
                            XMLHttpRequest: !0,
                            eventTarget: !0,
                            requestAnimationFrame: !0,
                            setInterval: !0,
                            setTimeout: !0
                        }, e)
                    }
                    return t.prototype.setupOnce = function() {
                        var t = (0, x.V)();
                        this._options.setTimeout && V(t, "setTimeout", eY), this._options.setInterval && V(t, "setInterval", eY), this._options.requestAnimationFrame && V(t, "requestAnimationFrame", eH), this._options.XMLHttpRequest && "XMLHttpRequest" in t && V(XMLHttpRequest.prototype, "send", eJ);
                        var e = this._options.eventTarget;
                        e && (Array.isArray(e) ? e : eF).forEach(ez)
                    }, t.id = "TryCatch", t
                }();

            function eY(t) {
                return function() {
                    for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                    var r = e[0];
                    return e[0] = e_(r, {
                        mechanism: {
                            data: {
                                function: A(t)
                            },
                            handled: !0,
                            type: "instrument"
                        }
                    }), t.apply(this, e)
                }
            }

            function eH(t) {
                return function(e) {
                    return t.call(this, e_(e, {
                        mechanism: {
                            data: {
                                function: "requestAnimationFrame",
                                handler: A(t)
                            },
                            handled: !0,
                            type: "instrument"
                        }
                    }))
                }
            }

            function eJ(t) {
                return function() {
                    for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                    var r = this;
                    return ["onload", "onerror", "onprogress", "onreadystatechange"].forEach(function(t) {
                        t in r && "function" == typeof r[t] && V(r, t, function(e) {
                            var n = {
                                    mechanism: {
                                        data: {
                                            function: t,
                                            handler: A(e)
                                        },
                                        handled: !0,
                                        type: "instrument"
                                    }
                                },
                                r = J(e);
                            return r && (n.mechanism.data.handler = A(r)), e_(e, n)
                        })
                    }), t.apply(this, e)
                }
            }

            function ez(t) {
                var e = (0, x.V)(),
                    n = e[t] && e[t].prototype;
                n && n.hasOwnProperty && n.hasOwnProperty("addEventListener") && (V(n, "addEventListener", function(e) {
                    return function(n, r, o) {
                        try {
                            "function" == typeof r.handleEvent && (r.handleEvent = e_(r.handleEvent.bind(r), {
                                mechanism: {
                                    data: {
                                        function: "handleEvent",
                                        handler: A(r),
                                        target: t
                                    },
                                    handled: !0,
                                    type: "instrument"
                                }
                            }))
                        } catch (t) {}
                        return e.call(this, n, e_(r, {
                            mechanism: {
                                data: {
                                    function: "addEventListener",
                                    handler: A(r),
                                    target: t
                                },
                                handled: !0,
                                type: "instrument"
                            }
                        }), o)
                    }
                }), V(n, "removeEventListener", function(t) {
                    return function(e, n, r) {
                        try {
                            var o = n && n.__sentry_wrapped__;
                            o && t.call(this, e, o, r)
                        } catch (t) {}
                        return t.call(this, e, n, r)
                    }
                }))
            }
            var eW = function() {
                    function t(e) {
                        void 0 === e && (e = {}), this.name = t.id, this._key = e.key || "cause", this._limit = e.limit || 5
                    }
                    return t.prototype.setupOnce = function() {
                        td(function(e, n) {
                            var r = tm().getIntegration(t);
                            return r ? function(t, e, n, r) {
                                if (!n.exception || !n.exception.values || !r || !U(r.originalException, Error)) return n;
                                var o = function t(e, n, r, o) {
                                    if (void 0 === o && (o = []), !U(n[r], Error) || o.length + 1 >= e) return o;
                                    var i = t1(n[r]);
                                    return t(e, n[r], r, y([i], o))
                                }(e, r.originalException, t);
                                return n.exception.values = y(o, n.exception.values), n
                            }(r._key, r._limit, e, n) : e
                        })
                    }, t.id = "LinkedErrors", t
                }(),
                eK = (0, x.V)(),
                eX = function() {
                    function t() {
                        this.name = t.id
                    }
                    return t.prototype.setupOnce = function() {
                        td(function(e) {
                            if (tm().getIntegration(t)) {
                                if (!eK.navigator && !eK.location && !eK.document) return e;
                                var n = e.request && e.request.url || eK.location && eK.location.href,
                                    r = (eK.document || {}).referrer,
                                    o = (eK.navigator || {}).userAgent,
                                    i = d(d(d({}, e.request && e.request.headers), r && {
                                        Referer: r
                                    }), o && {
                                        "User-Agent": o
                                    }),
                                    s = d(d({}, n && {
                                        url: n
                                    }), {
                                        headers: i
                                    });
                                return d(d({}, e), {
                                    request: s
                                })
                            }
                            return e
                        })
                    }, t.id = "UserAgent", t
                }(),
                e$ = function() {
                    function t() {
                        this.name = t.id
                    }
                    return t.prototype.setupOnce = function(e, n) {
                        e(function(e) {
                            var r, o, i, s, a, u, c, p, f, l, h = n().getIntegration(t);
                            if (h) {
                                try {
                                    if (r = e, (o = h._previousEvent) && (i = r, s = o, a = i.message, u = s.message, (a || u) && (!a || u) && (a || !u) && a === u && eZ(i, s) && eG(i, s) && 1 || (c = r, p = o, f = eQ(p), l = eQ(c), f && l && f.type === l.type && f.value === l.value && eZ(c, p) && eG(c, p)))) return ta.warn("Event dropped due to being a duplicate of previously captured event."), null
                                } catch (t) {}
                                return h._previousEvent = e
                            }
                            return e
                        })
                    }, t.id = "Dedupe", t
                }();

            function eG(t, e) {
                var n = e0(t),
                    r = e0(e);
                if (!n && !r) return !0;
                if (n && !r || !n && r || r.length !== n.length) return !1;
                for (var o = 0; o < r.length; o++) {
                    var i = r[o],
                        s = n[o];
                    if (i.filename !== s.filename || i.lineno !== s.lineno || i.colno !== s.colno || i.function !== s.function) return !1
                }
                return !0
            }

            function eZ(t, e) {
                var n = t.fingerprint,
                    r = e.fingerprint;
                if (!n && !r) return !0;
                if (n && !r || !n && r) return !1;
                try {
                    return n.join("") === r.join("")
                } catch (t) {
                    return !1
                }
            }

            function eQ(t) {
                return t.exception && t.exception.values && t.exception.values[0]
            }

            function e0(t) {
                var e = t.exception;
                if (e) try {
                    return e.values[0].stacktrace.frames
                } catch (t) {} else if (t.stacktrace) return t.stacktrace.frames
            }
            var e1 = {},
                e2 = (0, x.V)();
            e2.Sentry && e2.Sentry.Integrations && (e1 = e2.Sentry.Integrations), d(d(d({}, e1), p), f)
        }
    }
]);
//# sourceMappingURL=zipify-cart-drawer-sentry.js.map