"use strict";
(globalThis.zipifyCartJsonp = globalThis.zipifyCartJsonp || []).push([
    ["770"], {
        3938(e, t, r) {
            r.d(t, {
                default: () => c
            });
            var n = r(2577),
                o = r(9067),
                s = r(5072),
                i = r(2761),
                l = r(8830),
                a = r(1217),
                u = r(5696);
            let c = {
                namespaced: !0,
                state: {
                    t: null,
                    editMode: !1,
                    previewMode: !1,
                    isDesignMode: !1,
                    device: "desktop",
                    loading: !0,
                    fonts: [],
                    productHandle: null,
                    productVariantAvailableIds: null,
                    offerProduct: null,
                    offerProducts: {},
                    offerType: "Incart",
                    ocuToken: null,
                    incheckoutActive: null,
                    ids: {},
                    checkedOffers: {},
                    shownItems: {
                        initialize: !1,
                        index: 0,
                        prev: 0,
                        shownItems: 0
                    },
                    offerData: {
                        offers: []
                    },
                    representation: {
                        general: {},
                        headline: {},
                        timer: {},
                        offer: {},
                        buttons: {},
                        hero_section: {}
                    },
                    images: null,
                    products: null,
                    cart: null,
                    processing: !1,
                    moneyFormat: null,
                    currencyCode: null,
                    prices: {},
                    pricesDual: {},
                    selectedVariant: null,
                    translations: {},
                    tracking: {
                        viewportHeight: null,
                        alreadyTracked: [],
                        offsetTop: null,
                        offers: []
                    },
                    error: {
                        present: !1,
                        type: null,
                        banner: !1,
                        message: ""
                    },
                    quantity: 1,
                    isOnlySubscriptionProduct: !1,
                    replacingProductTitle: null,
                    replacingProductImage: null,
                    isDifferentCurrency: !1,
                    utils: {},
                    storeFrontProduct: null,
                    customerTags: [],
                    isButtonRendered: !1,
                    buyBoxRenderingConfig: {
                        buyBoxRendered: !1,
                        buyBoxIndex: null
                    },
                    inlineStatus: null,
                    maxPriceHeight: 0,
                    maxVariantHeight: 0,
                    discountData: null,
                    draftOrders: !1,
                    isEmbedded: !1,
                    viewOn: !1,
                    themeStyle: {}
                },
                getters: n.A,
                actions: o.Ay,
                mutations: {
                    setLoading(e, t) {
                        e.loading = t
                    },
                    setEditMode(e, t) {
                        e.editMode = t
                    },
                    setPreviewMode(e, t) {
                        e.previewMode = t
                    },
                    setDevice(e, t) {
                        e.device = t
                    },
                    setFonts(e, t) {
                        e.fonts = t
                    },
                    setOffer(e, t) {
                        t && (e.offerData = { ...t
                        }, e.offerData.offers.forEach(e => (0, l.f)(e)))
                    },
                    setIds(e, t) {
                        var r;
                        e.ids = null == t || null == (r = t.representation) ? void 0 : r.offers.map(e => e._ocu_offer_reference_id)
                    },
                    remapIds(e, t) {
                        t.forEach(t => {
                            e.ids[t] && (e.ids[t] = null)
                        })
                    },
                    checkOffer(e, t) {
                        e.checkedOffers[t] = !0, e.checkedOffers = { ...e.checkedOffers
                        }
                    },
                    uncheckOffer(e, t) {
                        e.checkedOffers[t] = !1, e.checkedOffers = { ...e.checkedOffers
                        }
                    },
                    clearCheckedOffers(e) {
                        Object.keys(e.checkedOffers).forEach(t => e.checkedOffers[t] = !1), e.checkedOffers = { ...e.checkedOffers
                        }
                    },
                    setVisibleIds(e, t) {
                        e.visibleOffersIds = t
                    },
                    setShownOffers(e, t) {
                        var r, n;
                        let {
                            index: o,
                            initialize: s,
                            shown: i
                        } = t;
                        if (null == (n = window) || null == (r = n.Shopify) ? void 0 : r.designMode) return;
                        s && e.shownItems.ids || (e.shownItems.ids = Array.from(Array(i)).keys()), e.shownItems.index = o;
                        let l = Array.from({
                            length: i
                        }, (e, t) => o + t);
                        e.shownItems.ids = Array.from(new Set([...e.shownItems.ids, ...l])), e.shownItems.initialize = s, e.shownItems.shown = i
                    },
                    setOfferProducts(e) {
                        let t = (e, t) => {
                            var r;
                            let [n, o] = t;
                            return { ...e,
                                ...{
                                    offer_id: +n,
                                    selected: !1,
                                    productId: null == o ? void 0 : o.id,
                                    variantId: null == o ? void 0 : o.variants[0].id,
                                    variant: null == o ? void 0 : o.variants[0],
                                    quantity: 1,
                                    prices: {
                                        price: null,
                                        discountedPrice: null,
                                        savings: null,
                                        _price: (null == o || null == (r = o.variants[0]) ? void 0 : r.price) / 100,
                                        _discountedPrice: null,
                                        _savings: null,
                                        _compareAtPrice: null
                                    }
                                }
                            }
                        };
                        e.offerProducts = e.products.map(e => Object.entries(e).reduce(t, {})), e.offerProducts = { ...e.offerProducts
                        }
                    },
                    setOfferType(e, t) {
                        e.offerType = t
                    },
                    setEmbedded(e, t) {
                        e.isEmbedded = t
                    },
                    setDesignMode(e, t) {
                        e.isDesignMode = t
                    },
                    setError(e, t) {
                        var r, n, o, s;
                        let {
                            type: i = "server_error",
                            banner: l = !1
                        } = t, a = null != (n = null == (r = e.offerData) ? void 0 : r.translations) ? n : u.b5;
                        a.product_sold_out && (a.product_sold_out = a.product_sold_out.replace("%name%", null != (s = null == (o = e.product) ? void 0 : o.title) ? s : "")), e.error = {
                            banner: l,
                            present: !0,
                            type: u.Sr[i],
                            message: a[i]
                        }
                    },
                    updateOffer(e, t) {
                        var r, n, o;
                        let s, {
                                data: i
                            } = t,
                            {
                                key: l,
                                index: a,
                                value: u
                            } = i,
                            c = e.offerData.offers[a].offer;
                        if ("images" === l) {
                            c[l] || (c[l] = []);
                            let t = c[l],
                                r = u.kind;
                            (null == t ? void 0 : t.length) ? (t = t.some(e => e.kind === r) ? t.map(e => e.kind === r ? u : e) : [...t, u], c[l] = [...t]) : c[l] = [u], e.offerData.offers = [...e.offerData.offers];
                            return
                        }
                        c[l] = "[object Object]" === Object.prototype.toString.call(c[l]) ? { ...c[l],
                            ...u
                        } : u;
                        let f = "star_rating" === l;
                        c = e.offerData.offers[a][f ? "star_rating" : "offer"], f ? Object.entries(u).forEach(e => {
                            let [t, r] = e;
                            return c[t] = r
                        }) : c[l] = (r = c, n = l, o = u, s = "star_rating" === n ? r : r[n], "[object Object]" === Object.prototype.toString.call(s) ? { ...s,
                            ...o
                        } : "images" === n ? [o] : o)
                    },
                    setOfferProduct(e, t) {
                        e.offerProduct = t, e.productHandle = t.handle, e.productVariantAvailableIds = t.variant_ids
                    },
                    setProducts(e, t) {
                        e.products = t
                    },
                    setProduct(e, t) {
                        e.products = e.previewMode ? (0, s.A)(t) : t
                    },
                    setMoneyFormat(e, t) {
                        e.moneyFormat = t.money_format, e.currencyCode = t.currency_code
                    },
                    setPrices(e, t) {
                        let {
                            prices: r,
                            index: n,
                            id: o
                        } = t;
                        e.products[n][o] && (e.products[n][o].prices = { ...e.products[n][o].prices,
                            ...r
                        })
                    },
                    setPricesDual(e, t) {
                        let {
                            prices: r
                        } = t;
                        e.pricesDual = { ...e.pricesDual,
                            ...r
                        }, e.pricesDual = { ...e.pricesDual,
                            ... function(e, t) {
                                var r, n, o, s, l, a, u, c, f;
                                let {
                                    prices: d,
                                    moneyFormat: p,
                                    currencyCode: m
                                } = e, y = {
                                    type: null == (n = e.representation) || null == (r = n.offer) ? void 0 : r.discount,
                                    value: null == (s = e.representation) || null == (o = s.offer) ? void 0 : o.discount_value
                                };
                                if (t) {
                                    let {
                                        dualPricing: e
                                    } = null != (l = window.OCUApi) ? l : {};
                                    /amount/.test(y.type) && (y.value /= null != (a = null == e ? void 0 : e.rate) ? a : 1), d = null != (u = null == e ? void 0 : e.prices) ? u : d, p = null != (c = null == e ? void 0 : e.moneyFormat) ? c : p, m = null != (f = null == e ? void 0 : e.currencyCode) ? f : m
                                }
                                return i.A.countPrices(y, d, p, m)
                            }(e, "dual")
                        }
                    },
                    setQuantity(e, t) {
                        let {
                            index: r,
                            quantity: n
                        } = t;
                        e.offerProducts[r].quantity = n < 1 ? 1 : +n, e.offerProducts[r] = { ...e.offerProducts[r]
                        }
                    },
                    setAccepting(e, t) {
                        e.accepting = t
                    },
                    setRepresentation(e, t) {
                        var r, n, o;
                        let {
                            section: s,
                            data: i
                        } = t;
                        e.representation[s][i.key] = (r = s, n = e.representation, (o = i).value instanceof Object ? { ...n[r][o.key],
                            ...o.value
                        } : o.value)
                    },
                    setFullRepresentation(e, t) {
                        Object.keys(e.representation).forEach(r => {
                            e.representation[r] = t[r]
                        }), e.representation = { ...(0, l.f)({ ...t
                            })
                        }
                    },
                    updateOffers(e) {
                        let {
                            products: t,
                            offerData: r
                        } = e, n = t.map(e => +Object.keys(e)[0]);
                        r.offers = r.offers.filter(e => n.includes(e.offer_id))
                    },
                    convertAmountDiscountCurrency(e) {
                        e.offerData.offers.forEach(t => {
                            var r, n, o, s, i;
                            "amount" !== t.offer.discount.type || e.isDifferentCurrency && (t.offer.discount.value = (r = t.offer.discount.value, n = e.currencyCode, r *= null != (i = window.Shopify && (null == (s = Shopify) || null == (o = s.currency) ? void 0 : o.rate)) ? i : 1, a.uL.includes(n) && (r = Math.round(r)), r))
                        })
                    },
                    setImages(e, t) {
                        e.images = t
                    },
                    setCart(e, t) {
                        e.cart = t
                    },
                    setProcessing(e, t) {
                        e.processing = t
                    },
                    setCurrency(e, t) {
                        var r, n, o, s, i, l;
                        let {
                            format: a,
                            code: u
                        } = t, {
                            active: c,
                            rate: f
                        } = null != (o = Shopify.currency) ? o : {};
                        e.isDifferentCurrency = c !== u && 1 !== Number(f), e.currencyCode = e.isDifferentCurrency ? c : u, e.country = e.isDifferentCurrency ? null == (n = window) || null == (r = n.Shopify) ? void 0 : r.country : null, e.isEmbedded ? e.moneyFormat = null != (s = Zipify.Cart.moneyFormat) ? s : a : e.moneyFormat = null != (l = Zipify.OCU.api.moneyFormat) ? l : e.isDifferentCurrency && (null == (i = OCUIncart) ? void 0 : i.money_format) || a
                    },
                    setBuyBoxConfig(e, t) {
                        e.buyBoxRenderingConfig = t
                    },
                    setOcuToken(e, t) {
                        e.ocuToken = t
                    },
                    setIncheckoutActive(e, t) {
                        e.incheckoutActive = t
                    },
                    setReplaced(e, t) {
                        e.replaced = { ...t
                        }
                    },
                    updatePrices(e, t) {
                        let {
                            productId: r,
                            prices: n
                        } = t;
                        e.offerProducts[r].prices = { ...e.offerProducts[r].prices,
                            ...n
                        }
                    },
                    clearData(e) {
                        e.products = null, e.loading = !0, e.buyBoxRenderingConfig = {
                            buyBoxRendered: null,
                            buyBoxIndex: null
                        }, e.quantity = 1
                    },
                    trackingOffer(e, t) {
                        e.tracking.offers.push(t)
                    },
                    trackingProperty(e, t) {
                        let {
                            key: r,
                            value: n
                        } = t;
                        e.tracking[r] = n
                    },
                    onlySubscriptionProduct(e, t) {
                        e.isOnlySubscriptionProduct = t
                    },
                    setUtils(e, t) {
                        e.utils = t
                    },
                    storeFrontProduct(e, t) {
                        e.storeFrontProduct = t
                    },
                    setCustomerTags(e, t) {
                        e.customerTags = t
                    },
                    setCustomerLocation(e, t) {
                        e.customerLocation = t
                    },
                    setButtonRendered(e, t) {
                        e.isButtonRendered = t
                    },
                    setOfferDescription(e) {
                        e.offerDescription = e.representation.offer.offer_description
                    },
                    setInlineStatus(e, t) {
                        e.inlineStatus = t
                    },
                    setMaxPriceHeight(e, t) {
                        e.maxPriceHeight < t && (e.maxPriceHeight = t)
                    },
                    setMaxVariantHeight(e, t) {
                        e.maxVariantHeight < t && (e.maxVariantHeight = t)
                    },
                    resetMaxPriceHeight(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                        e.maxPriceHeight = t
                    },
                    resetMaxVariantHeight(e) {
                        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                        e.maxVariantHeight = t
                    },
                    setDiscountData(e, t) {
                        e.discountData = t
                    },
                    setDraftOrders(e, t) {
                        e.draftOrders = t
                    },
                    setViewOn(e, t) {
                        e.viewOn = t
                    },
                    setStorefrontData(e, t) {
                        e.storefrontData = t
                    },
                    filterOffers(e, t) {
                        let r = e.offerData.offers.findIndex(e => {
                            let {
                                offer_id: r
                            } = e;
                            return r === t
                        });
                        e.offerData.offers = e.offerData.offers.filter(e => {
                            let {
                                offer_id: r
                            } = e;
                            return r !== t
                        }), e.offerProducts = Object.fromEntries(Object.entries(e.offerProducts).filter(e => {
                            let [r, {
                                offer_id: n
                            }] = e;
                            return n !== t
                        }).map((e, t) => {
                            let [r, n] = e;
                            return [t, n]
                        })), e.shownItems.ids = e.shownItems.ids.filter(e => e !== r).map((e, t) => t), e.products = e.products.filter(e => !e[t]), e.ids = e.ids.filter((e, t) => t !== r)
                    },
                    carouselIndicator(e, t) {
                        e.isCarouselInitialize = t
                    },
                    setThemeStyle(e, t) {
                        e.themeStyle = t
                    }
                }
            }
        }
    }
]);
//# sourceMappingURL=zipify-product-page-widget.module.js.map